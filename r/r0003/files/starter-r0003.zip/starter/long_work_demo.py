"""Глава 16. Долгая и совместная работа: то, чего нет в конструкторе «Дежурного».

Session и Outer loop живут в самом ``dezhurny.py run`` (план ``16_run_plan.json``).
Здесь — две учебные вещи вокруг них:

``repeat`` — одно и то же подтверждённое предложение применяется дважды
существующим ``apply_status_update`` во временной копии workspace: второй раз
эффекта нет (``already_applied``). Это учебная защита от повтора, не exactly-once.

``handoff --case analyzer`` — учебный ограниченный исполнитель: фиксированная
последовательность существующих tools через dispatcher, без модели и сети; его
результат — структурированный Handoff для Owner, проверенный
``validate_architecture_handoff``. ``--case missing-owner`` — Handoff без Owner
не принимается, ничего не выполняется.
"""

import argparse
import hashlib
import json
import re
import shutil
import tempfile
from pathlib import Path

from permissions_demo import NEW_STATUS, REASON, TASK_ID
from school_agent.approval import apply_status_update
from school_agent.dispatcher import call_tool
from school_agent.long_work import validate_architecture_handoff
from school_agent.paths import WORKSPACE_ROOT, resolve_workspace_path
from school_agent.tools import Tools

OWNER = "project-team"
EXECUTOR = "analyzer — учебный ограниченный исполнитель, не второй LLM"
MISSING_OWNER_CASE = "ch16/cases/architecture_missing_owner.json"
REPORT_NUMBERS = (("count", "Всего задач"), ("unfinished", "Незавершённых"), ("blocked", "Заблокированных"))


def _tasks_digest(workspace_root):
    folder = resolve_workspace_path("tasks", workspace_root=workspace_root, must_exist=True)
    digest = hashlib.sha256()
    for path in sorted(folder.glob("*.json")):
        digest.update(path.name.encode("utf-8"))
        digest.update(path.read_bytes())
    return digest.hexdigest()


def _card(workspace):
    return json.loads((workspace / "tasks" / (TASK_ID + ".json")).read_text(encoding="utf-8"))


def cmd_repeat(*, workspace_root=WORKSPACE_ROOT):
    shipped = _tasks_digest(workspace_root)
    with tempfile.TemporaryDirectory() as directory:
        # Временная копия: поставляемые карточки не меняются.
        workspace = Path(directory) / "workspace"
        shutil.copytree(Path(workspace_root), workspace)
        proposal = Tools(workspace_root=workspace).propose_status_update(TASK_ID, NEW_STATUS, REASON)
        states = [_card(workspace)]
        results = []
        for _ in range(2):
            # Одно и то же предложение, уже подтверждённое человеком, приходит второй раз.
            results.append(apply_status_update(proposal, approved=True, workspace_root=workspace))
            states.append(_card(workspace))
    changes = sum(1 for before, after in zip(states, states[1:]) if before != after)
    first, second = results
    return ["long_work: repeat",
            "proposal: %s | %s -> %s | operation_id: %s" % (
                TASK_ID, proposal["before"]["status"], proposal["after"]["status"], proposal["operation_id"]),
            "human_decision: approve — одно подтверждённое предложение, применяется дважды",
            "first: applied: %s | operation_id %s" % ("yes" if first["applied"] else "no", first["operation_id"]),
            "second: applied: %s | already_applied: %s | operation_id %s" % (
                "yes" if second["applied"] else "no", "yes" if second.get("already_applied") else "no",
                second["operation_id"]),
            "card changed: " + {0: "never", 1: "once"}.get(changes, "%d times" % changes),
            "shipped cards changed: " + ("no" if _tasks_digest(workspace_root) == shipped else "yes"),
            "граница: учебная защита от повтора одного предложения, не exactly-once"]


def _analyze(workspace_root):
    """Фиксированная последовательность существующих tools через dispatcher; модели нет."""

    tools = Tools(workspace_root=workspace_root)
    calls = [{"id": "a1", "name": "read_task_cards", "arguments": {}}]
    observation = call_tool(calls[0], tools)
    if not observation["ok"]:
        raise ValueError("read_task_cards: " + observation["error"]["message"])
    for number, card in enumerate(observation["result"]["untrusted_content"], 2):
        calls.append({"id": "a%d" % number, "name": "validate_task_card", "arguments": {"task_id": card["id"]}})
        if not call_tool(calls[-1], tools)["ok"]:
            raise ValueError("validate_task_card: " + card["id"])
    calls.append({"id": "a%d" % (len(calls) + 1), "name": "build_status_report", "arguments": {}})
    report = call_tool(calls[-1], tools)
    if not report["ok"]:
        raise ValueError("build_status_report: " + report["error"]["message"])
    return [call["name"] for call in calls], report["result"]["report"]


def cmd_handoff(case, *, workspace_root=WORKSPACE_ROOT):
    if case == "missing-owner":
        path = resolve_workspace_path(MISSING_OWNER_CASE, workspace_root=workspace_root, must_exist=True)
        handoff = json.loads(path.read_text(encoding="utf-8"))
        errors = validate_architecture_handoff(handoff)
        return ["long_work: handoff --case missing-owner",
                "handoff: workspace/" + MISSING_OWNER_CASE,
                "executor: " + str(handoff.get("executor")),
                "subtask: " + str(handoff.get("subtask")),
                "owner: " + (handoff["owner"] if handoff.get("owner") else "нет"),
                "result: " + ("accepted" if not errors else "not accepted — " + "; ".join(errors)),
                "executed: ничего — решение без Owner не принимается"]
    names, report = _analyze(workspace_root)
    found = {}
    for key, label in REPORT_NUMBERS:
        match = re.search(r"^" + label + r": (\d+)\.$", report, re.M)
        found[key] = int(match.group(1))
    evidence = "observation build_status_report — " + ", ".join(
        "«%s: %d.»" % (label, found[key]) for key, label in REPORT_NUMBERS)
    handoff = {"subtask": "анализ карточек", "executor": EXECUTOR, "result": found, "owner": OWNER,
               "constraints": "permissions и trust прежние", "basis": "fact", "evidence": evidence}
    errors = validate_architecture_handoff(handoff)
    validated = names.count("validate_task_card")
    return ["long_work: handoff --case analyzer",
            "executor: " + handoff["executor"],
            "subtask: " + handoff["subtask"],
            "tools: read_task_cards, validate_task_card ×%d, build_status_report" % validated,
            "handoff.result: count %(count)d | unfinished %(unfinished)d | blocked %(blocked)d" % found,
            "owner: " + handoff["owner"],
            "constraints: " + handoff["constraints"],
            "basis: " + handoff["basis"] + " | evidence: " + handoff["evidence"],
            "model/network: not used",
            "decision made by executor: no",
            "result: " + ("accepted" if not errors else "not accepted — " + "; ".join(errors))]


def main(argv=None):
    parser = argparse.ArgumentParser(description="Долгая и совместная работа главы 16.")
    commands = parser.add_subparsers(dest="command", required=True)
    commands.add_parser("repeat", help="одно подтверждённое изменение применяется дважды — эффект один")
    handoff = commands.add_parser("handoff", help="Handoff учебного ограниченного исполнителя для Owner")
    handoff.add_argument("--case", required=True, choices=("analyzer", "missing-owner"))
    args = parser.parse_args(argv)
    try:
        lines = cmd_repeat() if args.command == "repeat" else cmd_handoff(args.case)
    except (ValueError, FileNotFoundError, OSError) as exc:
        parser.error(str(exc))
    for line in lines:
        print(line)
    return 0


if __name__ == "__main__":
    main()
