"""Конструктор «Дежурного» (EC-24): один запускатель для агента ученика.

Код harness остаётся в ``school_agent/``; ученик настраивает только папку
``workspace/my_agent/``. ``run`` — это существующий ``run_agent`` с профилем
из этой папки: второго цикла, диспетчера и загрузчика skill здесь нет.
Модель — replay (авторский сценарий) или ручной bridge; все различия
поведения даёт harness, а не «поумневшая» модель. С ``16_run_plan.json``
один ``run`` — это одна Session: checkpoint между запусками пишет и проверяет
harness, после ``max_sessions`` Inner loop не запускается (глава 16).
``candidate`` фиксирует Release candidate: метку и отпечаток файлов
конфигурации; после любого изменения метка недействительна, и ``run``/``eval``
под ней не запускаются (глава 17). ``version`` сохраняет неизменяемый снимок
конфигурации в ``13_versions/<метка>/`` и сравнивает два снимка по одному
набору случаев ``11_evals.json`` (глава 13); решение — рекомендация, файлы
``my_agent/`` не меняются.

    python dezhurny.py status [--dir workspace/my_agent] [--json] [--chapter N]
    python dezhurny.py run [--dir …] [--scenario S] [--model replay|bridge]
    python dezhurny.py eval [--dir …]
    python dezhurny.py trace --last [--dir …]
    python dezhurny.py candidate --label L [--dir …]
    python dezhurny.py version save L | list | compare A B [--dir …]
"""

import argparse
import json
from pathlib import Path

from school_agent.agent import run_agent, run_replay_scenario
from school_agent.long_work import RunPlanError, build_checkpoint, session_number
from school_agent.release_candidate import FILE_NAME as CANDIDATE_FILE, ReleaseCandidateError, build_release_candidate
from school_agent.config import MAX_RETRIES, MAX_STEPS
from school_agent.my_agent_config import (
    DEFAULT_DIR, REPLAY_SCENARIOS, RESERVED, ConfigError, build_profile, check_save,
    contract_check, read_my_agent, require_valid, skill_connection,
)
from school_agent.paths import WORKSPACE_ROOT, WorkspaceBoundaryError, resolve_workspace_path
from school_agent.permissions import approval_allowed
from school_agent.skill_loader import discover_skills, load_skill, list_skill_files
from school_agent.state_store import build_handoff, load_state, save_state, validate_project_state
from school_agent.trace_analysis import build_incident_report, load_trace
from school_agent.versions import FOLDER as VERSIONS_DIR, VersionsError, compare_versions, list_versions, save_version

TRACE_DIR = "traces/dezhurny"
ORIGIN_NOTE = "авторский сценарий, не запись модели"
STATE_NAMES = {"configured": "настроено", "not_configured": "не настроено",
               "reserved": "зарезервировано", "error": "ошибка"}


def _relative(raw):
    """``workspace/…`` → путь относительно workspace; границу проверит resolve_workspace_path."""

    parts = Path(raw).as_posix().split("/")
    if Path(raw).is_absolute() or parts[0] != "workspace" or len(parts) < 2:
        raise WorkspaceBoundaryError("ожидался относительный путь внутри workspace/")
    return "/".join(parts[1:])


def _plural(number, one, few, many):
    """Форма слова после числа: 1 пункт, 2 пункта, 5 пунктов."""
    if number % 10 == 1 and number % 100 != 11:
        return one
    if 2 <= number % 10 <= 4 and not 12 <= number % 100 <= 14:
        return few
    return many


def _not_configured(chapter):
    return "не настроено (глава %d)" % chapter


def _detail(row, values):
    name, value = row["file"], values.get(row["file"])
    if row["state"] != "configured":
        return row["detail"]
    if name == "01_goal.md":
        return "«" + value + "»"
    if name == "02_stop_policy.json":
        return "max_steps %d, max_retries %d" % (value["max_steps"], value["max_retries"])
    if name == "03_workspace_policy.json":
        return ("операции: " + ", ".join(value["allowed_operations"]) + "; область записи: "
                + value["writable_prefix"] + "; черновик → " + value["save_report_to"])
    if name == "05_task_contract.md":
        count = len(value["done_when"])
        return "готово, когда: %d %s" % (count, _plural(count, "пункт", "пункта", "пунктов"))
    if name == "07_tools.json":
        return "allowlist: " + ", ".join(value["enabled"])
    if name == "08_my_tool.py":
        tools = values.get("07_tools.json")
        listed = bool(tools) and value["name"] in tools["enabled"]
        return (value["name"] + " — «" + value["description"] + "»; в каталоге: "
                + ("да" if listed else "нет, имени нет в 07_tools.json"))
    if name == "09_skills":
        return "skills: " + ", ".join(skill["name"] for skill in value["catalog"])
    if name == "10_state.json":
        return "запусков: %d" % value.get("runs", 0)
    if name == "11_evals.json":
        return "случаев: %d" % len(value["cases"])
    if name == "12_trace.json":
        return "enabled: " + ("true" if value["enabled"] else "false")
    if name == "14_permissions.json":
        return "; ".join(key + " " + value[key] for key in ("default", "task_cards", "status_update"))
    if name == "15_trust.json":
        decisions = list(value["skills"].values())
        return "external_content untrusted; skills: " + ", ".join(
            "%s %d" % (decision, decisions.count(decision)) for decision in ("connect_minimal", "isolate", "reject"))
    if name == "16_run_plan.json":
        return "max_sessions %d; checkpoint %s; owner %s" % (value["max_sessions"], value["checkpoint"], value["owner"])
    if name == VERSIONS_DIR:
        return "версий: %d" % len(value) + (
            " (" + ", ".join(item["label"] for item in value) + ")" if value else "")
    if name == CANDIDATE_FILE:
        return "%s; зафиксировано файлов: %d" % (value["label"], value["files"])
    return ""


def _effect(row, values):
    """Эффект строки 14 зависит от политики: открыт ли approval gate — решает approval_allowed."""

    if row["state"] == "error":
        # require_valid останавливает run и eval на любой строке с ошибкой.
        return "run не запускается, пока файл не исправлен"
    if row["file"] == "14_permissions.json" and row["state"] == "configured":
        allowed, reason = approval_allowed(values["14_permissions.json"])
        return ("approval gate: изменение статуса только после решения человека" if allowed
                else "approval gate закрыт: " + reason)
    if row["file"] == "15_trust.json" and row["state"] == "configured":
        return "каталог модели: только skills с решением connect_minimal"
    if row["file"] == "16_run_plan.json" and row["state"] == "configured":
        return "run: Session с checkpoint; после max_sessions — остановка до цикла"
    if row["file"] == VERSIONS_DIR and row["state"] == "configured":
        return "version save/list/compare"
    if row["file"] == CANDIDATE_FILE and row["state"] == "configured":
        return "run: печатает метку кандидата; после изменения любого файла — недействительна"
    return row["effect"]


def cmd_status(relative_dir=DEFAULT_DIR, *, workspace_root=WORKSPACE_ROOT, as_json=False, chapter=None):
    config = read_my_agent(relative_dir, workspace_root=workspace_root)
    rows = [dict(row, detail=_detail(row, config["values"]), effect=_effect(row, config["values"]))
            for row in config["rows"]]
    if chapter is not None:
        # Строка одной главы: главы печатают её, и соседние главы не меняют их вывод.
        if chapter not in {row["chapter"] for row in rows}:
            raise ConfigError("в my_agent/ нет файла главы %d" % chapter)
        rows = [row for row in rows if row["chapter"] == chapter]
        if as_json:
            return json.dumps({"config": "workspace/" + relative_dir, "rows": rows},
                              ensure_ascii=False, indent=2).splitlines()
        return ["dezhurny: status", "config: workspace/" + relative_dir] + [_status_line(row) for row in rows]
    active = [row for row in rows if row["file"] not in RESERVED]
    configured = sum(1 for row in active if row["state"] == "configured")
    if as_json:
        document = {"config": "workspace/" + relative_dir, "rows": rows,
                    "configured": configured, "total": len(active), "unknown": config["unknown"]}
        return json.dumps(document, ensure_ascii=False, indent=2).splitlines()
    lines = ["dezhurny: status", "config: workspace/" + relative_dir]
    lines += [_status_line(row) for row in rows]
    lines.append("configured: %d/%d" % (configured, len(active)))
    if config["unknown"]:
        lines.append("не распознано: " + ", ".join(config["unknown"]))
    return lines


def _status_line(row):
    state = STATE_NAMES[row["state"]]
    if row["detail"]:
        state += ": " + row["detail"]
    return "глава %d | %s | %s | %s" % (row["chapter"], row["file"], state, row["effect"])


def _next_trace(workspace_root):
    folder = resolve_workspace_path(TRACE_DIR, workspace_root=workspace_root)
    taken = [int(path.stem[4:]) for path in folder.glob("run-*.jsonl") if path.stem[4:].isdigit()]
    return TRACE_DIR + "/run-%03d.jsonl" % (max(taken, default=0) + 1)


def cmd_run(relative_dir=DEFAULT_DIR, *, scenario="success", model="replay",
            workspace_root=WORKSPACE_ROOT, bridge_factory=None):
    config = require_valid(read_my_agent(relative_dir, workspace_root=workspace_root))
    values = config["values"]
    if scenario not in REPLAY_SCENARIOS:
        raise ConfigError("неизвестный сценарий: " + scenario)
    if model == "bridge" and scenario != "success":
        raise ConfigError("ручной мост использует только сценарий success")
    policy = values.get("02_stop_policy.json", {"max_steps": MAX_STEPS, "max_retries": MAX_RETRIES})
    plan = values.get("16_run_plan.json")
    # Checkpoint проверяется до Inner loop: невалидный останавливает run, как ошибка файла.
    checkpoint, session = _load_checkpoint(plan, workspace_root) if plan else (None, None)
    profile = build_profile(config)
    trace_path = _next_trace(workspace_root) if values.get("12_trace.json", {}).get("enabled") else None
    goal = values.get("01_goal.md")
    lines = ["dezhurny: run", "goal: " + (goal or _not_configured(1)),
             "config: workspace/" + relative_dir,
             "model: " + model + (" — " + ORIGIN_NOTE if model == "replay" else " — ручной перенос, не проверенная запись"),
             "scenario: " + scenario,
             "stop_policy: max_steps %d, max_retries %d%s" % (
                 policy["max_steps"], policy["max_retries"],
                 "" if "02_stop_policy.json" in values else " (по умолчанию, глава 2)")]
    tools = values.get("07_tools.json")
    lines.append("tools: " + (", ".join(tools["enabled"]) if tools else "allowlist диспетчера (по умолчанию, глава 7)"))
    if profile is not None and profile.extra_tools:
        lines.append("my_tool: " + profile.extra_tools[0]["name"] + " — в каталоге модели, не исполняется")
    skills = values.get("09_skills")
    if skills:
        connected, not_connected = skill_connection(config)
        lines.append("my_skills: " + (", ".join(connected) if connected else "нет подключённых"))
        lines += ["not connected: %s (%s)" % item for item in not_connected]
    permissions = values.get("14_permissions.json")
    if permissions:
        lines.append("permissions: " + " | ".join(
            key + " " + permissions[key] for key in ("default", "task_cards", "status_update")))
    lines += _candidate_lines(values)
    if plan is not None:
        if session > plan["max_sessions"]:
            # Outer loop исчерпан: Inner loop не запускается, checkpoint не переписывается.
            return lines + ["outer loop: стоп — sessions %d/%d использованы; продолжение решает Owner: %s" % (
                                session - 1, plan["max_sessions"], plan["owner"]),
                            "checkpoint: не изменён | " + plan["checkpoint"]]
        lines.append(_session_line(session, plan, checkpoint))
    kwargs = dict(workspace_root=workspace_root, max_steps=policy["max_steps"],
                  max_retries=policy["max_retries"], trace_relative_path=trace_path, profile=profile)
    if model == "bridge":
        from school_agent.bridge import ManualBridge
        result = run_agent((bridge_factory or ManualBridge)(), scenario=scenario, **kwargs)
    else:
        result = run_replay_scenario(scenario, **kwargs)
    for event in result["trace"]:
        payload = event["payload"]
        if event["type"] == "tool_observation":
            lines.append("Шаг " + str(payload["step"]) + " | " + payload["observation"]["name"]
                         + " | " + payload["decision"])
        elif event["type"] == "tool_rejected" and payload.get("code") == "not_in_profile_allowlist":
            lines.append("Отклонено: " + str(payload.get("name")) + " | нет в 07_tools.json")
    lines.append("Остановка: " + result["terminal"])
    lines += _proposal_lines(result, permissions)
    if result["report"]:
        lines += result["report"].rstrip("\n").split("\n")
    contract = values.get("05_task_contract.md")
    if contract is None:
        lines.append("contract: " + _not_configured(5))
    else:
        missing = contract_check(contract["done_when"], result["report"])
        lines.append("contract: " + ("ok" if not missing else "violated — нет: " + "; ".join(missing)))
    lines.append(_save_line(values.get("03_workspace_policy.json"), result, workspace_root))
    lines.append(_state_line(relative_dir, values.get("10_state.json"), result, scenario, workspace_root))
    lines.append("trace: " + ("workspace/" + trace_path if trace_path else _not_configured(12)))
    if plan is not None:
        lines += _checkpoint_lines(plan, checkpoint, dict(result, scenario=scenario), goal, workspace_root)
    lines.append("Качество модели не подтверждено этим техническим прогоном.")
    return lines


def _candidate_lines(values):
    """Метка Release candidate до цикла; цикл, tools и permissions она не меняет."""

    candidate = values.get(CANDIDATE_FILE)
    if candidate is None:
        return []
    return ["Release candidate: %s | зафиксировано файлов: %d | отпечаток совпадает — метка кандидата, "
            "не доказательство качества" % (candidate["label"], candidate["files"])]


def cmd_candidate(relative_dir=DEFAULT_DIR, *, label, workspace_root=WORKSPACE_ROOT):
    """Зафиксировать Release candidate: метка и отпечаток текущих файлов конфигурации."""

    config = read_my_agent(relative_dir, workspace_root=workspace_root)
    # Фиксируется только проверенная конфигурация; прежняя метка 17 заменяется новой.
    broken = [row for row in config["rows"] if row["state"] == "error" and row["file"] != CANDIDATE_FILE]
    if broken:
        raise ConfigError(broken[0]["detail"])
    try:
        value = build_release_candidate(label, config["dir"])
    except ReleaseCandidateError as exc:
        raise ConfigError(str(exc)) from exc
    try:
        same = json.loads((config["dir"] / CANDIDATE_FILE).read_text(encoding="utf-8")) == value
    except (OSError, ValueError):
        same = False
    if not same:
        save_state(value, relative_dir + "/" + CANDIDATE_FILE, workspace_root=workspace_root)
    return ["dezhurny: candidate", "config: workspace/" + relative_dir,
            "Release candidate: %s | зафиксировано файлов: %d | digest: %s" % (
                label, len(value["files"]), value["digest"][:12]),
            "метка кандидата, не доказательство качества"]


def _load_checkpoint(plan, workspace_root):
    """(checkpoint или None, номер начинающейся Session) по плану 16_run_plan.json."""

    target = plan["checkpoint"]
    path = resolve_workspace_path(target, workspace_root=workspace_root)
    try:
        path.relative_to(resolve_workspace_path("drafts", workspace_root=workspace_root))
    except ValueError:
        raise ConfigError("16_run_plan.json: checkpoint — относительный путь внутри drafts/") from None
    if not path.exists():
        return None, 1
    try:
        state = load_state(target, workspace_root=workspace_root)
        errors = validate_project_state(state)
        if errors:
            raise RunPlanError("; ".join(errors))
        return state, session_number(state)
    except (ValueError, OSError) as exc:
        raise ConfigError("checkpoint: not accepted — " + str(exc)) from exc


def _session_line(session, plan, checkpoint):
    head = "session: %d/%d | " % (session, plan["max_sessions"])
    if checkpoint is None:
        return head + "checkpoint: нет — первая Session"
    return head + "checkpoint loaded | previous: %s | next step: %s" % (
        checkpoint.get("last_terminal", checkpoint["status"]), checkpoint["next_step"])


def _checkpoint_lines(plan, checkpoint, result, goal, workspace_root):
    state = build_checkpoint(checkpoint, result, plan, goal)
    save_state(state, plan["checkpoint"], workspace_root=workspace_root)
    # build_handoff отклоняет состояние с secret-полем, поэтому здесь секретов нет.
    handoff = build_handoff(state)
    return ["checkpoint: saved | %s | status %s | next step: %s" % (plan["checkpoint"], state["status"],
                                                                     state["next_step"]),
            "handoff: build_handoff — поля " + ", ".join(handoff) + " | transcript: "
            + ("yes" if "transcript" in handoff else "no") + " | secrets: 0 | owner: " + plan["owner"]]


def _proposal_lines(result, permissions):
    """Proposal из observation и состояние approval gate. Применения здесь нет никогда."""

    lines = []
    for event in result["trace"]:
        payload = event["payload"]
        if event["type"] != "tool_observation" or payload["observation"]["name"] != "propose_status_update"                 or not payload["observation"]["ok"]:
            continue
        proposal = payload["observation"]["result"]
        allowed, reason = approval_allowed(permissions)
        lines += ["proposal: %s | %s -> %s | operation_id: %s" % (
                      proposal["before"]["id"], proposal["before"]["status"], proposal["after"]["status"],
                      proposal["operation_id"]),
                  "approval: " + ("required" if allowed else "gate closed — " + reason),
                  "applied: no"]
    return lines


def _save_line(policy, result, workspace_root):
    if policy is None:
        return "save: " + _not_configured(3)
    if not result["report"]:
        return "save: нечего сохранять — черновика нет"
    status, reason, target = check_save(policy, workspace_root=workspace_root)
    if status == "allowed":
        path = resolve_workspace_path(target, workspace_root=workspace_root)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(result["report"], encoding="utf-8")
    return "save: " + status + " | " + reason + " | " + target


def _state_line(relative_dir, state, result, scenario, workspace_root):
    if state is None:
        return "state: " + _not_configured(10)
    runs = state.get("runs", 0)
    seen = ("первый запуск" if runs == 0 else "предыдущий запуск — %s, шагов %s" % (
        state.get("last_terminal"), state.get("last_steps")))
    save_state(dict(state, runs=runs + 1, last_terminal=result["terminal"], last_steps=result["steps"],
                    last_scenario=scenario), relative_dir + "/10_state.json", workspace_root=workspace_root)
    return "state: " + seen + " (запусков теперь: %d)" % (runs + 1)


def cmd_eval(relative_dir=DEFAULT_DIR, *, workspace_root=WORKSPACE_ROOT):
    config = require_valid(read_my_agent(relative_dir, workspace_root=workspace_root))
    values = config["values"]
    lines = ["dezhurny: eval", "config: workspace/" + relative_dir] + _candidate_lines(values)
    evals = values.get("11_evals.json")
    if evals is None:
        return lines + ["eval: " + _not_configured(11) + " — нет 11_evals.json"]
    results = _eval_cases(config, workspace_root)
    for case, terminal, ok in results:
        lines.append("case %s: scenario %s | expected %s | actual %s | %s" % (
            case["id"], case["scenario"], case["expected_terminal"], terminal, "pass" if ok else "fail"))
    lines.append("result: %d/%d" % (sum(ok for _, _, ok in results), len(results)))
    lines.append(EVIDENCE)
    return lines


EVIDENCE = "evidence: synthetic_script — проверка harness и настроек my_agent, не качество модели"


def _eval_cases(config, workspace_root):
    """[(случай, terminal, pass?)] для 11_evals.json проверенной конфигурации."""

    values = config["values"]
    policy = values.get("02_stop_policy.json", {"max_steps": MAX_STEPS, "max_retries": MAX_RETRIES})
    profile = build_profile(config)
    results = []
    for case in values["11_evals.json"]["cases"]:
        result = run_replay_scenario(case["scenario"], workspace_root=workspace_root,
                                     max_steps=policy["max_steps"], max_retries=policy["max_retries"],
                                     profile=profile)
        results.append((case, result["terminal"], result["terminal"] == case["expected_terminal"]))
    return results


def cmd_version_save(relative_dir=DEFAULT_DIR, *, label, workspace_root=WORKSPACE_ROOT):
    """Снимок проверенной конфигурации в 13_versions/<label>/; повтор той же метки ничего не пишет."""

    config = read_my_agent(relative_dir, workspace_root=workspace_root)
    # Снимок — только проверенной конфигурации; строки 13 (снимки) и 17 (метка) в него не входят.
    broken = [row for row in config["rows"]
              if row["state"] == "error" and row["file"] not in (VERSIONS_DIR, CANDIDATE_FILE)]
    if broken:
        raise ConfigError(broken[0]["detail"])
    try:
        manifest = save_version(config["dir"], label, workspace_root=workspace_root)
    except VersionsError as exc:
        raise ConfigError(str(exc)) from exc
    return ["dezhurny: version save", "config: workspace/" + relative_dir,
            "version: %s | файлов: %d | digest: %s" % (label, len(manifest["files"]), manifest["digest"][:12]),
            "снимок конфигурации, не оценка качества"]


def _manifests(relative_dir, workspace_root):
    config = read_my_agent(relative_dir, workspace_root=workspace_root)
    try:
        return config, list_versions(config["dir"])
    except VersionsError as exc:
        raise ConfigError(str(exc)) from exc


def cmd_version_list(relative_dir=DEFAULT_DIR, *, workspace_root=WORKSPACE_ROOT):
    _, manifests = _manifests(relative_dir, workspace_root)
    lines = ["dezhurny: version list", "config: workspace/" + relative_dir]
    if not manifests:
        return lines + ["versions: нет — выполни python dezhurny.py version save <метка>"]
    return lines + ["%s | файлов: %d | digest: %s" % (item["label"], len(item["files"]), item["digest"][:12])
                    for item in manifests]


def cmd_version_compare(relative_dir=DEFAULT_DIR, *, first, second, workspace_root=WORKSPACE_ROOT):
    """Разница снимков и, если набор случаев один, eval на каждом; решение — рекомендация."""

    config, _ = _manifests(relative_dir, workspace_root)
    try:
        difference = compare_versions(config["dir"], first, second)
    except VersionsError as exc:
        raise ConfigError(str(exc)) from exc
    lines = ["dezhurny: version compare", "config: workspace/" + relative_dir,
             "versions: %s -> %s" % (first, second)]
    for title, key in (("изменены", "changed"), ("добавлены", "added"), ("удалены", "removed")):
        lines.append(title + ": " + (", ".join(difference[key]) or "нет"))
    if not difference["same_cases"]:
        return lines + ["decision: не сравнивается — разные наборы случаев (правило главы 13)", EVIDENCE]
    # Каждый снимок — папка конфигурации; eval на нём тот же, что у команды eval.
    outcomes = []
    for label in (first, second):
        folder = relative_dir + "/" + VERSIONS_DIR + "/" + label
        outcomes.append(_eval_cases(require_valid(read_my_agent(folder, workspace_root=workspace_root)),
                                    workspace_root))
    lines.append("cases: 11_evals.json совпадает | случаев: %d" % len(outcomes[0]))
    improved = regressions = 0
    for (case, _, before), (_, _, after) in zip(*outcomes):
        improved += not before and after
        regressions += before and not after
        lines.append("case %s: %s %s | %s %s" % (case["id"], first, "pass" if before else "fail",
                                                second, "pass" if after else "fail"))
    lines.append("improved: %d | regressions: %d" % (improved, regressions))
    if regressions:
        lines.append("decision: revert")
    elif improved:
        lines.append("decision: keep")
    else:
        lines.append("decision: keep — улучшение не наблюдается: покажи другое свидетельство (diff, trace)")
    return lines + [EVIDENCE]


def cmd_trace_last(*, workspace_root=WORKSPACE_ROOT):
    folder = resolve_workspace_path(TRACE_DIR, workspace_root=workspace_root)
    runs = sorted(folder.glob("run-*.jsonl")) if folder.is_dir() else []
    if not runs:
        return ["trace: нет записанных запусков — включи 12_trace.json (глава 12)"]
    relative = TRACE_DIR + "/" + runs[-1].name
    report = build_incident_report(load_trace(relative, workspace_root=workspace_root))
    lines = ["trace: workspace/" + relative, "terminal: " + report["terminal"],
             "tool_calls: " + str(report["tool_calls"]), "errors: " + str(report["errors"])]
    point = report["failure_point"]
    if point is None:
        return lines + ["failure_point: нет наблюдаемого отклонения"]
    place = [point["type"]] + ([point["call_id"], point["tool"]] if point["call_id"] else [])
    return lines + ["failure_point: " + " ".join(place), "root_cause: " + str(report["root_cause"])]


def skill_layers(relative_dir=DEFAULT_DIR, *, workspace_root=WORKSPACE_ROOT):
    """Три слоя skill ученика тем же загрузчиком главы 9 (для тестов и учителя)."""

    config = read_my_agent(relative_dir, workspace_root=workspace_root)
    skills = config["values"].get("09_skills")
    if skills is None:
        return []
    root = skills["root"]
    return [{"catalog": skill, "instructions": load_skill(root, skill["name"])["instructions"],
             "files": list_skill_files(root / skill["name"])} for skill in discover_skills(root)]


def _version(relative, action, labels):
    expected = {"save": 1, "list": 0, "compare": 2}[action]
    if len(labels) != expected:
        usage = {"save": "version save <метка>", "list": "version list",
                 "compare": "version compare <метка A> <метка B>"}[action]
        raise ConfigError("использование: python dezhurny.py " + usage)
    if action == "save":
        return cmd_version_save(relative, label=labels[0])
    if action == "list":
        return cmd_version_list(relative)
    return cmd_version_compare(relative, first=labels[0], second=labels[1])


def main(argv=None):
    parser = argparse.ArgumentParser(description="Конструктор «Дежурного»: my_agent/ → существующий harness.")
    commands = parser.add_subparsers(dest="command", required=True)
    for name, text in (("status", "что настроено в my_agent/, по главам"),
                       ("run", "запуск агента с настройками my_agent/"),
                       ("eval", "случаи ученика из 11_evals.json"),
                       ("trace", "последний trace запуска"),
                       ("candidate", "зафиксировать Release candidate: метка и отпечаток конфигурации"),
                       ("version", "снимки конфигурации в 13_versions/: save, list, compare")):
        command = commands.add_parser(name, help=text)
        command.add_argument("--dir", default="workspace/" + DEFAULT_DIR, help="папка my_agent внутри workspace/")
        if name == "status":
            command.add_argument("--json", action="store_true")
            command.add_argument("--chapter", type=int, help="только строка главы N")
        if name == "run":
            command.add_argument("--scenario", default="success", choices=REPLAY_SCENARIOS)
            command.add_argument("--model", default="replay", choices=("replay", "bridge"))
        if name == "trace":
            command.add_argument("--last", action="store_true", required=True)
        if name == "candidate":
            command.add_argument("--label", required=True)
        if name == "version":
            command.add_argument("action", choices=("save", "list", "compare"))
            command.add_argument("labels", nargs="*", metavar="метка")
    args = parser.parse_args(argv)
    try:
        relative = _relative(args.dir)
        if args.command == "status":
            lines = cmd_status(relative, as_json=args.json, chapter=args.chapter)
        elif args.command == "run":
            lines = cmd_run(relative, scenario=args.scenario, model=args.model)
        elif args.command == "eval":
            lines = cmd_eval(relative)
        elif args.command == "candidate":
            lines = cmd_candidate(relative, label=args.label)
        elif args.command == "version":
            lines = _version(relative, args.action, args.labels)
        else:
            lines = cmd_trace_last()
    except (ValueError, FileNotFoundError, OSError) as exc:
        parser.error(str(exc))
    for line in lines:
        print(line)
    return 0


if __name__ == "__main__":
    main()
