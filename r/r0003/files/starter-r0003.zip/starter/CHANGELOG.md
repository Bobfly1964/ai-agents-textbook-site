# Изменения

## 0.17.2 — 26.09.2026

docs/WORKPLACE_SETUP.md: убраны производственные заметки; код и golden не менялись. Основание — `reports/Вердикт_APPENDICES.md` §3 (Приложение А книги = этот файл, EC-28). Три последние строки («Цель совместимости 3.9+…», «Это не полноценный запуск на 3.9…», «Авторский гайд «Шаг 0» не найден…») заменены строкой «Нужен Python 3.9 или новее; комплект проверен на Python 3.12.».

## 0.17.1 — 26.09.2026

Правка C1 вердикта `reports/Вердикт_RETRO_TECH.md` (`ACCEPT_WITH_FIXES`):
`versions.build_manifest` больше не отказывает пустой конфигурации — снимок с
`files: {}` и отпечатком пустого набора, как `candidate` главы 17; `version save`
печатает `файлов: 0`. Тест `test_empty_config_is_a_snapshot` (снимок создаётся,
`compare` с ним — `добавлены: …` и `decision: не сравнивается — …`) вместо теста
отказа. Golden не менялись.

## 0.17.0 — 26.09.2026

Ретрофит глав 1–13 — реализация частей (а) и (б) по
`reports/Вердикт_PLAN_RETRO.md` (`GO_WITH_FIXES`, §3.2).

(а) Глава 13. `school_agent/versions.py`: `save_version` (копии файлов
`release_candidate.config_files` в `13_versions/<метка>/` и `manifest.json`
`{"label", "files", "digest"}` существующим `save_state`, манифест — последним;
та же метка и те же файлы — ничего не пишется, другие — отказ: снимок
неизменяем), `list_versions` (строковый порядок меток), `compare_versions`
(`changed`/`added`/`removed` по манифестам и `same_cases`),
`validate_versions_dir`. Хеш, отпечаток и формат метки — только из
`release_candidate`; времени в манифесте нет; модуль ничего не печатает.
Конструктор: строка 13 читается (`RESERVED` пуст), `status` —
`настроено: версий: N (метки) | version save/list/compare`, без папки —
`не настроено | version save сохраняет снимок конфигурации`, `configured: k/15`.
Сломанный снимок — ошибка строки 13 и остановка `run`/`eval` до цикла; текст
говорит, что делать (`… — удали папку снимка или сохрани заново под новой
меткой`; скопированный шаблон — `это шаблон, а не снимок …`). `dezhurny.py
version save <метка>` (отказ при ошибке любой строки, кроме 13 и 17) / `list` /
`compare <a> <b>`: разница файлов; при одном `11_evals.json` — eval на обоих
снимках (тот же код, что у `eval`, вынесен в `_eval_cases`), `improved`
(fail → pass), `regressions` (pass → fail), `decision: revert | keep | keep —
улучшение не наблюдается …`; при разных наборах — `не сравнивается`. Решение —
рекомендация, файлы не меняются. Данные: `workspace/ch13/cases/versions/`
(снимки `1.0.0`, `1.1.0` созданы командой `version save`; в `1.1.0` из
`07_tools.json` убран `validate_task_card`), `versions-other-cases/`; шаблон
`templates/13_versions/README.md`. Golden: четыре `ch13_dezhurny_*`;
`dezhurny_status_empty/example` — строка 13 и `k/15`. `run` без
`13_versions/` побайтно прежний; отпечаток Release candidate снимком не
меняется.

(б) Главы 1–12 без изменения кода: фикстуры `tests/fixtures/ch01|ch05|ch12`,
папки-примеры `workspace/my_agent/examples/ch08|ch09|ch10`, одиннадцать golden
`ch01|05|07|08|09|10|12_dezhurny_*` с фактического stdout.
`tests/test_retrofit_blocks.py` запускает команды блоков так, как
`verify_chapter.py`; `tests/test_versions.py` — контракт главы 13. Слепок 115
golden 0.16.0 и `state_store.py` побайтно; golden ретрофита
(`ch01–ch13_dezhurny_*`) исключены из слепков прежних глав.
Прочие изменения тестов: тест зарезервированной строки 13 заменён проверкой
чтения строки; счётчик `0/15`; `ErrorRowStopsRunTests` охватывает строку 13;
`test_what_is_fixed` — `13_versions/notes.md` теперь ошибка строки 13.

## 0.16.0 — 25.09.2026

Глава 17 — реализация до P2 по `reports/Вердикт_PLAN_главы_17.md`
(`GO_WITH_FIXES`, §3.2). `school_agent/release_candidate.py` — единственный
источник правил: `config_files` (файлы глав 1–16 и `09_skills/`; без
`10_state.json`, `13_versions/`, шаблонов, примеров и файла 17),
`digest` (SHA-256 по «путь + содержимое», `\r\n → \n`),
`build_release_candidate`, `validate_release_candidate` (ошибки списком,
первое расхождение называет файл). Модуль ничего не печатает и не пишет.
Конструктор: строка 17 `17_release_candidate.json`; `dezhurny.py candidate
--label L` фиксирует метку существующим `save_state` (та же метка и те же файлы
— файл не переписывается); `run` и `eval` печатают метку до цикла, остальное не
меняется; изменение, добавление или удаление файла после фиксации — строка
`ошибка` и остановка `run`/`eval` до цикла. Без файла вывод прежний. `status`:
строка 17 и `configured: k/14`. Данные: `workspace/ch17/cases/release-candidate/`
(шесть случаев eval, метка создана командой `candidate`), `release-stale/`
(`07_tools.json` расширен после фиксации), `release-invalid/` (`"ready": true`);
шаблон `17_release_candidate.json`. Шесть golden `ch17_*`;
`dezhurny_status_empty/example` — строка 17 и `k/14`.
`tests/test_release_candidate.py` — 16 тестов; слепок 109 прежних golden и
`state_store.py` побайтно. Прочие изменения тестов: счётчик `0/14`;
`ErrorRowStopsRunTests` охватывает строку 17.

## 0.15.0 — 25.09.2026

Глава 16 — реализация до P2 по `reports/Вердикт_PLAN_главы_16.md`
(`GO_WITH_FIXES`, §3.2). `school_agent/long_work.py` — единственный источник
правил: `validate_run_plan` (`max_sessions` 1–5, `checkpoint` внутри `drafts/`
— проверка текста пути, `owner`), `session_number`, `build_checkpoint` (поля
Handoff главы 10, `next_step` по терминалу, `sessions_used`, `last_terminal`,
`last_scenario`), `validate_architecture_handoff` (`owner`, `basis` fact /
heuristic / hypothesis / forecast, `fact` требует `evidence`, запрещённые поля и
secret-ключи). Модуль ничего не читает и не печатает. Конструктор:
`16_run_plan.json` снят с `RESERVED` (`read_run_plan_file` — единственный
читатель); `dezhurny.py run` с планом — одна Session: до `run_agent` checkpoint
проверяется существующими `load_state` + `validate_project_state` (невалидный —
exit 2), строка `session: N/M`; после `max_sessions` — `outer loop: стоп …`,
Inner loop не запускается, checkpoint не переписывается; после цикла —
`save_state` в путь плана и строка `handoff:` через существующий
`build_handoff`. Без файла вывод `run` прежний; `eval` план не читает. `status`:
строка 16 и `configured: k/13`. `long_work_demo.py`: `repeat` (одно
подтверждённое предложение дважды через существующий `apply_status_update` на
копии workspace — второй раз `already_applied`; учебная защита, не
exactly-once), `handoff --case analyzer|missing-owner` (фиксированная
последовательность существующих tools через dispatcher, без модели и сети).
Данные: случай `workspace/ch16/cases/long-work/` (`max_sessions: 2`,
`max_steps: 2` — каждая Session заканчивается `limit`),
`workspace/ch16/cases/architecture_missing_owner.json`, фикстуры
`tests/fixtures/ch16/`, шаблон `16_run_plan.json`. Восемь golden `ch16_*`;
`dezhurny_status_empty/example` — строка 16 и `k/13`. `tests/test_long_work_demo.py`
— 26 тестов; слепок 101 прежнего golden и `state_store.py` побайтно. Прочие
изменения тестов: зарезервированный файл — `13_versions/`; счётчик `0/13`;
`ErrorRowStopsRunTests` охватывает строку 16.

## 0.14.1 — 25.09.2026

Строка с ошибкой в `status` сообщает, что `run` не запустится; golden
`ch15_trust_invalid.txt`. Вердикт главы 15 (`ACCEPT_WITH_FIXES`, C1): для
строки в состоянии «ошибка» `dezhurny.py status` печатает последним полем «run
не запускается, пока файл не исправлен» вместо эффекта состояния «не
настроено» (для строки 15 тот читался как fail-open). `run` и `eval` уже
останавливались на любой строке с ошибкой (`require_valid`, exit 2) — поведение
не менялось. Тесты `ErrorRowStopsRunTests`: для каждой из 12 активных строк
испорченный файл → строка `status --chapter N` с новой формулировкой, `run` —
exit 2, stdout пуст, в stderr тот же текст ошибки. Прочие golden — побайтно
прежние.

## 0.14.0 — 24.09.2026

Глава 15 — реализация до P2 по `reports/Вердикт_PLAN_главы_15.md`
(`GO_WITH_FIXES`, §3.2). `school_agent/trust.py`: `validate_trust_config`
(`external_content: untrusted`; `skills` — решение аудита
`connect_minimal | isolate | reject`) и `connected_skills`. Конструктор:
`15_trust.json` активирован (`read_trust_file` — единственный читатель; имя
skill, которого нет в `09_skills`, — ошибка); `HarnessProfile.skill_names` —
в каталог skills модели попадают только подключённые; `run_agent` применяет это
вне напечатанных фрагментов (`_skill_catalog`, `_skill_root_for(…, profile)`);
`run` печатает `my_skills:` и `not connected: <имя> (<причина>)`; без файла
вывод прежний. `dezhurny.py status --chapter N` — шапка и строка главы N.
`school_agent/trust_audit.py` + `trust_demo.py`: `document --case task-901`
(карточка читается существующим `Tools.read_task_cards`; каждое требование
авторской разметки `workspace/ch15/cases/task-901.annotations.json` проверяется
вызовом гейта — `call_tool` → `unknown_tool`, схема `read_task_cards` → «лишнее
поле path», `approval_allowed(None)` → gate закрыт), `replay` (существующий
`run_replay_scenario("injection")`), `audit skill --sample
project-status|project-sync|suspicious-skill`, `audit mcp --sample
mock-mcp-server` — статический аудит по фиксированным признакам, scripts
читаются как текст и не запускаются. Данные: разметка `task-901`, случай
`workspace/ch15/cases/external-skill/` (копия `project-sync` побайтно — тест),
фикстуры `tests/fixtures/ch15/`, шаблон `15_trust.json`. Девять golden
`ch15_*`, `tests/test_trust_demo.py` (23 теста), всего 354. Глава 14 — errata
v1.2 (`reports/PATCH_CH14_v1.2.md`): `status --chapter 14`, golden
`ch14_dezhurny_status.txt` переснят в этом режиме. Golden конструктора
`dezhurny_status_empty/example` — строка главы 15 и `configured: k/12`.
`untrusted_samples/` и `ch04_mcp_map.txt` не менялись.

## 0.13.1 — 24.09.2026

По вердикту главы 14 (`ACCEPT_WITH_FIXES`, C1): approval gate проверяет политику
до запроса решения человека. `permissions_demo.cmd_approval` при закрытом gate
(`status_update: deny` или нет файла политики) не пишет `approval_requested` /
`approval_decision`, не вызывает `apply_status_update` и печатает
`human_decision: не запрашивалось — approval gate закрыт политикой`,
`apply_status_update: not called | reason: …`, `approval_events: 0`. Открытый gate —
без изменений. Golden `ch14_approval_policy_deny.txt` (три строки); прочие golden —
побайтно прежние. Тест: при закрытом gate `TraceRecorder` не создаётся и
`apply_status_update` не вызывается (оба случая политики). Всего 331 тест.

## 0.13.0 — 24.09.2026

Глава 14 — реализация до P2 по `reports/Вердикт_PLAN_главы_14.md`
(`GO_WITH_FIXES`, §3.2) и `reports/PLAN_CH14_v1.0.md` §19. Новый модуль
`school_agent/permissions.py` — единственный источник правил:
`validate_permissions_config` (ровно поля `default: deny`,
`task_cards: read_only`, `status_update: approval_required | deny`; любое иное
значение `status_update` — «автоматическое применение изменения состояния
запрещено») и `approval_allowed` (нет политики → gate закрыт, `deny` → закрыт,
иначе — только после решения человека). `permissions_demo.py`: `policy --dir`,
`approval --dir --decision approve|deny [--case fresh|card-changed]` — proposal
создаёт существующий `Tools.propose_status_update`, применяет существующий
`apply_status_update` и только при открытом gate; всё во временной копии
workspace; печатаются before/after, reason, `operation_id`, `approval_events`;
события `approval_requested` (harness) и `approval_decision` (human) пишет
существующий `TraceRecorder`. `trace_analysis.count_approval_events` — правило
счёта вынесено из `summarize_trace` (поведение прежнее).

Конструктор: `14_permissions.json` активирован (читатель
`read_permissions_file`), строка status и её эффект зависят от
`approval_allowed`; `dezhurny.py run` печатает `permissions:` только при
настроенной политике, а после `propose_status_update` — `proposal: … |
operation_id`, `approval: required | gate closed — …`, `applied: no`;
`apply_status_update` из `dezhurny.py` не вызывается никогда. Replay-сценарий
`status_update` (один `propose_status_update` для `task-002`, `synthetic_script`),
`config.SCENARIOS["status_update"] = "tasks"`; прежние сценарии побайтно.
Данные: `tests/fixtures/ch14/14_permissions.json`,
`workspace/ch14/cases/too-broad/`, `workspace/ch14/cases/status-deny/`,
шаблон и пример 14 в `workspace/my_agent/`. `tools/verify_chapter.py`
восстанавливает `workspace/my_agent/` побайтно после главы. Восемь golden
`ch14_*`, `tests/test_permissions_demo.py` (23 теста); в
`tests/golden_dezhurny/` изменены ровно строка главы 14 и `configured: k/11` в
двух файлах status (вердикт, MINOR 6). Прежние 84 golden `tests/golden/` —
без изменений. Всего 330 тестов.

## 0.12.1 — 24.09.2026

Приёмка EC-24 (`reports/Вердикт_EC-16.md`, `ACCEPT_WITH_FIXES`): номер EC-24 в
документах (прежнее обозначение — «EC-16»); строка `13_versions` в `status` —
«формат — при ретрофите главы 13»; форма числа «пункт/пункта/пунктов»
(`dezhurny._plural`); `_skill_root_for` проверяет имя по `NAME_PATTERN`
загрузчика главы 9 до обращения к диску; golden конструктора: две строки в двух
файлах (`dezhurny_status_empty.txt` — строка главы 13;
`dezhurny_status_example.txt` — строки глав 5 и 13). Два новых теста, всего 307.
Глава 12 — errata v1.3 (`reports/PATCH_CH12_v1.3.md`).

## 0.12.0 — 24.09.2026

EC-24 — конструктор «Дежурного» (в документах 24.09 — «EC-16»; `reports/EC-16_Конструктор_Дежурного_PLAN.md`),
вне цикла глав. Ученик настраивает папку `workspace/my_agent/`, а
`dezhurny.py` (`status [--json]`, `run [--scenario] [--model replay|bridge]`,
`eval`, `trace --last`; у всех `--dir workspace/…`) запускает существующий
harness с этими настройками. Новый модуль `school_agent/my_agent_config.py`:
`read_my_agent` (строки status: настроено / не настроено (глава N) /
зарезервировано / ошибка — с сообщением по-русски), `require_valid`,
`build_profile` (`HarnessProfile`: allowlist 07, описание tool 08, корень skills
09; `None`, если 07–09 ничего не меняют), `contract_check`, `check_save` (те же
три отказа, что у гейта главы 3; область записи — только внутри `drafts/`).

`run_agent` получил необязательный параметр `profile=None`: при `None` цикл,
trace и все прежние golden — без изменений (тест сравнивает payload событий).
С профилем: tool вне allowlist ученика отклоняется harness до диспетчера
(`tool_rejected`, код `not_in_profile_allowlist`, терминал `error`; анализ
главы 12 находит это как failure point); каталог tools для модели сужается и
дополняется описанием tool ученика (`access: not-executable`); каталог skills
дополняется skills ученика, `load_skill`/`read_skill_resource` ищут имя по
корням. `dispatcher.py` не менялся. Код `08_my_tool.py` не исполняется —
имя и докстринг читаются через `ast`. Состояние (10) пишет существующий
`save_state` в `my_agent/10_state.json`, trace (12) — в
`workspace/traces/dezhurny/run-NNN.jsonl`. Файлы глав 13–16 зарезервированы.

Данные: `workspace/my_agent/README.md`, `templates/` (10 шаблонов) и
`examples/full|limit2|denied|tools`. Шесть golden в отдельной папке
`tests/golden_dezhurny/` (прежние тесты-слепки считают все файлы
`tests/golden/`), `tests/test_dezhurny.py` (34 теста, всего 305). Прежние 84
golden не менялись (слепок в новом тесте). Глава 12 — errata v1.2
(`reports/PATCH_CH12_v1.2.md`): напечатанный заголовок `run_agent` с
`profile=None` и абзац о параметре.

## 0.11.0 — 24.09.2026

Глава 13 (PLAN — раздел 0 кандидата v1.0, §0.11 «нужно добавить»):
`change_demo.py` — `proposal <путь>`, `diff <до> <после>`, `eval <Version>
--cases <набор>`, `compare <до> <после> --cases <набор>`. Всё только читает:
скрипты skill не запускаются, runtime `skills/project-status/` не
перезаписывается, Rollback не выполняется — `compare` печатает `keep` или
`revert` и `rollback_to`. Строки `runtime_skill_changed` и `files_changed` —
наблюдение по SHA-256 файлов до и после команды. Новый модуль
`school_agent/versioning.py`: `review_change_proposal` (обязательные поля;
`status` только `proposed`, `new_norm` всегда ложен; `source_eval_case` из
того же набора; `root_cause` берётся из существующего
`build_incident_report` по Trace главы 12 и должен совпасть с
`expected_root_cause`), `diff_skill_versions` (строки `SKILL.md`, внутри
замены попарно «было → стало»; структуру обеих Version проверяет
существующий `load_skill`), `load_version_cases`, `run_version_cases`
(детерминированная rubric над текстом процедуры: случай проходит, если одна
строка инструкций содержит все фрагменты `line_contains`; повреждённая
Version — `accepted: false` без частичного счёта), `compare_version_results`
(Regression — только pass → fail; разные `eval_set` или разные наборы
случаев — `VersioningError`; `keep` только при исправленном target_case и
нуле Regression), `snapshot_files`. Метка Version — имя каталога над
каталогом skill (`<метка>/<имя skill>/SKILL.md`); решение из имени не
выводится (тест). Данные: `workspace/ch13/version_cases.json`,
`change_proposals/validate-task-id.json`, Version `1.0.0`,
`1.1.0-candidate`, `1.1.0-good` и `cases/broken-version/` без `SKILL.md`.
Шесть golden `ch13_*` и `tests/test_change_demo.py` (29 тестов, всего 271).
Слепок golden в `tests/test_trace_demo.py` не включает эталоны глав 13+
(фильтр `ch1[3-9]_`, как в тесте главы 11); сами 78 эталонов глав 1–12 не
менялись. Код глав 1–12 не менялся. Маркер `v0.11.0-ch13` не создан:
комплект не является Git-репозиторием.

## 0.10.0 — 23.09.2026

Глава 12 (PLAN — раздел 0 кандидата v1.0, §0.10 «нужно добавить»):
`trace_demo.py` — `record --scenario <имя> --out traces/<…>`, `show <путь>`,
`analyze <путь>`. Второго agent loop и второй записи журнала нет: `record`
вызывает существующий `run_replay_scenario`, а события пишет существующий
`TraceRecorder` внутри `run_agent`; границы пути и запрет перезаписи — тоже
существующие. Новый модуль `school_agent/trace_analysis.py` только читает:
`load_trace` (JSONL внутри workspace; повреждённая строка, событие без
обязательных полей, observation без запроса, потерянные `run_started` или
`run_finished` → `TraceFormatError`), `summarize_trace`, `find_failure_point`
(при `unknown_tool` точка отклонения — `tool_requested`, иначе
`tool_observation`), `build_incident_report` (terminal, счётчики,
failure_point, root_cause из кода ошибки observation, `evidence_event_id`).
Данные: `workspace/ch12/replay/trace_cases.json` (авторский сценарий,
`synthetic_script`) и снятые из него фактическим `TraceRecorder` учебные
traces `workspace/ch12/cases/wrong_tool.jsonl`, `invalid_arguments.jsonl`,
`tool_exception.jsonl` — один tool call, одна ошибка, терминал `error` в
каждом, но три разных failure point. Шесть golden и
`tests/test_trace_demo.py` (23 теста, всего 242). `tools/verify_chapter.py`
удаляет ученические файлы не после каждой команды, а после всей главы (в
главе 12 `show` читает то, что записал `record`), и чистит также
`workspace/traces/`. Код глав 1–11 не менялся. Маркер `v0.10.0-ch12` не
создан: комплект не является Git-репозиторием.

## 0.9.2 — 23.09.2026

По вердикту главы 11 (`ACCEPT_WITH_FIXES`, C1): `eval_main(argv=None)` в
`school_agent/presentation.py` принимает флаг `--summary` — три строки вместо
полного отчёта. Строки вычисляются из того же результата `run_eval_cases()`
(`harness: {passed}/{total} passed`; `model_behavior: {status}
(verified_sessions: {n}; scripted: {число случаев со status scripted},
excluded from scoring)`; `publication_ready: {true|false}` и блокеры в
скобках, при пустом списке — без скобок); констант в выводе нет. Без флага
stdout прежний, golden `ch11_eval_runner.txt` не изменился. Добавлен golden
`tests/golden/ch11_eval_summary.txt`; в `tests/test_eval_runner.py` — пять
новых тестов (stdout `--summary` = golden и ровно три строки; флаг меняет
только форму того же результата; `passed: 5` даёт `5/6` и код выхода 1;
`scripted` считается по случаям; без блокеров скобок нет), всего 17 тестов
главы и 219 в комплекте. Слепок 70 golden глав 1–10 не менялся. C3:
`tools/export_author_snapshots.py` печатает `eval_runner.py` и
`workspace/evals/test_cases.json`, а контрактные тесты среза включают
`test_eval_runner.py` и `test_evals.py`.

## 0.9.1 — 23.09.2026

Глава 11 (PLAN — раздел 0 кандидата v1.0, §0.6 «нужно добавить»). Кода
приложения глава не меняет: `eval_runner.py`, `run_eval_cases()` и данные
`workspace/evals/` уже существовали, поэтому новых публичных функций и
второго источника случаев не появилось. Добавлены golden
`tests/golden/ch11_eval_runner.txt` (фактический stdout `python
eval_runner.py`, 71 строка) и `tests/test_eval_runner.py` — 12 тестов:
stdout совпадает с golden и с `run_eval_cases()`; harness считается на своих
случаях; общей доли над двумя слоями нет (`pass_rate`, `passed`, `total`,
`score`, `percent` отсутствуют и в корне, и в `model_behavior`); scripted
`model_behavior` помечен `excluded` и `model_quality_verified: false`;
отсутствие живых свидетельств остаётся `not_evaluated`, а не нулём;
`publication_ready` ложен при двух внешних блокерах; `test_cases.json`
указывает на те же два файла, которые читает `school_agent/evals.py`, и сам
случаев не содержит; у каждого случая есть наблюдаемое ожидание
(`invariant`, `expected_terminal`, `real_run_acceptance`); случай без
ожидаемого поведения поднимает `ValueError`, а не считается пройденным.
Слепок 70 golden глав 1–10. Код глав 1–10 не менялся. Маркер `v0.9.1-ch11`
не создан: комплект не является Git-репозиторием.

## 0.9.0 — 22.09.2026

Глава 10 (PLAN — раздел 0 кандидата v1.0, §0.7 «нужно добавить»):
`state_demo.py` — `classify`, `resume`, `checkpoint --out drafts/…`, `handoff`.
Второго хранилища нет: чтение и запись через существующие
`state_store.load_state`/`save_state` (имена из PLAN `load_project_state`/
`save_project_state` не вводились — по PLAN §0.7 п. 2 API синхронизирован с
фактом). В `state_store.py` добавлены `validate_project_state` и
`build_handoff`; признаки секретного поля берутся из существующего
`trace.SENSITIVE_PARTS`. `checkpoint` пишет только внутри
`workspace/drafts/` (проверка по разрешённому пути, `drafts/../…`
отклоняется) и проверяет, что карточки `tasks/` не изменились. Данные:
`workspace/ch10/cases/` (готовое, без `next_step`, с полем `secret`),
`workspace/ch10/templates/project_state.json`, `workspace/ch10/storage_map.json`.
Шесть golden и `tests/test_state_demo.py` (18 тестов, всего 202).
`tools/verify_chapter.py` удаляет файлы, которые команда главы создала в
`workspace/drafts/`. Код глав 1–9 не менялся. Маркер `v0.9.0-ch10` не создан:
комплект не является Git-репозиторием.

## 0.8.0 — 22.09.2026

Глава 9 (вердикт по PLAN v1.0, `GO_WITH_FIXES`, §3.2): `skill_demo.py` —
подкоманды `catalog`, `load <name>`, `resource <name> <path>`,
`check <workspace-dir>`, `replay` поверх единственного загрузчика
`school_agent/skill_loader.py` и `run_replay_scenario("success")`; второго
разбора `SKILL.md` нет, `scripts/` только перечисляются и не запускаются;
`check` принимает каталог только внутри `workspace/` через
`resolve_workspace_path`. Прежний вывод без подкоманд
(`presentation.skill_main`) больше не вызывается из `skill_demo.py`; сама
функция не удалена. C1: из frontmatter `skills/project-status/SKILL.md`
убран устаревший номер версии в `compatibility`. Данные:
`workspace/ch09/cases/` (четыре случая, включая безвредный маркер
`script-present/scripts/check.py`) и `workspace/ch09/templates/` (шаблоны
проектного и личного skill). Восемь golden и `tests/test_skill_demo.py`
(22 теста, всего 184). `tools/verify_chapter.py` сверяет листинги и в блоках
`markdown`, ограждение может быть длиннее ``` (для файлов, содержащих ```).
Код глав 1–8 не менялся. Маркер `v0.8.0-ch09` не создан: комплект не
является Git-репозиторием.

## 0.7.1 — 22.09.2026

По вердикту главы 8 (`ACCEPT_WITH_FIXES`, C1–C3): описания каталога моста
`data/tool_catalog.json` синхронизированы с паспортами главы 8
(`workspace/ch08/tool_passports.json`) — модель в bridge видит те же
«когда / когда не», что проверяет глава; `version` каталога → `0.7.1`,
`access` и `input_schema_ref` не менялись. Тест равенства
`test_catalog_descriptions_match_passports` (всего 162). Окончания строк
CRLF → LF в `tool_quality_demo.py` и `school_agent/tool_quality.py`.
Код и golden не менялись.

## 0.7.0 — 22.09.2026

Глава 8 (PLAN — раздел 0 кандидата v1.0, §0.4 «нужно добавить»):
`tool_quality_demo.py` (`passport <tool>`, `route --case <...>`, `suite`) и
`school_agent/tool_quality.py` — `build_tool_passport`, `check_route_case`,
`run_quality_suite` (плюс `load_catalog`, `select_tool`). Учебный выбор —
прозрачное правило: основы слов запроса сравниваются с «Используй для …»
и «Не используй для …» из description; это не модель и не model behavior.
Error case проверяет существующий `validate_tool_arguments`. Данные:
`workspace/ch08/tool_passports.json` (без schema — источник один,
`data/tool_schemas.json`), `workspace/ch08/cases.json`. Четыре golden и
`tests/test_tool_quality_demo.py` (18 тестов, всего 161). Тесты-слепки глав
6 и 7 теперь исключают эталоны любых следующих глав (`ch07+`/`ch08+`), а не
перечисляют их. Код глав 1–7 и `data/tool_catalog.json` не менялись.
Маркер `v0.7.0-ch08` не создан: комплект не является Git-репозиторием.

## 0.6.0 — 22.09.2026

Глава 7 (вердикт по PLAN v1.0, GO_WITH_FIXES, §3.2): `dispatcher_demo.py` —
две линзы на уже существующий механизм. `case <allowed|unknown-tool|
invalid-arguments|tool-exception>` — один tool call через `call_tool`;
`run <two-calls|stop-after-decision|missing-file>` — пакет из replay через
`run_agent`, печать событий его журнала (`tool_requested`,
`tool_observation`, `run_finished`) и строки `not executed` для остатка
пакета. Своей таблицы имён, проверки arguments, политики решения и журнала
в демонстрации нет. Данные: `workspace/ch07/replay/dispatcher_cases.json`
(`synthetic_script`), `workspace/ch07/bridge_passport_template.md`.
Восемь golden и `tests/test_dispatcher_demo.py` (20 тестов, всего 143).
В `tests/test_tool_call_demo.py` счёт эталонов главы 6 исключает `ch07_*`;
слепок 44 эталонов глав 1–6 — в новом тесте. Код глав 1–6 не менялся.
Маркер `v0.6.0-ch07` не создан: комплект не является Git-репозиторием.

## 0.5.1 — 21.09.2026

Два инвариант-теста главы 6: контракт replay-файла
(`workspace/ch06/replay/read_task_cards.json` проходит `ReplayModel` и несёт
честный `provenance.kind = synthetic_script`) и единственный источник схем
(`workspace/ch06/` не содержит собственных `*.schema.json`, `tool_call_demo`
использует те же объекты `TOOL_SCHEMAS`/`CARD_SCHEMA`, что и `validation.py`).
Код и golden не менялись.

## 0.5.0 — 21.09.2026

Глава 6: `tool_call_demo.py` — пять режимов (`show`, `execute`, `check`,
`check-card`, `schema`) поверх уже существующих `call_tool`,
`validate_tool_arguments`, схем `data/tool_schemas.json`. Новая функция
`validation.validate_task_card_schema(card)` — обёртка над существующим
валидатором для карточки задачи. Двенадцать новых golden и
`tests/test_tool_call_demo.py`. Код глав 1–5 не менялся.

## 0.4.2 — 21.09.2026

`workspace/task_spec.json` приведён к паспорту главы 5 (результат
`summary`/`blocked_tasks`/`next_step` по решению главы 4; поля `goal,
inputs, result, done_when, unknowns, forbidden_actions`). Код, тесты и
golden не менялись; 101 тест OK.

## 0.4.1 — 21.09.2026

Флаги `network` и `trust` в `list_mcp_resources` — утверждение самой
демонстрации (`NETWORK_FLAG`/`TRUST_FLAG` в `school_agent/mechanism_support.py`),
из карточки `server.json` больше не читаются: поле внутри данных не может
назначать доверие (EC-05). Ключи `network`/`trust` удалены из
`workspace/ch04/mcp/server.json`, а новый тест подаёт карточку с
`network: used` и `trust: proven` и проверяет, что печатаемые флаги не
меняются.

`scripts/verify_release.py`: дочерний `unittest -v` запускается с
`env=dict(os.environ, PYTHONIOENCODING="utf-8")` — иначе на консоли cp1251
лог вложенного прогона терялся (`UnicodeDecodeError` в reader-thread), хотя
итоговый вердикт `all_passed` оставался верным.

## 0.4.0 — 20.09.2026, глава 4 CANDIDATE v1.0

Аддитивно добавлены `mechanisms_demo.py` и `school_agent/mechanism_support.py`
по разделу 18.2 PLAN `CH04 v1.1`. CLI печатает пять нейтральных фрагментов,
сверяет классификацию, показывает локальную mock-карту MCP и читает ровно один
слой Agent Skill за запуск. Файлы `loop_demo.py`, `harness_demo.py`,
`access_demo.py`, `school_agent/lesson_support.py` и 22 golden глав 1–3 не
изменялись.

Слои B7–B9 используют существующий `school_agent/skill_loader.py`; второго
загрузчика skill в starter нет, и это закреплено тестом. Учебный mock-skill
`status-summary` лежит в отдельном корне `workspace/ch04/skills/` и не
смешивается с каталогом главы 9.

Фрагменты печатаются в форме самих артефактов: служебные поля, прямо
называющие механизм, в вывод не попадают, иначе классификация свелась бы к
чтению подписи. Эталонный ключ лежит в `tests/fixtures/ch04/`, а не в рабочей
папке ученика; заполненный `workspace/drafts/ch04_choices.txt` не
поставляется, и команда главы честно печатает `результат: не принят`, пока
ученик не создал файл. Добавлен `workspace/drafts/README.md`.

Добавлены 10 golden и 21 тест, всего 100 тестов. Неполный вход не превращается
в частичный балл; путь к файлу ответов вне разрешённых корней отклоняется
существующим `resolve_workspace_path`; тест карты MCP запрещает сетевой вызов.
`verify_release.py` — PASS. Планируемый маркер `v0.4.0-ch04` не создан:
комплект не является Git-репозиторием.

## Канонический релиз главы 3 — 06.09.2026

Глава 3 принята как `CANONICAL v1.2`. По финальному решению редактора в текст
главы внесены четыре точечных уточнения о трёх проверках доступа; код, API,
тесты, golden и версия starter 0.3.1 не изменялись.

Маркер `v0.3.1-ch03` отложен: поставленный starter не является
Git-репозиторием. `publication_ready: false` сохраняется из-за классного пилота
и подтверждённого живого свидетельства модели.

## 0.3.1 — 06.09.2026, глава 3 CANDIDATE v1.1

Адресно закрыт возврат по `CANDIDATE v1.0`. Разрешённая операция `write`
теперь дополнительно ограничена префиксом `workspace/drafts/`; любой другой
путь получает `denied/path_not_writable` до вызова `write_text`. Добавлены
human/JSON-golden новой причины и тест неизменности `task-003.json` при
временно включённом `write`.

Вывод `harness_demo.py --show-parts` честно маркирует permissions как отдельное
демо главы 3, ещё не подключённое к runtime учебного цикла. PLAN v1.1,
`loop_demo.py`, `school_agent/lesson_support.py` и десять golden глав 1–2 не
изменены. Планируемый маркер — `v0.3.1-ch03`; фактический тег не создан.

## 0.3.0 — 06.09.2026, глава 3 CANDIDATE

Аддитивно добавлены `harness_demo.py` для выделения оркестрации знакомого
цикла и `access_demo.py` для фактической проверки пути и операции. Файлы
`loop_demo.py`, `school_agent/lesson_support.py` и десять прежних golden не
изменены. `run_harness` проверен на равенство `run_loop` во всех семи
сценариях.

По умолчанию access-демо разрешает чтение и технически останавливает запись
до открытия файла. Ветка записи существует и проверена отдельно: тест
временно расширяет `ALLOWED_OPERATIONS` и записывает только служебный файл во
временной папке. Человекочитаемый вывод используется по умолчанию, JSON — по
`--json`; JSON-поле `os_sandbox_proven` не выдаётся за доказательство.

Добавлены 10 golden и 10 тестов, всего 78 тестов. `verify_release.py` — PASS,
`eval_runner.py` сохраняет `publication_ready: false`: классный пилот и
подтверждённое живое свидетельство остаются внешними блокерами. Планируемый
маркер `v0.3.0-ch03` не создан, потому что комплект не является Git-репозиторием.

## Канонический релиз глав 1–2 — 05.09.2026

Главы 1–2 приняты как `CANONICAL v1.2`, регламент 05 — как
`CANONICAL v1.1`. Из издательских блокеров сняты ожидание редакторской
приёмки глав и ожидание решения владельца по регламенту. Остаются классный
пилот и подтверждённое живое свидетельство; поэтому
`publication_ready: false`.

Плановый маркер `v0.2.1-ch02` не создан: поставленный starter не является
Git-репозиторием. Маркер отложен до появления репозитория владельца.

## Документационная правка после заключения № 3

В `WORKPLACE_SETUP.md` команды согласованы по платформам: Windows использует
`py -3`, macOS/Linux — `python3`. Код, API, golden и версия 0.2.1 не менялись.

## 0.2.1 — 05.09.2026, спринт 2

Исправлен единственный заявленный дефект: `decide(state)` больше не читает
имя сценария. Пустой завершённый поиск всегда даёт `needs_input`.
`limit` использует незавершённый постраничный поиск, который действительно
разрешает продолжение. Единственный владелец предела — `decide`; условие
цикла упрощено до `while not state["done"]`.

Добавлены инвариант одинакового решения при одинаковых observation/счётчиках
и golden для `no_matches` и `missing_file`. Остальная логика 0.2.0
сохранена.

После получения фактических глав 1–2 и регламента 05 источниковые блокеры в
eval-метаданных были заменены на ворота редакторской/владельческой приёмки;
они закрыты каноническим релизом 05.09.2026.

## 0.2.0 — 05.09.2026, технический кандидат

B1–B4: строковый ложный stub, простой CLI, JSON по флагу, while/update/decide
в том же действии, pathless read, доверие вне карточки.
M1–M8: model requests для progressive disclosure, initiator, раздельные evals,
единые error/needs_input, без fake timeout, простые entrypoints,
правдоподобный аудит, 4 статуса/дубли/ошибка, tools по ссылке.
Добавлены manual bridge, строгий response parser, бюджеты и golden.
Approval: целостность предложения, status-only, stale before, идемпотентность.
Граница symlink проверена для карточек и SKILL.md.
Личный skill: три проверки; расширены инструкции редактора/терминала.

В новом выпуске старые task-003-a/-b и самоаннотированный suspicious-skill
заменены. В исходном пакете 0.1.0 сохранены; восстановление возможно.
Приёмка глав, реальный model-run и классный пилот не заявляются выполненными.

## 0.1.0

Исходная техническая база, принятая редактором. В этом спринте не менялась.
