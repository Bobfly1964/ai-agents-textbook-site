"""Глава 15. Prompt injection и недоверенные подключения: учебные отчёты, только чтение.

``document`` показывает заражённую карточку как данные и для каждого требования
из неё — ответ уже построенного гейта. ``replay`` — существующий авторский
сценарий ``injection`` через тот же agent loop. ``audit skill`` и ``audit mcp`` —
статический аудит учебных образцов: scripts не запускаются, сеть не
используется, и чистый отчёт не доказывает безопасность.
"""

import argparse

from school_agent.agent import run_replay_scenario
from school_agent.trust_audit import (
    DOCUMENT_CASES, MCP_SAMPLES, SKILL_SAMPLES,
    audit_mcp_sample, audit_skill_sample, audit_untrusted_document,
)

ORIGIN_NOTE = "авторский сценарий, не запись модели"
LIMIT = "static audit: not a safety proof"


def cmd_document(case):
    report = audit_untrusted_document(case)
    provenance = report["provenance"]
    lines = ["document: workspace/" + report["card"],
             "trust: " + provenance["trust"] + " — assigned by " + provenance["assigned_by"],
             "content: untrusted_content (поле notes — данные карточки)",
             "treated_as_instruction: " + ("yes" if report["treated_as_instruction"] else "no")]
    for number, item in enumerate(report["requirements"], 1):
        lines.append("requirement %d: «%s» → %s → %s" % (number, item["fragment"], item["gate"], item["result"]))
    return lines + ["network used: no",
                    "annotations: authored — программа не распознаёт атаки"]


def cmd_replay():
    result = run_replay_scenario("injection")
    loaded = any(event["type"] == "skill_loaded" for event in result["trace"])
    return ["scenario: injection",
            "mode: " + result["adapter"] + " — " + ORIGIN_NOTE,
            "evidence: " + result["evidence_kind"],
            "skill_loaded: " + ("yes" if loaded else "no"),
            "executed_tools: " + ", ".join(result["executed_tools"]),
            "terminal: " + result["terminal"],
            "model_quality_verified: " + ("true" if result["model_quality_verified"] else "false"),
            "граница: успех авторского replay не доказывает устойчивость живой модели"]


def cmd_audit_skill(sample):
    report = audit_skill_sample(sample)
    lines = ["sample: " + sample, "path: " + report["path"], "provenance: " + report["provenance"]]
    if report["skill_md"]:
        lines += ["SKILL.md: found | name " + report["name"], "compatibility: " + report["compatibility"]]
    else:
        lines.append("SKILL.md: not found — " + report["format_error"])
    lines += ["files: " + ", ".join(report["files"]),
              "scripts: %d | scripts executed: no" % len(report["scripts"])]
    for finding in report["findings"]:
        lines.append("finding: %s:%d | %s | %s" % (finding["file"], finding["line"], finding["category"],
                                                   finding["text"]))
    if not report["findings"]:
        lines.append("finding: нет по признакам рубрики")
    return lines + ["network used: no",
                    "decision: " + report["decision"] + " — " + "; ".join(report["because"]),
                    LIMIT]


def cmd_audit_mcp(sample):
    report = audit_mcp_sample(sample)
    lines = ["sample: " + sample,
             "card: " + report["card"] + " | kind " + report["kind"] + " | server_name " + str(report["server_name"]),
             "provenance, заявлено карточкой: " + report["declared_provenance"],
             "provenance, назначено harness по каналу: " + report["provenance"]]
    for item in report["permissions"]:
        lines.append("permission: " + item["scope"] + " — " + ("нужно для чтения карточек" if item["needed"]
                                                              else "лишнее: шире минимального набора"))
    for item in report["tools"]:
        lines.append("declared_tool: " + item["name"] + " — " + ("есть в allowlist диспетчера" if item["in_allowlist"]
                                                                else "нет в allowlist диспетчера (глава 7)"))
    return lines + ["network used: no",
                    "protocol != trust",
                    "decision: %s — лишних permission scope: %d; tools вне allowlist: %d" % (
                        report["decision"], len(report["extra"]), len(report["outside"])),
                    LIMIT]


def main(argv=None):
    parser = argparse.ArgumentParser(description="Недоверенное содержимое и внешние компоненты главы 15.")
    commands = parser.add_subparsers(dest="command", required=True)
    document = commands.add_parser("document", help="карточка как данные и гейты для её требований")
    document.add_argument("--case", required=True, choices=sorted(DOCUMENT_CASES))
    commands.add_parser("replay", help="авторский сценарий injection через существующий harness")
    audit = commands.add_parser("audit", help="статический аудит учебного образца")
    kinds = audit.add_subparsers(dest="kind", required=True)
    kinds.add_parser("skill").add_argument("--sample", required=True, choices=sorted(SKILL_SAMPLES))
    kinds.add_parser("mcp").add_argument("--sample", required=True, choices=sorted(MCP_SAMPLES))
    args = parser.parse_args(argv)
    try:
        if args.command == "document":
            lines = cmd_document(args.case)
        elif args.command == "replay":
            lines = cmd_replay()
        elif args.kind == "skill":
            lines = cmd_audit_skill(args.sample)
        else:
            lines = cmd_audit_mcp(args.sample)
    except (ValueError, FileNotFoundError, OSError) as exc:
        parser.error(str(exc))
    for line in lines:
        print(line)
    return 0


if __name__ == "__main__":
    main()
