# my_agent — твой «Дежурный»

Здесь лежат настройки твоего агента. Код harness ты не пишешь: он уже есть в
`school_agent/`. Ты кладёшь сюда файлы глав, и `python dezhurny.py run`
наблюдаемо меняет поведение.

Порядок: скопируй нужный файл из `templates/` в эту папку, заполни его, затем
запусти из корня starter:

```text
python dezhurny.py status
python dezhurny.py run
```

`status` покажет, какая строка стала «настроено», а `run` — что изменилось.
`python dezhurny.py status --chapter N` печатает только строку главы N.
Любой файл можно не заводить: тогда действует значение по умолчанию.

| Файл | Глава | Что меняет |
|---|---|---|
| `01_goal.md` | 1 | заголовок запуска цитирует первую строку цели |
| `02_stop_policy.json` | 2 | предел шагов и повторов |
| `03_workspace_policy.json` | 3 | куда harness может сохранить черновик |
| `05_task_contract.md` | 5 | проверка результата по разделу «Готово, когда» |
| `07_tools.json` | 7 | какие tools разрешены; остальные отклоняются |
| `08_my_tool.py` | 8 | описание твоего tool в каталоге (код не исполняется) |
| `09_skills/<имя>/SKILL.md` | 9 | твой skill в каталоге skills |
| `10_state.json` | 10 | создай файл с `{}` — harness будет помнить прошлый запуск |
| `11_evals.json` | 11 | твои случаи для `python dezhurny.py eval` |
| `12_trace.json` | 12 | `{"enabled": true}` — trace каждого запуска, `python dezhurny.py trace --last` |
| `14_permissions.json` | 14 | без файла approval gate закрыт; `status_update: approval_required` — изменение статуса только после решения человека |
| `15_trust.json` | 15 | решение аудита по skills из `09_skills/`: в каталог модели попадают только `connect_minimal` |
| `16_run_plan.json` | 16 | план долгой работы: лимит Session, checkpoint, Owner; `run` = Session |
| `17_release_candidate.json` | 17 | метка Release candidate и отпечаток файлов конфигурации; **не копируй шаблон — выполни `python dezhurny.py candidate --label festival-rc1`**; после изменения любого файла метка недействительна, и `run` не запускается |
| `13_versions/` | 13 | снимки конфигурации; **не создавай руками — выполни `python dezhurny.py version save 1.0.0`**; `version compare 1.0.0 1.1.0` сравнивает два снимка по одним и тем же случаям `11_evals.json`. Порядок меток строковый: 1.10.0 стоит раньше 1.2.0; выбирай метки с ведущими нулями или буквами |

Готовые примеры — в `examples/` (например, `python dezhurny.py status --dir
workspace/my_agent/examples/full`). Модель в запуске — replay, то есть
авторский сценарий: настройки меняют среду вокруг модели, а не её «ум».
