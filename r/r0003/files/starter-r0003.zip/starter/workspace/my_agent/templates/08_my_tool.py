def my_tool(cards):
    """<Что делает tool, когда его использовать и когда нет.>"""
    return None
