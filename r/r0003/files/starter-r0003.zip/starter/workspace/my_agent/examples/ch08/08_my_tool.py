def count_open_tasks(cards):
    """Считает незавершённые задачи в уже прочитанных карточках; ничего не пишет и не отправляет."""
    return sum(1 for card in cards if card.get("status") != "done")
