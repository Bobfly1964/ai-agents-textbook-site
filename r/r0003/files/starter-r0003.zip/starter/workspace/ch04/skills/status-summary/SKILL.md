---
name: status-summary
description: подготовить сводку по карточкам проекта
---

# Статус-сводка проекта

## Процедура

1. read cards
2. select blocked
3. compose summary

Поля отчёта описаны в references/report_fields.md и читаются только тогда,
когда шагу compose summary действительно нужна точная форма результата.
Наличие ресурса не означает его загрузку.
