"""Обычная функция без SKILL.md: это не Agent Skill."""


def count_open(cards):
    return sum(1 for card in cards if card.get("status") != "done")
