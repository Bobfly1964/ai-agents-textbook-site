name: bad-frontmatter
description: Здесь нет открывающей строки ---, поэтому это не frontmatter.
---

# Процедура без корректного frontmatter

1. Прочитай карточки.
