"""Маркер главы 9: при запуске создаёт файл EXECUTED.marker рядом с собой.

Загрузчик и skill_demo.py этот файл не запускают; тест проверяет, что маркера нет.
"""
from pathlib import Path

if __name__ == "__main__":
    (Path(__file__).resolve().parent / "EXECUTED.marker").write_text("executed", encoding="utf-8")
