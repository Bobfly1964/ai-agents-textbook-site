# Traces

`python agent_demo.py --scenario success --write-trace` создаёт здесь JSONL.
Перед повторным учебным прогоном старый trace можно переименовать вручную; код
не удаляет файлы автоматически.

