"""Глава 14. Permissions и участие человека: политика и approval gate.

``policy`` проверяет ``14_permissions.json`` тем же читателем, что и конструктор.
``approval`` показывает решение человека о **конкретном** предложении: proposal
создаёт существующий ``Tools.propose_status_update``, применяет — существующий
``apply_status_update``, и только если политика открывает approval gate. Всё
происходит во временной копии учебного workspace: поставляемые карточки не
меняются. ``apply_status_update`` не tool и модели не доступен.
"""

import argparse
import json
import shutil
import tempfile
from pathlib import Path

from school_agent.approval import ApprovalError, apply_status_update
from school_agent.my_agent_config import DEFAULT_DIR, read_permissions_file
from school_agent.paths import WORKSPACE_ROOT, WorkspaceBoundaryError, resolve_workspace_path
from school_agent.permissions import FIELDS, PermissionsError, approval_allowed
from school_agent.tools import Tools
from school_agent.trace import TraceRecorder
from school_agent.trace_analysis import count_approval_events

POLICY_FILE = "14_permissions.json"
TASK_ID, NEW_STATUS = "task-002", "done"
REASON = "Макет афиши согласован; Марк просит отметить задачу выполненной."


def _relative(raw):
    """``workspace/…`` → путь относительно workspace; границу проверит resolve_workspace_path."""

    parts = Path(raw).as_posix().split("/")
    if Path(raw).is_absolute() or parts[0] != "workspace" or len(parts) < 2:
        raise WorkspaceBoundaryError("ожидался относительный путь внутри workspace/")
    return "/".join(parts[1:])


def load_policy(relative_dir, *, workspace_root=WORKSPACE_ROOT):
    """(политика или None, ошибка или None). Файла нет — политики нет: default deny."""

    directory = resolve_workspace_path(relative_dir, workspace_root=workspace_root, must_exist=True)
    path = directory / POLICY_FILE
    if not path.is_file():
        return None, None
    try:
        return read_permissions_file(path), None
    except PermissionsError as exc:
        return None, str(exc)


def cmd_policy(relative_dir=DEFAULT_DIR, *, workspace_root=WORKSPACE_ROOT):
    policy, error = load_policy(relative_dir, workspace_root=workspace_root)
    lines = ["permissions: workspace/" + relative_dir + "/" + POLICY_FILE]
    if error:
        return lines + ["result: not accepted", "reason: " + error]
    if policy is None:
        return lines + ["result: not configured", "approval_gate: closed — " + approval_allowed(None)[1]]
    lines += [key + ": " + policy[key] for key in FIELDS]
    allowed, reason = approval_allowed(policy)
    lines.append("approval_gate: " + ("open — применение только после решения человека" if allowed
                                      else "closed — " + reason))
    return lines + ["result: accepted"]


def _card(workspace, task_id):
    return json.loads((workspace / "tasks" / (task_id + ".json")).read_text(encoding="utf-8"))


def cmd_approval(relative_dir=DEFAULT_DIR, *, decision, case="fresh", workspace_root=WORKSPACE_ROOT):
    policy, error = load_policy(relative_dir, workspace_root=workspace_root)
    source = "workspace/" + relative_dir + "/" + POLICY_FILE
    if error:
        return ["policy: " + source, "result: not accepted", "reason: " + error,
                "apply_status_update: not called"]
    lines = ["policy: " + source + " | " + ("status_update " + policy["status_update"] if policy
                                           else "нет файла — default deny")]
    with tempfile.TemporaryDirectory() as directory:
        # Временная копия: поставляемые карточки не меняются ни при каком решении.
        workspace = Path(directory) / "workspace"
        shutil.copytree(Path(workspace_root), workspace)
        proposal = Tools(workspace_root=workspace).propose_status_update(TASK_ID, NEW_STATUS, REASON)
        lines += ["proposal: %s | %s -> %s" % (TASK_ID, proposal["before"]["status"], proposal["after"]["status"]),
                  "before: status " + proposal["before"]["status"],
                  "after: status " + proposal["after"]["status"],
                  "reason: " + proposal["reason"],
                  "operation_id: " + proposal["operation_id"],
                  "proposal_applied: " + ("true" if proposal["applied"] else "false")]
        if case == "card-changed":
            # Кто-то изменил карточку после предложения: прежнее решение к ней уже не относится.
            card = _card(workspace, TASK_ID)
            card["title"] = card["title"] + " (обновлено)"
            (workspace / "tasks" / (TASK_ID + ".json")).write_text(
                json.dumps(card, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
            lines.append("card_changed_after_proposal: title")
        before = _card(workspace, TASK_ID)
        events = []
        # Сначала политика: если изменение запрещено, человека не спрашивают — подтверждать нечего.
        allowed, gate_reason = approval_allowed(policy)
        if not allowed:
            lines += ["human_decision: не запрашивалось — approval gate закрыт политикой",
                      "apply_status_update: not called | reason: " + gate_reason]
        else:
            trace = TraceRecorder(workspace / "traces" / "ch14_approval.jsonl")
            trace.record("approval_requested", operation_id=proposal["operation_id"], target=proposal["target"])
            trace.record("approval_decision", initiator="human", decision=decision,
                         operation_id=proposal["operation_id"])
            events = trace.events
            lines.append("human_decision: " + decision)
            try:
                result = apply_status_update(proposal, approved=(decision == "approve"), workspace_root=workspace)
            except ApprovalError as exc:
                lines.append("apply_status_update: not applied | reason: " + str(exc))
            else:
                lines.append("apply_status_update: applied" if result["applied"]
                             else "apply_status_update: not applied | reason: " + result["reason"])
        after = _card(workspace, TASK_ID)
        changed = sorted(key for key in set(before) | set(after) if before.get(key) != after.get(key))
        lines += ["observed_status: " + after["status"],
                  "changed_fields: " + (", ".join(changed) if changed else "нет"),
                  "approval_events: %d" % count_approval_events(events)]
    return lines


def main(argv=None):
    parser = argparse.ArgumentParser(description="Permissions и approval gate главы 14 на учебных данных.")
    commands = parser.add_subparsers(dest="command", required=True)
    policy = commands.add_parser("policy", help="проверить 14_permissions.json")
    policy.add_argument("--dir", default="workspace/" + DEFAULT_DIR, help="папка внутри workspace/")
    approval = commands.add_parser("approval", help="решение человека о конкретном предложении")
    approval.add_argument("--dir", default="workspace/" + DEFAULT_DIR, help="папка с 14_permissions.json")
    approval.add_argument("--decision", required=True, choices=("approve", "deny"))
    approval.add_argument("--case", default="fresh", choices=("fresh", "card-changed"))
    args = parser.parse_args(argv)
    try:
        relative = _relative(args.dir)
        if args.command == "policy":
            lines = cmd_policy(relative)
        else:
            lines = cmd_approval(relative, decision=args.decision, case=args.case)
    except (ValueError, FileNotFoundError, OSError) as exc:
        parser.error(str(exc))
    for line in lines:
        print(line)
    return 0


if __name__ == "__main__":
    main()
