"""Глава 13. Обратная связь и версии: proposal, diff, eval и compare двух Version.

Все команды только читают подготовленные Version и ученические копии внутри
``workspace``. Скрипты skill не запускаются, runtime ``skills/project-status/``
не перезаписывается, Rollback не выполняется: ``compare`` печатает решение
``keep`` или ``revert`` и метку Version, к которой следует вернуться.
Строки ``runtime_skill_changed`` и ``files_changed`` — наблюдение по SHA-256
файлов до и после команды, а не обещание.
"""

import argparse
from pathlib import Path

from school_agent.paths import PROJECT_ROOT, WorkspaceBoundaryError, resolve_workspace_path
from school_agent.versioning import (
    compare_version_results,
    diff_skill_versions,
    review_change_proposal,
    run_version_cases,
    snapshot_files,
)

RUNTIME_SKILL = PROJECT_ROOT / "skills" / "project-status"


def _workspace_relative(raw):
    """``workspace/…`` → путь относительно workspace; границу проверит resolve_workspace_path."""

    path = Path(raw)
    parts = path.as_posix().split("/")
    if path.is_absolute() or parts[0] != "workspace" or len(parts) < 2:
        raise WorkspaceBoundaryError("ожидался относительный путь внутри workspace/")
    return "/".join(parts[1:])


def _yes_no(changed):
    return "yes" if changed else "no"


def _proposal(path):
    review = review_change_proposal(_workspace_relative(path))
    print("feedback: " + review["feedback"])
    print("source_eval_case: " + review["source_eval_case"])
    print("source_trace: " + review["source_trace"])
    print("root_cause: " + review["root_cause"])
    print("change_proposal: " + review["change_proposal"])
    print("status: " + review["status"])
    print("new_norm: " + _yes_no(review["new_norm"]))


def _diff(before, after):
    runtime = snapshot_files(RUNTIME_SKILL)
    result = diff_skill_versions(_workspace_relative(before), _workspace_relative(after))
    print("before: " + result["before"])
    print("after: " + result["after"])
    print("file: " + result["file"])
    for line in result["lines"]:
        print(line)
    print("changed_lines: " + str(len(result["lines"])))
    print("runtime_skill_changed: " + _yes_no(snapshot_files(RUNTIME_SKILL) != runtime))


def _eval(version, cases):
    result = run_version_cases(_workspace_relative(version), _workspace_relative(cases))
    print("version: " + result["version"])
    print("eval_set: " + result["eval_set"])
    if not result["accepted"]:
        print("result: not accepted")
        print("reason: " + result["reason"])
        return
    for case in result["cases"]:
        print("case " + case["id"] + ": " + ("pass" if case["passed"] else "fail"))
    print("result: " + str(result["passed"]) + "/" + str(result["total"]))


def _mark(passed):
    return "pass" if passed else "fail"


def _compare(before, after, cases):
    directories = [resolve_workspace_path(_workspace_relative(raw), must_exist=True)
                   for raw in (before, after)]
    files = snapshot_files(*directories, RUNTIME_SKILL)
    results = [run_version_cases(_workspace_relative(raw), _workspace_relative(cases))
               for raw in (before, after)]
    refused = [result for result in results if not result["accepted"]]
    if refused:
        for result in refused:
            print("version: " + result["version"])
            print("result: not accepted")
            print("reason: " + result["reason"])
        print("decision: not compared")
        return
    report = compare_version_results(*results)
    print("before: " + report["before"] + " | %d/%d" % report["before_score"])
    print("after: " + report["after"] + " | %d/%d" % report["after_score"])
    print("eval_set: " + report["eval_set"])
    print("target_case " + report["target_case"] + ": " + _mark(report["target_before"])
          + " -> " + _mark(report["target_after"]))
    for case_id in report["regressions"]:
        print("regression: " + case_id + " | pass -> fail")
    print("regressions: " + str(len(report["regressions"])))
    print("decision: " + report["decision"])
    if report["rollback_to"]:
        print("rollback_to: " + report["rollback_to"])
    print("files_changed: " + _yes_no(snapshot_files(*directories, RUNTIME_SKILL) != files))


def main(argv=None):
    parser = argparse.ArgumentParser(
        description="Version главы 13 на локальных учебных данных; только чтение.",
    )
    commands = parser.add_subparsers(dest="command", required=True)
    proposal = commands.add_parser("proposal", help="связи Change proposal с Test case и Trace")
    proposal.add_argument("path")
    diff = commands.add_parser("diff", help="изменённые строки SKILL.md двух Version")
    diff.add_argument("before")
    diff.add_argument("after")
    evaluate = commands.add_parser("eval", help="одна Version на фиксированном наборе случаев")
    evaluate.add_argument("version")
    evaluate.add_argument("--cases", required=True)
    compare = commands.add_parser("compare", help="две Version на одном наборе: Regression и keep/revert")
    compare.add_argument("before")
    compare.add_argument("after")
    compare.add_argument("--cases", required=True)
    args = parser.parse_args(argv)

    try:
        if args.command == "proposal":
            _proposal(args.path)
        elif args.command == "diff":
            _diff(args.before, args.after)
        elif args.command == "eval":
            _eval(args.version, args.cases)
        else:
            _compare(args.before, args.after, args.cases)
    except (ValueError, FileNotFoundError, OSError) as exc:
        parser.error(str(exc))
    return 0


if __name__ == "__main__":
    main()
