"""Учительская демонстрация. Предскажи запрос и результат отдельно."""
from school_agent.agent import run_replay_scenario


def run_demo(scenario="success"):
    return run_replay_scenario(scenario)


if __name__ == "__main__":
    from school_agent.presentation import agent_main
    agent_main()
