# ИИ-агенты и Agent Skills — starter 0.3.1

Единый starter курса. Версия 0.3.1 закрывает адресный возврат по кандидату
главы 3, не меняя канонические файлы и выводы глав 1–2.
Офлайн-ядро: стандартная библиотека Python, без установки пакетов, сети и API.
Ручной мост требует доступного человеку чата; его доступность обеспечивает учитель.
Главы 1–3 имеют статус `CANONICAL v1.2`;
регламент 05 — `CANONICAL v1.1`.
Реальная модель и классный пилот в объём механического релиза не входят.

## Запуск

Распакуй весь пакет. Открой терминал именно в папке starter.

```sh
python chat_stub.py
python chat_stub.py --scenario missing_file
python loop_demo.py --scenario permanent_error
python harness_demo.py --show-parts
python harness_demo.py --scenario one_match
python access_demo.py --access read --path tasks/task-003.json
python agent_demo.py --scenario success
python -m unittest -v
python eval_runner.py
```

Windows: вместо python может потребоваться py -3; macOS/Linux — python3.
Целевая совместимость 3.9+, фактическая проверка — Python 3.12.
Редактор и терминал: [WORKPLACE_SETUP](docs/WORKPLACE_SETUP.md).

| Когда | Файл | Что наблюдать |
|---|---|---|
| Глава 1 | chat_stub.py | Одинаковая фраза не доказывает чтение |
| Глава 2 | loop_demo.py | Действие → observation → decide в том же шаге |
| Глава 3, урок 5 | harness_demo.py | Семь обязанностей harness вокруг знакомого цикла |
| Глава 3, урок 6 | access_demo.py | Фактическое чтение, гейт операции, область записи `workspace/drafts/` и граница workspace |
| Preview учителя, урок 3–4 | agent_demo.py --scenario success | Черновик после 5 tools; это replay |
| Главы 6–7 | school_agent/dispatcher.py | Запрос, schema, allowlist, результат |
| Глава 9 | skill_demo.py, skills/project-status/ | Metadata → инструкции → reference |
| Глава 11 | eval_runner.py | Harness отдельно от качества модели |

Обвязка вынесена в school_agent/. Верхние учебные скрипты остаются короткими.
Контракты и golden-выводы: [API_STARTER_BY_CHAPTER](API_STARTER_BY_CHAPTER.md).

## Четыре адаптера

- stub: model_stub/planner_stub в главах 1–2, не живая модель.
- replay: data/model_replay.json — авторские сценарии, не записи реальной модели.
- bridge: ручной перенос JSON; минимум один живой запуск обязателен в B.
- live: зарезервированный факультативный API/локальный адаптер, не реализован.
  CLI выдаёт явную ошибку, не подменяет его replay.

```sh
python agent_demo.py --adapter bridge --trace traces/bridge-lesson14.jsonl
```

Передай напечатанный контекст доступной модели, вставь один JSON-ответ,
затем отдельную строку с точкой. /cancel — остановка. Неверный JSON
не исполняется. Повторное имя trace запрещено.
[Лабораторная](docs/LIVE_MODEL_LAB.md). Тест stdin — не запуск живой модели.

## Границы

Четыре tools; read_task_cards() без пути; validate_task_card(task_id)
и build_status_report() по состоянию. Предложение не пишет файл;
apply_status_update вне allowlist, требует решения человека.
Карточки недоверенны, provenance назначает harness.
5 tool steps, 1 повтор ошибки чтения на запуск, 20 model turns.
Загрузка skill/reference запрашивается моделью отдельно; scripts не запускаются.

Даже после включения `write` учебное демо записывает только пути под
`workspace/drafts/`; остальные пути получают `denied/path_not_writable`.
Это учебные ограничения, не OS sandbox и не защита от изменённого Python-кода
с правами пользователя. Не добавляй реальные данные. Redaction по ключам
не гарантирует очистку строк; не публикуй traces без просмотра.
Не исполняй untrusted_samples/.

Один starter на курс. Маркер главы 3 — отложенный `v0.3.1-ch03`.
Git-репозиторий
в поставленном комплекте отсутствует, поэтому фактический тег отложен до
создания репозитория владельца.
История: [CHANGELOG](CHANGELOG.md). Ограничения: [VERIFICATION](docs/VERIFICATION.md).
Отчёты спринта — ../reports/.
