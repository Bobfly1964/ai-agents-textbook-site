# Карточка

Обязательные поля: id, title, status. Дополнительные: team, blockers (список строк), notes.
Статусы: planned, in_progress, blocked, done.
Прочие поля запрещены при проверке. Метаданные происхождения не хранятся
в карточке: harness оборачивает весь результат в untrusted_content и
добавляет provenance с assigned_by=harness и trust=untrusted.

validate_task_card(task_id) проверяет оригинал из состояния, не копию из ответа модели.
