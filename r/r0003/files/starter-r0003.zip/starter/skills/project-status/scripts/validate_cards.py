"""Ручная проверка автором; loader не запускает этот файл."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[3]))
from school_agent.tools import Tools

if __name__ == "__main__":
    tools = Tools()
    data = tools.read_task_cards()
    for card in data["untrusted_content"]:
        print(tools.validate_task_card(card["id"]))
