"""Чек исходников и тесты с временными рабочими папками."""
import ast
import json
import os
import subprocess
import sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]

def main():
    checks = []
    files = sorted(ROOT.rglob("*.py"))
    for path in files:
        ast.parse(path.read_text(encoding="utf-8"), filename=str(path), feature_version=(3, 9))
        compile(path.read_text(encoding="utf-8"), str(path), "exec")
    checks.append({"check":"syntax_grammar_3_9_and_compile", "passed":True, "files":len(files)})
    json_files = sorted(ROOT.rglob("*.json"))
    for path in json_files:
        json.loads(path.read_text(encoding="utf-8"))
    checks.append({"check":"json_parse", "passed":True, "files":len(json_files)})
    result = subprocess.run([sys.executable, "-m", "unittest", "-v"], cwd=ROOT,
                            capture_output=True, text=True, encoding="utf-8",
                            env=dict(os.environ, PYTHONIOENCODING="utf-8"))
    checks.append({"check":"unittest", "command":"python -m unittest -v",
                   "passed":result.returncode == 0, "stdout":result.stdout, "stderr":result.stderr})
    print(json.dumps({"python":sys.version, "checks":checks,
                      "all_passed":all(row["passed"] for row in checks)}, ensure_ascii=False, indent=2))
    return 0 if all(row["passed"] for row in checks) else 1

if __name__ == "__main__":
    raise SystemExit(main())
