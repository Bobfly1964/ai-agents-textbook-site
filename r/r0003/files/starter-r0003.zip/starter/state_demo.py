"""Глава 10. Состояние и память: карта хранения, checkpoint, продолжение, handoff.

Читает и пишет только через существующие ``load_state``/``save_state``
(``school_agent/state_store.py``) — второго хранилища нет. Запись разрешена
только в ``workspace/drafts/``; карточки проекта не изменяются. Значения
секретных полей не печатаются. Сеть не используется.
"""

import argparse
import hashlib
import json
from pathlib import Path

from school_agent.paths import WORKSPACE_ROOT, WorkspaceBoundaryError, resolve_workspace_path
from school_agent.trace import SENSITIVE_PARTS
from school_agent.state_store import (
    build_handoff,
    load_state,
    save_state,
    validate_project_state,
)

STORAGE_MAP = WORKSPACE_ROOT / "ch10" / "storage_map.json"


def _workspace_relative(raw):
    """``workspace/…`` → путь относительно workspace; границу проверит load_state."""

    path = Path(raw)
    parts = path.as_posix().split("/")
    if path.is_absolute() or parts[0] != "workspace" or len(parts) < 2:
        raise WorkspaceBoundaryError("ожидался относительный путь внутри workspace/")
    return "/".join(parts[1:])


def _drafts_relative(raw):
    """Цель записи — только внутри workspace/drafts/, проверяется по разрешённому пути."""

    drafts = resolve_workspace_path("drafts")
    target = resolve_workspace_path(raw)
    try:
        target.relative_to(drafts)
    except ValueError as exc:
        raise WorkspaceBoundaryError("checkpoint сохраняется только в drafts/ внутри workspace") from exc
    if target == drafts:
        raise WorkspaceBoundaryError("checkpoint сохраняется только в drafts/ внутри workspace")
    return target.relative_to(WORKSPACE_ROOT.resolve()).as_posix()


def _tasks_digest():
    digest = hashlib.sha256()
    for path in sorted((WORKSPACE_ROOT / "tasks").glob("*.json")):
        digest.update(path.name.encode("utf-8"))
        digest.update(path.read_bytes())
    return digest.hexdigest()


def _print_state(state):
    print("project: " + state["project"])
    print("status: " + state["status"])
    print("blocked tasks: " + (", ".join(state.get("blocked_tasks", [])) or "нет"))
    print("next step: " + state["next_step"])


def _classify():
    items = json.loads(STORAGE_MAP.read_text(encoding="utf-8"))["items"]
    for item in items:
        print(item["artifact"] + " -> " + item["mechanism"] + " | " + item["question"])


def _resume(raw):
    state = load_state(_workspace_relative(raw))
    errors = validate_project_state(state)
    if errors:
        print("checkpoint: not accepted")
        print("error: " + errors[0])
        print("result: not resumable")
        return
    print("checkpoint: loaded")
    _print_state(state)
    print("result: resumable")


def _checkpoint(raw, out):
    state = load_state(_workspace_relative(raw))
    errors = validate_project_state(state)
    if errors:
        print("checkpoint: not saved")
        print("error: " + errors[0])
        print("result: not ready for resume")
        return
    target = _drafts_relative(out)
    before = _tasks_digest()
    save_state(state, target)
    saved = load_state(target)
    print("checkpoint: saved")
    print("path: " + target)
    print("fields: " + ", ".join(state))
    print("project cards changed: " + ("no" if _tasks_digest() == before else "yes"))
    ready = saved == state and not validate_project_state(saved)
    print("result: " + ("ready for resume" if ready else "not ready for resume"))


def _handoff(raw):
    state = load_state(_workspace_relative(raw))
    try:
        handoff = build_handoff(state)
    except ValueError as exc:
        print("handoff: not built")
        print("error: " + str(exc))
        print("secret value printed: no")
        print("result: not accepted")
        return
    secret_fields = [key for key in handoff if any(part in key.lower() for part in SENSITIVE_PARTS)]
    transcript = any("transcript" in key.lower() or "chat" in key.lower() for key in handoff)
    print("handoff: built")
    _print_state(handoff)
    print("full transcript included: " + ("yes" if transcript else "no"))
    print("secret fields included: " + str(len(secret_fields)))
    print("result: " + ("accepted" if not secret_fields and not transcript else "not accepted"))


def main(argv=None):
    parser = argparse.ArgumentParser(
        description="Состояние и память главы 10 на локальных учебных данных.",
    )
    commands = parser.add_subparsers(dest="command", required=True)
    commands.add_parser("classify", help="какой механизм отвечает на какой вопрос хранения")
    resume = commands.add_parser("resume", help="можно ли продолжить работу по checkpoint")
    resume.add_argument("path")
    checkpoint = commands.add_parser("checkpoint", help="сохранить проверенное состояние в drafts/")
    checkpoint.add_argument("path")
    checkpoint.add_argument("--out", required=True)
    handoff = commands.add_parser("handoff", help="собрать передачу для продолжения")
    handoff.add_argument("path")
    args = parser.parse_args(argv)

    try:
        if args.command == "classify":
            _classify()
        elif args.command == "resume":
            _resume(args.path)
        elif args.command == "checkpoint":
            _checkpoint(args.path, args.out)
        else:
            _handoff(args.path)
    except (WorkspaceBoundaryError, ValueError, OSError) as exc:
        parser.error(str(exc))
    return 0


if __name__ == "__main__":
    main()
