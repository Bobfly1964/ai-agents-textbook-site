# Контракт учебник ↔ starter 0.17.2

Реализация EC-01…06 от 05.09.2026. Уровень 5а — только имена/сигнатуры,
ниже поурочного плана и выше главы. Содержательные конфликты — через EC.
Контракт действует вместе с регламентом 05 `CANONICAL v1.1`.

| Глава | Интерфейс | Контракт |
|---|---|---|
| 1 | model_stub(text) | Строка «Карточки проекта прочитаны. Задача task-003 заблокирована.» |
| 1 | read_task_cards() | Ни одного аргумента; базовая папка фиксирована |
| 2 | planner_stub(state) | Выбор действия, не выполнение |
| 2 | update_state(state, observation) | observation, steps += 1, failures += 1 при отказе |
| 2 | decide(state) | Только observation, steps, failures и лимиты; без чтения scenario |
| 2 | run_loop(scenario, max_steps, max_retries) | `while not state["done"]`; единственный владелец лимита — `decide` после observation |
| 3 | run_harness(scenario, max_steps, max_retries) | Аддитивная оркестрация; для семи сценариев результат равен `run_loop`; новой функции решения нет |
| 3 | check_workspace_access(relative_path, operation) | Корень фиксирован приложением; путь относительный; разрешённая запись выполняется только внутри `workspace/drafts/`, иначе `denied/path_not_writable`; учебные проверки не доказывают OS-sandbox |
| 4 | mechanisms_demo.main(argv=None) | CLI `fragments`, `check <путь>`, `mcp`, `skill --layer <...>`; детерминированный stdout, stderr пуст |
| 4 | list_mechanism_fragments(root=CH04_ROOT) | Пять фрагментов из самих артефактов; служебные поля с названием механизма не печатаются |
| 4 | format_fragment_list(items) | Полный stdout B1 |
| 4 | check_mechanism_choices(choices_path, root=CH04_ROOT) | Путь только из `workspace/` или `tests/fixtures/`; границу проверяет `resolve_workspace_path`; неполный вход не даёт частичный балл |
| 4 | format_choice_review(review) | Полный stdout B2–B5; `результат: N/M` либо `результат: не принят` |
| 4 | list_mcp_resources(root=CH04_ROOT) | host/client/server/resources из локальной карточки; флаги network: not used и trust: not proven — утверждение самой демонстрации, из карточки не читаются (EC-05); сеть не используется |
| 4 | format_mcp_map(model) | Полный stdout B6, включая `network: not used` и `trust: not proven` |
| 4 | skill_steps(instructions), report_fields(content) | Разбор текста уже загруженного слоя; не загрузчик |
| 6–7 | call_tool(tool_call, tools) | Schema и allowlist до выполнения |
| 6–8 | Tools.read_task_cards() | arguments={} |
| 6–8 | Tools.validate_task_card(task_id) | Оригинал из состояния, не копия модели |
| 6–8 | Tools.build_status_report() | Проверенные карточки, черновик в памяти |
| 6 | tool_call_demo.main(argv=None) | CLI show/execute/check <path>/check-card <path>/schema <имя>; детерминированный stdout, stderr пуст |
| 6 | validate_task_card_schema(card) | Подмножество JSON Schema по $defs.task_card из data/tool_schemas.json |
| 7 | dispatcher_demo.main(argv=None) | CLI case <allowed\|unknown-tool\|invalid-arguments\|tool-exception> / run <two-calls\|stop-after-decision\|missing-file> поверх call_tool и run_agent; детерминированный stdout |
| 7 | run_agent(adapter, *, scenario, max_steps, max_retries, trace_relative_path, profile=None) | Пакет tool_calls последовательно через call_tool; решение после каждого observation; после терминала остаток пакета не выполняется; steps — только выполненные попытки; trace — новый файл внутри workspace/traces; `profile` (EC-24) необязателен, при `None` поведение прежнее |
| 7 | agent_demo.py --adapter replay\|bridge --scenario <name> --trace <traces/…> | CLI уроков 2–14; bridge только со сценарием success |
| 8 | tool_quality_demo.main(argv=None) | CLI passport <tool> / route --case <should-validate-card\|should-read-board> / suite; детерминированный stdout, stderr пуст; доменные tools не вызываются |
| 8 | build_tool_passport(name, catalog, schemas) | Паспорт разрешённого tool: scope, contract, description, when/when_not из description, сводка schema из TOOL_SCHEMAS; без выполнения |
| 8 | check_route_case(case_name, catalog) | Учебный выбор на заранее заданном случае из workspace/ch08/cases.json; правило when/when_not над description, не модель; неизвестный case — ValueError |
| 8 | run_quality_suite(catalog) | positive, negative (выбор) и error (validate_tool_arguments) case; итог passed/total |
| 8 | load_catalog(path=PASSPORTS_PATH), select_tool(request, catalog) | Паспорта workspace/ch08/tool_passports.json только для имён allowlist; выбор читает только запрос и каталог |
| 14 | Tools.propose_status_update(task_id, new_status, reason) | Без записи, before/after и operation_id |
| 14 | apply_status_update(proposal, approved=…, workspace_root=…) | Не tool; status-only, отдельное решение человека |
| 14 | permissions.validate_permissions_config(value) | Ровно `default: deny`, `task_cards: read_only`, `status_update: approval_required \| deny`; иначе `PermissionsError` с причиной; ничего не читает и не печатает; единственный источник правил |
| 14 | permissions.approval_allowed(policy) | `(False, "политики нет: default deny")` без политики; `(False, "политика status_update = deny")`; иначе `(True, "approval_required")` |
| 14 | permissions_demo.main(argv=None) | CLI policy --dir <workspace/…> / approval --dir <workspace/…> --decision approve\|deny [--case fresh\|card-changed]; proposal — `propose_status_update`; сначала политика: при закрытом gate человека не спрашивают, событий approval нет, `apply_status_update` не вызывается; при открытом — решение человека и `apply_status_update`; временная копия workspace; события approval пишет `TraceRecorder`; детерминированный stdout |
| 14 | my_agent_config.read_permissions_file(path) | Единственный читатель `14_permissions.json` для status, run и permissions_demo |
| 15 | trust.validate_trust_config(value) | Ровно `external_content: untrusted` и `skills: {имя: connect_minimal \| isolate \| reject}`; `trusted`, `execute`, неизвестное поле — `TrustError`; ничего не читает и не печатает |
| 15 | trust.connected_skills(policy, found_names) | Без политики подключены все; с политикой — только `connect_minimal`, у остальных причина (`isolate`, `reject`, «нет решения аудита») |
| 15 | my_agent_config.read_trust_file(path) | Единственный читатель `15_trust.json`; имя skill, которого нет в `09_skills`, — ошибка конфигурации |
| 15 | trust_demo.main(argv=None) | CLI document --case task-901 / replay / audit skill --sample <имя> / audit mcp --sample <имя>; требования из данных проверяются вызовом существующих гейтов; статический аудит — scripts не запускаются, сети нет, «static audit: not a safety proof»; детерминированный stdout |
| 16 | long_work.validate_run_plan(value) | Ровно `max_sessions` (целое 1–5), `checkpoint` (относительный путь внутри `drafts/`, проверяется как текст, диск не читается), `owner` (непустая строка роли); иное — `RunPlanError`; ничего не читает и не печатает |
| 16 | long_work.session_number(checkpoint) | Номер начинающейся Session: без checkpoint — 1, иначе `sessions_used + 1`; нет `sessions_used` — `RunPlanError` |
| 16 | long_work.build_checkpoint(state_before, result, plan, goal) | Состояние после Session: поля Handoff главы 10 (`project`, `goal`, `status` = терминал, `blocked_tasks` из черновика `build_status_report`, `pending_question` при `needs_input`, `next_step` по терминалу) + `sessions_used`, `last_terminal`, `last_scenario` |
| 16 | long_work.validate_architecture_handoff(value) | Handoff отдельного исполнителя: `subtask`, `executor`, `result` (объект), `owner`, `basis` ∈ fact \| heuristic \| hypothesis \| forecast; `fact` требует `evidence`; `transcript`, `history`, `permissions`, `trust`, secret-ключи запрещены; ошибки списком |
| 16 | my_agent_config.read_run_plan_file(path) | Единственный читатель `16_run_plan.json` |
| 16 | dezhurny.py run (с `16_run_plan.json`) | Один `run` = одна Session; Inner loop — существующий `run_agent`. До цикла: checkpoint из плана — `load_state` + `validate_project_state` (невалидный — exit 2, `checkpoint: not accepted — …`), `session: N/M`; после `max_sessions` — `outer loop: стоп …`, Inner loop не запускается, checkpoint не переписывается, exit 0. После цикла — `save_state` в путь плана, строки `checkpoint: saved …` и `handoff: build_handoff …`. Без файла вывод прежний |
| 16 | long_work_demo.main(argv=None) | CLI `repeat` (одно подтверждённое предложение применяется дважды существующим `apply_status_update` на копии workspace: второй раз `already_applied`) / `handoff --case analyzer\|missing-owner` (фиксированная последовательность существующих tools через dispatcher, без модели и сети; Handoff для Owner) |
| 17 | release_candidate.config_files(folder) | Файлы конфигурации папки: главы 1–16 и все файлы `09_skills/`; без `10_state.json`, `13_versions/`, `templates/`, `examples/`, `README.md` и файла 17; относительные POSIX-пути, отсортированы; файл вне папки — `ReleaseCandidateError` |
| 17 | release_candidate.digest(folder, files) | SHA-256 по «путь + содержимое» с `\r\n → \n` |
| 17 | release_candidate.build_release_candidate(label, folder) | `{"label", "files": {путь: sha256}, "digest"}`; `label` — `^[A-Za-z0-9._-]{1,64}$` |
| 17 | release_candidate.validate_release_candidate(value, folder) | Ошибки списком (первое расхождение): «ожидался JSON-объект», «неизвестное поле …», «label — …», «не зафиксирован — выполни python dezhurny.py candidate --label <label>», «недействителен — добавлен / удалён <файл>», «недействителен — <файл> изменён после фиксации», «недействителен — отпечаток не совпадает»; пустой список — метка действительна. Ничего не печатает |
| 17 | dezhurny.py candidate --label L [--dir …] | Фиксирует Release candidate: пишет `17_release_candidate.json` существующим `save_state`; при той же метке и тех же файлах не переписывает; при ошибке другой строки конфигурации — отказ (exit 2). Печатает метку, число файлов, 12 знаков отпечатка и «метка кандидата, не доказательство качества» |
| 17 | dezhurny.py run / eval (с `17_release_candidate.json`) | До цикла строка `Release candidate: L \| зафиксировано файлов: N \| отпечаток совпадает — …`; terminal, tools, permissions, trust не меняются. Недействительная метка — строка `ошибка` в `status` и остановка `run`/`eval` до цикла (`require_valid`, exit 2). Без файла вывод прежний |
| 13 | versions.save_version(folder, label, *, workspace_root=WORKSPACE_ROOT) | Снимок `folder/13_versions/<label>/`: копии файлов `release_candidate.config_files` и `manifest.json` `{"label", "files": {путь: sha256}, "digest"}` (существующий `save_state`, последним); метка — `release_candidate.LABEL`; та же метка и те же файлы — ничего не пишет; другие — `VersionsError` «версия <label> уже есть и отличается — выбери новую метку»; пустая конфигурация — снимок с `files: {}` (0.17.1, как `candidate`); пишет только внутри `13_versions/`, ничего не печатает |
| 13 | versions.list_versions(folder) | Манифесты снимков в строковом порядке меток (1.10.0 раньше 1.2.0); нет папки — `[]` |
| 13 | versions.compare_versions(folder, a, b) | `{"changed", "added", "removed"}` по sha манифестов и `same_cases` — одинаковый `11_evals.json` в обоих снимках; неизвестная метка — `VersionsError` |
| 13 | versions.validate_versions_dir(folder) | Каждый подкаталог `13_versions/` — снимок: `13_versions: <снимок>: нет manifest.json \| лишний файл <путь> \| файл <путь> не совпадает с манифестом \| метка не соответствует формату \| manifest.json повреждён — удали папку снимка или сохрани заново под новой меткой`; только `README.md` — «это шаблон, а не снимок — удали папку и выполни python dezhurny.py version save <метка>» |
| 13 | dezhurny.py version save L / list / compare A B [--dir …] | `save` — отказ при ошибке любой строки, кроме 13 и 17 (exit 2); печатает `version: L \| файлов: N \| digest: <12 hex>` и «снимок конфигурации, не оценка качества». `list` — строка на снимок или `versions: нет — …`. `compare` — `изменены/добавлены/удалены`; при одном наборе случаев — `cases: 11_evals.json совпадает \| случаев: K`, по случаю `case <id>: A pass\|fail \| B pass\|fail`, `improved: N \| regressions: M`, `decision: revert` (M > 0) / `keep` (N > 0) / `keep — улучшение не наблюдается: покажи другое свидетельство (diff, trace)`; при разных — `decision: не сравнивается — разные наборы случаев (правило главы 13)`, eval не запускается; последняя строка `evidence: synthetic_script — …`. Решение — рекомендация, файлы не меняются |
| 13 | dezhurny.py status (строка 13) | `настроено: версий: N (метки) \| version save/list/compare`; без папки — `не настроено \| version save сохраняет снимок конфигурации`; сломанный снимок — `ошибка` и остановка `run`/`eval` до цикла. Итог `configured: k/15`. Снимки не входят в отпечаток Release candidate и не меняют `run` |
| 14–17 | dezhurny.py status --chapter N | Шапка и строка главы N без счётчика; главы печатают только его — активация следующих строк не меняет их вывод. Строка в состоянии «ошибка» (0.14.1): последнее поле — «run не запускается, пока файл не исправлен» (`run` и `eval` останавливаются до цикла, exit 2) |
| 9 | load_skill / read_skill_resource в ответе | Запросы контекста, не пятый/шестой доменные tools |
| 9 | skill_demo.main(argv=None) | CLI catalog/load <name>/resource <name> <path>/check <workspace-dir>/replay поверх skill_loader и run_replay_scenario; scripts не выполняются; детерминированный stdout |
| 4, 9 | discover_skills(skills_root) | Слой 1: только name и description каждого каталога с SKILL.md |
| 4, 9 | load_skill(skills_root, name) | Слой 2: metadata, instructions, список supporting files; name == имя каталога; плоский frontmatter |
| 4, 9 | read_skill_resource(skills_root, name, relative_path) | Слой 3: только references/ и assets/, allowlist расширений, предел 256 000 байт, путь внутри каталога skill |
| 4, 9 | list_skill_files(skill_directory) | Перечень references/, assets/, scripts/ без чтения и без запуска |
| 10 | state_demo.main(argv=None) | CLI classify / resume <workspace-path> / checkpoint <workspace-path> --out drafts/<…> / handoff <workspace-path>; запись только в workspace/drafts/; значения секретных полей не печатаются; детерминированный stdout |
| 10, 14 | load_state(relative_path="project_state.json", *, workspace_root) | Существующее хранилище: JSON-объект внутри workspace; граница resolve_workspace_path |
| 10, 14 | save_state(state, relative_path="project_state.json", *, workspace_root) | Атомарная запись через временный файл и os.replace; только внутри workspace |
| 10 | validate_project_state(state) | Пустой список — состояние пригодно для продолжения; обязательны project, goal, status, next_step; ключ с частью из trace.SENSITIVE_PARTS → «forbidden secret field» |
| 10 | build_handoff(state) | Только поля HANDOFF_FIELDS; невалидное состояние или секрет → ValueError; история и стенограмма не передаются |
| 11 | run_eval_cases() | Harness отдельно от scripted model_behavior; общей доли над двумя слоями нет; отсутствие живых свидетельств — `not_evaluated`, а не ноль; `publication_ready` ложен при открытых внешних блокерах |
| 11 | eval_runner.py | Печатает результат `run_eval_cases()` как JSON (stdout = golden `ch11_eval_runner.txt`); `--summary` — три строки из того же результата (golden `ch11_eval_summary.txt`), счёт не меняется; exit 0, пока все harness-случаи проходят |
| 11 | workspace/evals/test_cases.json | Индекс двух наборов: `harness_cases.json` и `model_behavior_cases.json`; собственных случаев не содержит — второго источника истины нет |
| 12 | trace_demo.main(argv=None) | CLI record --scenario <имя> --out traces/<…> / show <путь> / analyze <путь> поверх существующих `run_replay_scenario` и `TraceRecorder`; второго цикла и второго журнала нет; запись только в `workspace/traces/`, существующий Trace не перезаписывается; анализ read-only |
| 12 | trace_analysis.load_trace(relative_path, *, workspace_root=WORKSPACE_ROOT) | JSONL только внутри workspace; повреждённая строка, событие без обязательных полей, observation без запроса, потерянные `run_started`/`run_finished` → `TraceFormatError`, а не частичный отчёт |
| 12 | trace_analysis.summarize_trace(events) | events, tool_calls, errors, approval_events, terminal, steps — счётом по событиям; approval узнаётся по типу события, а не по списку случаев |
| 12 | trace_analysis.find_failure_point(events) | Первое наблюдаемое отклонение: при `unknown_tool` — событие `tool_requested`, иначе `tool_observation`; скрытые причины не угадываются; без отклонения — `None` |
| 12 | trace_analysis.build_incident_report(events) | terminal, счётчики, failure_point, root_cause (код ошибки из observation) и `evidence_event_id`; рекомендаций по версиям и откату нет |
| 13 | change_demo.main(argv=None) | CLI proposal <путь> / diff <до> <после> / eval <Version> --cases <набор> / compare <до> <после> --cases <набор>; только чтение внутри workspace; runtime `skills/project-status/` не меняется, скрипты не запускаются, Rollback не выполняется; детерминированный stdout |
| 13 | versioning.review_change_proposal(relative_path, *, workspace_root=WORKSPACE_ROOT) | Обязательные поля; `status` только `proposed`, `new_norm` всегда ложен; `source_eval_case` из того же набора; root_cause — из `build_incident_report` по `source_trace`, должен совпасть с `expected_root_cause` |
| 13 | versioning.diff_skill_versions(before_path, after_path, *, workspace_root=WORKSPACE_ROOT) | Изменённые строки `SKILL.md` двух Version (`<метка>/<имя skill>/`); структура — через `load_skill`; качество не оценивает |
| 13 | versioning.run_version_cases(version_path, cases_path, *, workspace_root=WORKSPACE_ROOT) | Один фиксированный набор; rubric `line_contains` над текстом процедуры, не модель; повреждённая Version — `accepted: false` без частичного счёта |
| 13 | versioning.compare_version_results(before, after) | Regression — только pass → fail на том же `eval_set` и том же наборе случаев, иначе `VersioningError`; `keep` — target_case исправлен и Regression нет, иначе `revert` и `rollback_to` |
| Конструктор (EC-24) | dezhurny.main(argv=None) | CLI status [--json] / run [--scenario S] [--model replay\|bridge] / eval / trace --last / candidate --label L / version save\|list\|compare; у всех --dir workspace/<папка my_agent>; композиция существующих run_agent, skill_loader, state_store, trace_analysis; второго цикла, диспетчера и загрузчика нет; детерминированный stdout при replay |
| Конструктор (EC-24) | my_agent_config.read_my_agent(relative_dir="my_agent", *, workspace_root=WORKSPACE_ROOT) | Строки status по главам 1–17: настроено / не настроено (глава N) / ошибка с сообщением (зарезервированных строк с 0.17.0 нет); код `08_my_tool.py` не исполняется (ast) |
| Конструктор (EC-24) | my_agent_config.build_profile(config) | `HarnessProfile` для `run_agent(profile=…)`: allowlist из 07 (tool вне списка → `tool_rejected`/`not_in_profile_allowlist` до диспетчера), описание tool 08 только при имени в allowlist, корень skills 09; `None`, если 07–09 ничего не меняют |
| Конструктор (EC-24) | my_agent_config.check_save(policy, *, workspace_root) | Сохранение черновика: operation_not_allowed / path_outside_workspace / path_not_writable, как гейт главы 3; область записи — только внутри `drafts/` |

read_task_cards() доступен как функция для главы 1. В полном harness — сессионный
Tools; self не передаётся моделью. workspace_root/scenario отсутствуют в schemas tools.
Карточка: id/title/status обязательны; team/blockers/notes дополнительные.
Статусы planned / in_progress / blocked / done; дубли task-003 / task-003-copy.

## Счётчики

steps считает выполненные попытки, включая ошибку tool. Отклонённый до исполнения
запрос не увеличивает steps и даёт error. failures считает отказы; MAX_RETRIES=1 —
один повтор ошибки чтения на запуск. Второй отказ → error на действии 2.
Успех на предельном шаге остаётся success. Пустой завершённый поиск,
неоднозначность или approval →
needs_input. Таймаут не симулируется. model_turns ≤20 ограничивает обращения без tools.

Сценарий `limit` возвращает на каждом шаге неполный результат
`search_complete: false` и следующий номер страницы. Такое observation честно
разрешает продолжение; на шаге 5 `decide` возвращает `limit`.
Одинаковые observation и счётчики дают одинаковое решение независимо от имени
сценария. Имя сценария использует только среда при подготовке observation.

## Ответ bridge/replay

data/response.schema.json: tool_calls / load_skill / read_skill_resource /
text / needs_input / error. Parser дополнительно запрещает повтор JSON-ключей,
пустые по смыслу строки, NaN и ответ >256 KB. До 4 calls выполняются последовательно
до решения остановиться; id уникален в запуске. Результат связан с call_id.
Это учебный протокол, не provider API.

## Слои Agent Skill в главе 4

B7–B9 используют существующий `school_agent/skill_loader.py` главы 9:
`discover_skills` → `load_skill` → `read_skill_resource`. Второго загрузчика
skill в starter нет; `mechanisms_demo.py` только форматирует stdout и вызывает
ровно один слой за запуск. Учебный mock-skill главы 4 лежит в отдельном корне
`workspace/ch04/skills/` и не смешивается с каталогом главы 9 `skills/`.
Эталонный ключ классификации лежит в `tests/fixtures/ch04/`, а не в рабочей
папке ученика; ученический файл ответов starter не поставляет.

## Golden

`tests/golden`: 32 полных вывода. Десять прежних эталонов — chat
normal/missing; семь сценариев `new_state`; teacher agent success. Десять
эталонов выпуска 0.3.0 главы 3 — карта частей, один запуск harness и четыре
access-сценария в человекочитаемом и JSON-режимах. В 0.3.1 добавлена пара
human/JSON для `path_not_writable`. Прежние эталоны starter 0.2.1 не
изменены; их соответствие главам `CANONICAL v1.2` подтверждено редакторским
заключением № 4.

Десять эталонов выпуска 0.4.0 главы 4 — пять фрагментов, четыре сценария
классификации и несозданный файл ответов, карта MCP и три слоя Agent Skill.
Двадцать два эталона глав 1–3 в выпуске 0.4.0 не изменялись.

Восемь эталонов выпуска 0.6.0 главы 7 — четыре случая `dispatcher_demo.py case`,
три прогона `dispatcher_demo.py run` и stdout `agent_demo.py --scenario missing_file`.
Сорок четыре эталона глав 1–6 не изменялись (слепок в `tests/test_dispatcher_demo.py`).

Четыре эталона выпуска 0.7.0 главы 8 — паспорт `validate_task_card`, два
случая `route` и `suite`. Пятьдесят два эталона глав 1–7 не изменялись
(слепок в `tests/test_tool_quality_demo.py`). Учебные паспорта главы 8 лежат
в `workspace/ch08/tool_passports.json`; с 0.7.1 описания каталога моста
`data/tool_catalog.json` совпадают с ними дословно (тест равенства).

Восемь эталонов выпуска 0.8.0 главы 9 — `skill_demo.py` catalog, load, resource,
четыре случая `check` и replay. Пятьдесят шесть эталонов глав 1–8 не изменялись
(слепок в `tests/test_skill_demo.py`).

Шесть эталонов выпуска 0.9.0 главы 10 — `state_demo.py` classify, два resume,
checkpoint и два handoff. Шестьдесят четыре эталона глав 1–9 не изменялись
(слепок в `tests/test_state_demo.py`).

Шесть эталонов выпуска 0.10.0 главы 12 — `trace_demo.py` record, show, повторная
запись того же пути и три разбора учебных traces. Семьдесят два эталона глав
1–11 не изменялись (слепок в `tests/test_trace_demo.py`). Учебные traces
`workspace/ch12/cases/*.jsonl` сняты фактическим `TraceRecorder` из авторского
сценария `workspace/ch12/replay/trace_cases.json`; тест повторяет запись и
сверяет формат.

Шесть эталонов конструктора «Дежурного» (EC-24, выпуск 0.12.0) лежат отдельно, в
`tests/golden_dezhurny/`: status чистой папки и полного примера, run по
умолчанию, с пределом двух шагов и с отказом записи, eval примера. Прежние
84 эталона глав 1–13 не изменялись (слепок в `tests/test_dezhurny.py`).

Два эталона главы 11 — полный stdout `eval_runner.py` (`ch11_eval_runner.txt`,
выпуск 0.9.1) и три строки `--summary` (`ch11_eval_summary.txt`, выпуск 0.9.2
по вердикту C1). Семьдесят эталонов глав 1–10 не изменялись (слепок в
`tests/test_eval_runner.py`).

Ретрофит глав 1–13 (выпуск 0.17.0): пятнадцать эталонов блоков «Достраиваем
„Дежурного“» — `ch01|05|07|08|09|10|12_dezhurny_*` (одиннадцать, команды
конструктора с фикстурами и папками `examples/ch08|ch09|ch10`) и четыре
`ch13_dezhurny_*` (`version save`, `status --chapter 13`, два `version compare`).
Эталоны глав 2, 3, 11 в блоках — прежние `dezhurny_run_limit2`,
`dezhurny_run_denied`, `dezhurny_eval_example`. В `golden_dezhurny/` изменены
только `dezhurny_status_empty/example` (строка 13 и `k/15`). Сто пятнадцать
эталонов 0.16.0 не изменялись (слепок в `tests/test_versions.py`).

Шесть эталонов выпуска 0.11.0 главы 13 — `change_demo.py` proposal, diff,
eval исходной Version, два compare (с Regression и без) и повреждённая
Version. Семьдесят восемь эталонов глав 1–12 не изменялись (слепок в
`tests/test_change_demo.py`).
