"""Harness измеряется отдельно от поведения модели."""
import json
import tempfile
import shutil
from pathlib import Path

from .agent import run_replay_scenario
from .dispatcher import call_tool
from .paths import WORKSPACE_ROOT, PROJECT_ROOT, WorkspaceBoundaryError, resolve_workspace_path
from .tools import Tools
from .approval import apply_status_update

def check_harness(case_id, workspace_root):
    tools = Tools(workspace_root)
    if case_id == "allowlist":
        result = call_tool({"id": "h1", "name": "publish_report", "arguments": {}}, tools)
        return not result["executed"] and result["error"]["code"] == "unknown_tool"
    if case_id == "pathless_contract":
        result = call_tool({"id": "h2", "name": "read_task_cards", "arguments": {"relative_dir": "../"}}, tools)
        return not result["executed"] and result["error"]["code"] == "invalid_arguments"
    if case_id == "workspace_boundary":
        try:
            resolve_workspace_path("../escape.json", workspace_root=workspace_root)
        except WorkspaceBoundaryError:
            return True
        return False
    if case_id == "proposal_no_write":
        with tempfile.TemporaryDirectory() as directory:
            target = Path(directory) / "workspace"
            shutil.copytree(workspace_root, target)
            cards_before = {path.name: path.read_bytes() for path in (target / "tasks").glob("*.json")}
            proposal = Tools(target).propose_status_update("task-003", "in_progress", "Учебное предложение")
            result = apply_status_update(proposal, approved=False, workspace_root=target)
            cards_after = {path.name: path.read_bytes() for path in (target / "tasks").glob("*.json")}
            return not result["applied"] and cards_before == cards_after
    if case_id == "step_budget":
        result = run_replay_scenario("limit", workspace_root=workspace_root)
        return result["terminal"] == "limit" and result["steps"] == 5
    if case_id == "retry_terminal":
        result = run_replay_scenario("missing_file", workspace_root=workspace_root)
        return result["terminal"] == "error" and result["steps"] == 2 and result["failures"] == 2
    raise ValueError("неизвестная harness-проверка: " + case_id)

def run_eval_cases(*, workspace_root=WORKSPACE_ROOT):
    folder = PROJECT_ROOT / "workspace/evals"
    harness_cases = json.loads((folder / "harness_cases.json").read_text(encoding="utf-8"))["cases"]
    behavior_cases = json.loads((folder / "model_behavior_cases.json").read_text(encoding="utf-8"))["cases"]
    rows = [{"id": case["id"], "passed": check_harness(case["id"], workspace_root)} for case in harness_cases]
    behavior = []
    for case in behavior_cases:
        result = run_replay_scenario(case["scenario"], workspace_root=workspace_root)
        behavior.append({"id": case["id"], "status": "scripted", "scoring": "excluded",
                         "actual_terminal": result["terminal"],
                         "expected_script_terminal": case["expected_terminal"],
                         "script_contract_matches": result["terminal"] == case["expected_terminal"],
                         "model_quality_verified": False})
    return {
        "harness": {"passed": sum(row["passed"] for row in rows), "total": len(rows), "cases": rows},
        "model_behavior": {"status": "not_evaluated", "verified_sessions": 0, "cases": behavior},
        "model_quality_gate": "pending_verified_live_evidence_and_review",
        "publication_ready": False,
        "publication_blockers": ["classroom_pilot_pending",
                                 "live_model_evidence_pending"],
    }
