"""Учебный host для безопасной демонстрации progressive disclosure.

Это не полный YAML-парсер и не универсальный Agent Skills host. Поддерживается
плоский frontmatter, достаточный для обязательных ``name`` и ``description``.
Scripts обнаруживаются, но никогда не запускаются этим модулем.
"""

from __future__ import annotations

import re
from pathlib import Path
from typing import Any


NAME_PATTERN = re.compile(r"^[a-z0-9]+(?:-[a-z0-9]+)*$")
READABLE_RESOURCE_DIRS = {"references", "assets"}
READABLE_SUFFIXES = {".md", ".txt", ".json", ".csv"}


class SkillFormatError(ValueError):
    """Структура учебного Agent Skill некорректна."""


def _split_skill_file(text: str) -> tuple[dict[str, str], str]:
    lines = text.splitlines()
    if not lines or lines[0].strip() != "---":
        raise SkillFormatError("SKILL.md должен начинаться с YAML frontmatter")
    try:
        end = next(index for index in range(1, len(lines)) if lines[index].strip() == "---")
    except StopIteration as exc:
        raise SkillFormatError("frontmatter не закрыт строкой ---") from exc

    metadata: dict[str, str] = {}
    for line in lines[1:end]:
        if not line.strip() or line.lstrip().startswith("#"):
            continue
        if line[:1].isspace() or ":" not in line:
            raise SkillFormatError(
                "учебный загрузчик поддерживает только плоские поля key: value"
            )
        key, value = line.split(":", 1)
        key = key.strip()
        value = value.strip()
        if len(value) >= 2 and value[0] == value[-1] and value[0] in {'"', "'"}:
            value = value[1:-1]
        if key in metadata:
            raise SkillFormatError("повтор поля frontmatter")
        metadata[key] = value
    return metadata, "\n".join(lines[end + 1 :]).strip() + "\n"


def _validate_metadata(metadata: dict[str, str], directory_name: str) -> None:
    name = metadata.get("name", "")
    description = metadata.get("description", "")
    if not 1 <= len(name) <= 64 or not NAME_PATTERN.fullmatch(name):
        raise SkillFormatError("name не соответствует учебному профилю спецификации")
    if name != directory_name:
        raise SkillFormatError("name должен совпадать с именем каталога")
    if not 1 <= len(description) <= 1024:
        raise SkillFormatError("description должен содержать 1–1024 символа")


def _skill_path(skills_root: str | Path, name: str) -> Path:
    if not isinstance(name, str) or not NAME_PATTERN.fullmatch(name):
        raise SkillFormatError("недопустимое имя skill")
    root = Path(skills_root).resolve()
    candidate = (root / name).resolve()
    try:
        candidate.relative_to(root)
    except ValueError as exc:
        raise SkillFormatError("путь выходит за каталог skills") from exc
    return candidate


def _read_skill(name: str, skills_root: str | Path) -> tuple[dict[str, str], str, Path]:
    directory = _skill_path(skills_root, name)
    skill_file = (directory / "SKILL.md").resolve()
    try:
        skill_file.relative_to(directory)
    except ValueError as exc:
        raise SkillFormatError("SKILL.md выходит за каталог skill") from exc
    if not skill_file.is_file():
        raise SkillFormatError(f"у {name} нет SKILL.md")
    if skill_file.stat().st_size > 256_000:
        raise SkillFormatError("SKILL.md превышает учебный предел размера")
    metadata, instructions = _split_skill_file(skill_file.read_text(encoding="utf-8"))
    _validate_metadata(metadata, directory.name)
    return metadata, instructions, directory


def discover_skills(skills_root: str | Path) -> list[dict[str, str]]:
    """Слой 1: вернуть только ``name`` и ``description`` всех skills."""

    root = Path(skills_root)
    catalog: list[dict[str, str]] = []
    for directory in sorted(path for path in root.iterdir() if path.is_dir()):
        if not (directory / "SKILL.md").is_file():
            continue
        metadata, _, _ = _read_skill(directory.name, root)
        catalog.append(
            {"name": metadata["name"], "description": metadata["description"]}
        )
    return catalog


def load_skill(skills_root: str | Path, name: str) -> dict[str, Any]:
    """Слой 2: после активации вернуть metadata и полные инструкции."""

    metadata, instructions, directory = _read_skill(name, skills_root)
    return {
        "metadata": metadata,
        "instructions": instructions,
        "available_files": list_skill_files(directory),
    }


def list_skill_files(skill_directory: str | Path) -> list[dict[str, str]]:
    """Показать supporting files, но ничего не запускать и не читать."""

    root = Path(skill_directory).resolve()
    files: list[dict[str, str]] = []
    for folder in ("references", "assets", "scripts"):
        directory = root / folder
        if not directory.is_dir():
            continue
        for path in sorted(item for item in directory.rglob("*") if item.is_file()):
            try:
                path.resolve().relative_to(root)
            except ValueError as exc:
                raise SkillFormatError("supporting file выходит за каталог skill") from exc
            files.append({"path": path.relative_to(root).as_posix(), "kind": folder})
    return files


def read_skill_resource(
    skills_root: str | Path, name: str, relative_path: str
) -> dict[str, str]:
    """Слой 3: прочитать только reference или asset по безопасному пути."""

    _, _, directory = _read_skill(name, skills_root)
    raw = Path(relative_path)
    if raw.is_absolute() or ".." in raw.parts or not raw.parts or raw.parts[0] not in READABLE_RESOURCE_DIRS:
        raise SkillFormatError("можно читать только references/ и assets/")
    candidate = (directory / raw).resolve()
    try:
        candidate.relative_to(directory)
    except ValueError as exc:
        raise SkillFormatError("ресурс выходит за каталог skill") from exc
    if candidate.suffix.lower() not in READABLE_SUFFIXES:
        raise SkillFormatError("тип ресурса не входит в allowlist")
    if not candidate.is_file():
        raise SkillFormatError("ресурс не найден")
    if candidate.stat().st_size > 256_000:
        raise SkillFormatError("ресурс превышает учебный предел размера")
    return {"path": raw.as_posix(), "content": candidate.read_text(encoding="utf-8")}
