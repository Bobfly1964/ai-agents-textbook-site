"""Глава 16. Долгая и совместная работа: один источник правил.

Формат ``workspace/my_agent/16_run_plan.json``::

    {"max_sessions": 2, "checkpoint": "drafts/ch16/run_state.json", "owner": "project-team"}

Session — один запуск ``dezhurny.py run``; Inner loop внутри неё — существующий
``run_agent``, второго цикла нет. Между Session harness сохраняет checkpoint
существующим ``save_state``; следующая Session сначала проверяет его
существующим ``validate_project_state``. Outer loop ограничен ``max_sessions``:
после лимита Inner loop не запускается, продолжение решает Owner — человек.

Учебный Handoff отдельного исполнителя (урок 32) проверяет
``validate_architecture_handoff``: у результата есть Owner и основание
``fact | heuristic | hypothesis | forecast``; факт ссылается на артефакт.
Модуль ничего не читает с диска и ничего не печатает.
"""

import re
from pathlib import PurePosixPath

from .state_store import _secret_keys

FIELDS = ("max_sessions", "checkpoint", "owner")
MAX_SESSIONS = 5
# Следующий шаг записывается явно — по терминалу завершённой Session.
NEXT_STEPS = {
    "limit": "Новая Session: снова прочитать карточки и продолжить проверку",
    "needs_input": "Ответить на вопрос, затем новая Session",
    "error": "Устранить причину ошибки, затем новая Session",
}
BASES = ("fact", "heuristic", "hypothesis", "forecast")
HANDOFF_REQUIRED = ("subtask", "executor", "result", "owner", "basis")
HANDOFF_FORBIDDEN = ("transcript", "history", "permissions", "trust")
BLOCKER = re.compile(r"^- `([^`]+)`:")


class RunPlanError(ValueError):
    """План долгой работы или checkpoint не соответствуют формату главы 16."""


def validate_run_plan(value):
    """Разобранный JSON → нормализованный план; иначе RunPlanError. Диск не читается."""

    if not isinstance(value, dict):
        raise RunPlanError("ожидался JSON-объект")
    for key in value:
        if key not in FIELDS:
            raise RunPlanError("неизвестное поле " + str(key))
    for key in FIELDS:
        if key not in value:
            raise RunPlanError("нет поля " + key)
    sessions = value["max_sessions"]
    if type(sessions) is not int or not 1 <= sessions <= MAX_SESSIONS:
        raise RunPlanError("max_sessions — целое от 1 до %d" % MAX_SESSIONS)
    checkpoint = value["checkpoint"]
    # Та же граница, что у checkpoint главы 10: только внутри drafts/; путь проверяется как текст.
    parts = PurePosixPath(checkpoint).parts if isinstance(checkpoint, str) else ()
    if not parts or "\\" in checkpoint or PurePosixPath(checkpoint).is_absolute() \
            or parts[0] != "drafts" or len(parts) < 2 or any(part in ("..", ".") for part in parts):
        raise RunPlanError("checkpoint — относительный путь внутри drafts/")
    owner = value["owner"]
    if not isinstance(owner, str) or not owner.strip():
        raise RunPlanError("owner — непустая строка роли")
    return {"max_sessions": sessions, "checkpoint": checkpoint, "owner": owner.strip()}


def session_number(checkpoint):
    """Номер Session, которая начинается сейчас: без checkpoint — 1, иначе sessions_used + 1."""

    if checkpoint is None:
        return 1
    used = checkpoint.get("sessions_used")
    if type(used) is not int or used < 1:
        raise RunPlanError("missing field sessions_used")
    return used + 1


def _blocked(report):
    """id заблокированных задач из раздела «Блокеры» черновика build_status_report."""

    if not report:
        return []
    section = report.split("## Блокеры", 1)[1] if "## Блокеры" in report else ""
    found = [match.group(1) for match in map(BLOCKER.match, section.splitlines()) if match]
    return list(dict.fromkeys(found))


def build_checkpoint(state_before, result, plan, goal):
    """Состояние после Session: поля Handoff главы 10 и счётчик Outer loop."""

    terminal = result["terminal"]
    state = {
        "project": goal or "Дежурный",
        "goal": goal or "не настроено (глава 1)",
        "status": terminal,
        "blocked_tasks": _blocked(result.get("report")),
        "next_step": NEXT_STEPS.get(terminal, "Передать сводку Owner: " + plan["owner"]),
        "sessions_used": session_number(state_before),
        "last_terminal": terminal,
        "last_scenario": result.get("scenario"),
    }
    if terminal == "needs_input":
        state["pending_question"] = result.get("reason")
    if state["last_scenario"] is None:
        del state["last_scenario"]
    return state


def validate_architecture_handoff(value):
    """Пригоден ли Handoff отдельного исполнителя Owner; пустой список — да."""

    if not isinstance(value, dict):
        return ["handoff должен быть JSON-объектом"]
    if _secret_keys(value):
        return ["forbidden secret field"]
    errors = ["запрещено поле " + key for key in HANDOFF_FORBIDDEN if key in value]
    for key in HANDOFF_REQUIRED:
        if key not in value:
            errors.append("нет " + key)
    if "owner" in value and (not isinstance(value["owner"], str) or not value["owner"].strip()):
        errors.append("нет owner")
    if "result" in value and not isinstance(value["result"], dict):
        errors.append("result должен быть объектом")
    if "basis" in value and value["basis"] not in BASES:
        errors.append("basis — одно из " + ", ".join(BASES))
    if value.get("basis") == "fact" and not (isinstance(value.get("evidence"), str) and value["evidence"].strip()):
        errors.append("basis fact требует evidence")
    return errors
