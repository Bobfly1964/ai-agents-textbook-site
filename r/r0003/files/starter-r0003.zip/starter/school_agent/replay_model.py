"""Авторский сценарий ответа. Не выдаётся за запись реальной модели."""
import copy
import json
from pathlib import Path

from .response import validate_response, ResponseError

class ReplayModel:
    kind = "replay"
    def __init__(self, path, scenario):
        document = json.loads(Path(path).read_text(encoding="utf-8"))
        if document.get("format_version") != 2:
            raise ValueError("нужен replay format_version=2")
        self.provenance = document["provenance"]
        self.rows = document["scenarios"][scenario]
        self.position = 0

    def next(self, context):
        if self.position >= len(self.rows):
            raise ResponseError("replay исчерпан до завершения задачи")
        row = self.rows[self.position]
        if row["expects_phase"] != context["state"]["phase"]:
            raise ResponseError("replay не соответствует наблюдаемому phase")
        self.position += 1
        return validate_response(copy.deepcopy(row["response"]))
