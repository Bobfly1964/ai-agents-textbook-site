"""Ручной обмен: сеть, ключи и выполнение кода из ответа отсутствуют."""
import json

from .response import parse_response, ResponseError

class ManualBridge:
    kind = "bridge"
    def __init__(self, input_fn=input, output_fn=print, session_label="unrecorded"):
        self.input_fn = input_fn
        self.output_fn = output_fn
        self.session_label = session_label

    def next(self, context):
        self.output_fn("\n=== КОНТЕКСТ ДЛЯ ЧАТА ===")
        self.output_fn(json.dumps(context, ensure_ascii=False, indent=2))
        self.output_fn("Проверь отсутствие личных данных. Передай контекст доступной модели.")
        self.output_fn("Вставь один JSON-ответ; отдельная строка . завершает ввод. /cancel — остановка.")
        lines = []
        size = 0
        while True:
            try:
                line = self.input_fn()
            except (EOFError, StopIteration):
                return {"type": "needs_input", "text": "bridge_input_needed: ввод завершён"}
            if line == "/cancel":
                return {"type": "needs_input", "text": "bridge_cancelled: остановлено человеком"}
            if line == ".":
                break
            size += len(line.encode("utf-8")) + 1
            if size > 256_000:
                raise ResponseError("ответ превышает учебный лимит")
            lines.append(line)
        return parse_response("\n".join(lines))
