"""Harness: только он читает файлы, считает шаги и определяет остановку."""
import copy
import json
from pathlib import Path

from .config import MAX_STEPS, MAX_RETRIES, MAX_MODEL_TURNS
from .dispatcher import call_tool
from .paths import PROJECT_ROOT, WORKSPACE_ROOT, resolve_workspace_path
from .replay_model import ReplayModel
from .response import ResponseError, validate_response
from .skill_loader import NAME_PATTERN, discover_skills, load_skill, read_skill_resource, SkillFormatError
from .tools import Tools
from .trace import TraceRecorder
from .validation import TOOL_SCHEMAS

DEFAULT_REPLAY_PATH = PROJECT_ROOT / "data/model_replay.json"

def decide_after_observation(observation, state, max_steps, max_retries):
    if not observation["ok"]:
        error = observation["error"]["code"]
        if error == "missing_data":
            return "needs_input"
        if error != "cards_unavailable" or state["failures"] > max_retries:
            return "error"
    else:
        value = observation["result"]
        if observation["name"] == "validate_task_card" and not value["valid"]:
            return "needs_input"
        if observation["name"] == "read_task_cards" and value["count"] == 0:
            return "needs_input"
        if observation["name"] == "build_status_report":
            return "success"
        if observation["name"] == "propose_status_update":
            return "needs_input"
    return "limit" if state["steps"] >= max_steps else "continue"

def _skill_root_for(skill_roots, name, profile=None):
    """Первый корень, где есть каталог skill; недопустимое имя на диске не проверяется.

    Корни ученика (все, кроме первого) дают skill, только если профиль его подключил.
    """
    if isinstance(name, str) and NAME_PATTERN.fullmatch(name):
        for index, root in enumerate(skill_roots):
            if index and profile is not None and not profile.allows_skill(name):
                continue
            if (root / name / "SKILL.md").is_file():
                return root
    return skill_roots[0]

def _skill_catalog(skill_roots, profile):
    """Каталог skills для модели: skills проекта и подключённые профилем skills ученика."""
    catalog = discover_skills(skill_roots[0])
    for root in skill_roots[1:]:
        catalog += [skill for skill in discover_skills(root) if profile.allows_skill(skill["name"])]
    return catalog

def run_agent(adapter, *, workspace_root=WORKSPACE_ROOT, scenario="success",
              max_steps=MAX_STEPS, max_retries=MAX_RETRIES, trace_relative_path=None,
              profile=None):
    if type(max_steps) is not int or not 1 <= max_steps <= MAX_STEPS:
        raise ValueError("max_steps должен быть от 1 до 5")
    if type(max_retries) is not int or not 0 <= max_retries <= MAX_RETRIES:
        raise ValueError("max_retries должен быть 0 или 1")
    trace_path = None if trace_relative_path is None else resolve_workspace_path(
        trace_relative_path, workspace_root=workspace_root)
    if trace_path is not None:
        allowed = resolve_workspace_path("traces", workspace_root=workspace_root)
        try:
            trace_path.relative_to(allowed)
        except ValueError as exc:
            raise ValueError("trace разрешён только внутри workspace/traces") from exc
        if trace_path.exists():
            raise ValueError("trace уже существует; выбери новое имя запуска")
    trace = TraceRecorder(trace_path)
    tools = Tools(workspace_root, scenario)
    skill_root = PROJECT_ROOT / "skills"
    # Профиль конструктора «Дежурного» (workspace/my_agent/); None — поведение глав 1–13.
    skill_roots = [skill_root] + ([] if profile is None else list(profile.skill_roots))
    state = {"phase": "start", "steps": 0, "failures": 0, "model_turns": 0,
             "context_requests": 0, "done": False}
    terminal, reason, report = None, "", None
    loaded, resources, observations, executed, call_ids = {}, {}, [], [], set()
    catalog = json.loads((PROJECT_ROOT / "data/tool_catalog.json").read_text(encoding="utf-8"))["tools"]
    tool_catalog = [dict(tool, input_schema=TOOL_SCHEMAS[tool["name"]]) for tool in catalog]
    if profile is not None:
        tool_catalog = [tool for tool in tool_catalog if profile.allows(tool["name"])]
        tool_catalog += copy.deepcopy(list(profile.extra_tools))
    response_schema = json.loads((PROJECT_ROOT / "data/response.schema.json").read_text(encoding="utf-8"))
    trace.record("run_started", adapter=adapter.kind, scenario=scenario, limits={
        "steps": max_steps, "failures_before_stop": max_retries + 1, "model_turns": MAX_MODEL_TURNS},
        **({} if profile is None else {"profile": profile.summary()}))
    while not state["done"] and state["steps"] < max_steps:
        if state["model_turns"] >= MAX_MODEL_TURNS:
            terminal, reason = "limit", "model_turn_limit"
            break
        context = {
            "instruction": (PROJECT_ROOT / "data/agent_instruction.md").read_text(encoding="utf-8"),
            "goal": "Проверь карточки и составь черновик статуса проекта. Ничего не изменяй и не отправляй.",
            "state": copy.deepcopy(state),
            "tool_catalog": tool_catalog,
            "response_schema": response_schema,
            "skill_catalog": _skill_catalog(skill_roots, profile),
            "active_skills": copy.deepcopy(loaded),
            "skill_resources": copy.deepcopy(resources),
            "observations": copy.deepcopy(observations),
        }
        state["model_turns"] += 1
        trace.record("context_prepared", layer="metadata_and_requested_content",
                     active_skills=list(loaded), resources=list(resources),
                     observation_count=len(observations))
        try:
            response = validate_response(adapter.next(context))
        except (ResponseError, ValueError, KeyError, OSError) as exc:
            terminal, reason = "error", "invalid_model_response"
            trace.record("response_rejected", message=str(exc))
            break
        trace.record("model_response", initiator="model", response=response)
        kind = response["type"]
        if kind in {"load_skill", "read_skill_resource"}:
            state["context_requests"] += 1
            try:
                name = response["name"]
                if kind == "load_skill":
                    loaded[name] = load_skill(_skill_root_for(skill_roots, name, profile), name)
                    state["phase"] = "skill_loaded"
                    trace.record("skill_loaded", name=name, requested_by="model")
                else:
                    if name not in loaded:
                        raise SkillFormatError("сначала запроси load_skill")
                    key = name + "/" + response["path"]
                    resources[key] = read_skill_resource(_skill_root_for(skill_roots, name, profile), name, response["path"])
                    state["phase"] = "resource_loaded"
                    trace.record("skill_resource_loaded", name=name, path=response["path"], requested_by="model")
            except (SkillFormatError, OSError, UnicodeError) as exc:
                terminal, reason = "error", "skill_request_rejected"
                trace.record("skill_request_rejected", message=str(exc))
                break
            continue
        if kind != "tool_calls":
            terminal = "needs_input" if kind in {"text", "needs_input"} else "error"
            reason = response["text"]
            break
        refused = None if profile is None else next(
            (request for request in response["tool_calls"] if not profile.allows(request.get("name"))), None)
        if refused is not None:
            # Allowlist ученика проверяет harness до диспетчера; ответ целиком не исполняется.
            trace.record("tool_requested", initiator="model", request=refused)
            terminal, reason = "error", "not_in_profile_allowlist"
            trace.record("tool_rejected", code=reason, name=refused.get("name"))
            break
        for request in response["tool_calls"]:
            trace.record("tool_requested", initiator="model", request=request)
            if request["id"] in call_ids:
                terminal, reason = "error", "duplicate_call_id"
                trace.record("tool_rejected", code=reason)
                state["done"] = True
                break
            call_ids.add(request["id"])
            observation = call_tool(request, tools)
            if observation["executed"]:
                state["steps"] += 1
                executed.append(request["name"])
            if not observation["ok"]:
                state["failures"] += 1
                state["phase"] = "tool_error"
            elif request["name"] == "read_task_cards":
                state["phase"] = "cards_read"
            elif request["name"] == "validate_task_card":
                state["phase"] = "cards_validated" if tools.cards and len(tools.validated) == len(tools.cards) else "validating"
            elif request["name"] == "build_status_report":
                state["phase"] = "report_built"
                report = observation["result"]["report"]
            else:
                state["phase"] = "proposal_ready"
            observations.append(observation)
            decision = decide_after_observation(observation, state, max_steps, max_retries)
            trace.record("tool_observation", step=state["steps"], observation=observation,
                         state=copy.deepcopy(state), decision=decision)
            if decision != "continue":
                terminal, reason = decision, "after_observation"
                state["done"] = True
                break
    terminal = terminal or "limit"
    state["done"] = True
    trace.record("run_finished", terminal=terminal, reason=reason, steps=state["steps"])
    return {"adapter": adapter.kind, "terminal": terminal, "reason": reason,
            "steps": state["steps"], "failures": state["failures"], "state": state,
            "executed_tools": executed, "report": report, "trace": trace.events,
            "evidence_kind": "synthetic_script" if adapter.kind == "replay" else "unverified_manual_session",
            "model_quality_verified": False}

def run_replay_scenario(scenario="success", *, workspace_root=WORKSPACE_ROOT,
                        replay_path=DEFAULT_REPLAY_PATH, **kwargs):
    adapter = ReplayModel(replay_path, scenario)
    return run_agent(adapter, workspace_root=workspace_root, scenario=scenario, **kwargs)
