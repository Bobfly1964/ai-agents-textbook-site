"""Применение вне tool allowlist. Только status; approval — строго True."""
from .paths import WORKSPACE_ROOT, resolve_workspace_path
from .state_store import load_state, save_state
from .tools import TASK_ID_PATTERN, validate_card_data, proposal_id


class ApprovalError(RuntimeError):
    pass


def apply_status_update(proposal, *, approved, workspace_root=WORKSPACE_ROOT):
    if approved is not True:
        return {"applied": False, "reason": "человек отклонил изменение"}
    if not isinstance(proposal, dict) or proposal.get("requires_approval") is not True:
        raise ApprovalError("нет approval gate")
    before, after = proposal.get("before"), proposal.get("after")
    if not validate_card_data(before)["valid"] or not validate_card_data(after)["valid"]:
        raise ApprovalError("неверные карточки")
    task_id = before["id"]
    target = f"tasks/{task_id}.json"
    if not TASK_ID_PATTERN.fullmatch(task_id) or proposal.get("target") != target:
        raise ApprovalError("неверная цель изменения")
    if dict(before, status=after["status"]) != after:
        raise ApprovalError("можно изменить только status")
    if not isinstance(proposal.get("reason"), str) or not proposal["reason"].strip():
        raise ApprovalError("нет причины")
    if proposal.get("operation_id") != proposal_id(proposal):
        raise ApprovalError("содержимое предложения изменилось")
    resolve_workspace_path(target, workspace_root=workspace_root, must_exist=True)
    current = load_state(target, workspace_root=workspace_root)
    if current == after:
        return {"applied": False, "already_applied": True, "operation_id": proposal["operation_id"]}
    if current != before:
        raise ApprovalError("карточка изменилась после создания предложения")
    save_state(after, target, workspace_root=workspace_root)
    return {"applied": True, "target": target, "operation_id": proposal["operation_id"]}
