"""Строгий локальный формат ответа; это учебный протокол, не API провайдера."""
import json

class ResponseError(ValueError):
    pass

def validate_response(value):
    if not isinstance(value, dict):
        raise ResponseError("ответ должен быть JSON-объектом")
    kind = value.get("type")
    fields = {
        "tool_calls": {"type", "tool_calls"},
        "load_skill": {"type", "name"},
        "read_skill_resource": {"type", "name", "path"},
        "text": {"type", "text"},
        "needs_input": {"type", "text"},
        "error": {"type", "text"},
    }
    if not isinstance(kind, str) or kind not in fields or set(value) != fields[kind]:
        raise ResponseError("неизвестный тип, пропущенное или лишнее поле ответа")
    if kind == "tool_calls":
        calls = value["tool_calls"]
        if not isinstance(calls, list) or not 1 <= len(calls) <= 4:
            raise ResponseError("нужно от 1 до 4 tool calls")
        ids = []
        for call in calls:
            if not isinstance(call, dict) or set(call) != {"id", "name", "arguments"}:
                raise ResponseError("неверные поля tool call")
            if not all(isinstance(call[key], str) and call[key].strip() for key in ("id", "name")):
                raise ResponseError("id и name должны быть непустыми строками")
            if not isinstance(call["arguments"], dict):
                raise ResponseError("arguments должен быть объектом")
            ids.append(call["id"])
        if len(set(ids)) != len(ids):
            raise ResponseError("повтор id tool call")
    else:
        for key in fields[kind] - {"type"}:
            if not isinstance(value[key], str) or not value[key].strip():
                raise ResponseError(key + " должен быть непустой строкой")
    return value

def parse_response(raw):
    if not isinstance(raw, str) or len(raw.encode("utf-8")) > 256_000:
        raise ResponseError("ответ превышает лимит или не является текстом")
    def pairs(items):
        result = {}
        for key, value in items:
            if key in result:
                raise ResponseError("повтор JSON-ключа: " + key)
            result[key] = value
        return result
    def constant(value):
        raise ResponseError("нечисловая константа JSON: " + value)
    try:
        return validate_response(json.loads(raw, object_pairs_hook=pairs, parse_constant=constant))
    except (json.JSONDecodeError, RecursionError) as exc:
        raise ResponseError("нужен один JSON-объект без Markdown-ограждения") from exc
