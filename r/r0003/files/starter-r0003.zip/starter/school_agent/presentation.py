"""Вывод и CLI для ученика; техническая обвязка вынесена из entrypoints."""
import argparse
import json
from .config import ERROR_CARDS
from .tools import Tools, ToolDataError
from .paths import PROJECT_ROOT, WORKSPACE_ROOT

def read_for_demo(scenario):
    try:
        return Tools(scenario=scenario).read_task_cards()
    except ToolDataError:
        return {"error": ERROR_CARDS}

def chat_main(run_demo):
    parser = argparse.ArgumentParser()
    parser.add_argument("--scenario", choices=["normal", "missing_file"], default="normal")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()
    result = run_demo("Прочитай карточки проекта.", args.scenario)
    if args.json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        print(result["message"])
        if "error" in result["observation"]:
            print(result["observation"]["error"])
        else:
            print("Наблюдение tool: прочитано карточек: " + str(result["observation"]["count"]))

def agent_main():
    from .agent import run_replay_scenario, run_agent
    from .bridge import ManualBridge
    parser = argparse.ArgumentParser()
    parser.add_argument("--adapter", choices=["replay", "bridge", "live"], default="replay")
    parser.add_argument("--scenario", default="success")
    parser.add_argument("--trace", help="новый путь внутри workspace/traces")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()
    if args.adapter == "live":
        parser.error("provider-specific live не включён; используй --adapter bridge")
    if args.adapter == "bridge" and args.scenario != "success":
        parser.error("ручной мост использует только базовые синтетические карточки success")
    try:
        result = (run_replay_scenario(args.scenario, trace_relative_path=args.trace)
                  if args.adapter == "replay" else run_agent(ManualBridge(), trace_relative_path=args.trace))
    except (ValueError, KeyError, OSError) as exc:
        parser.error(str(exc))
    if args.json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        print("Режим: " + result["adapter"])
        for event in result["trace"]:
            if event["type"] == "tool_observation":
                value = event["payload"]
                print("Шаг " + str(value["step"]) + " | " + value["observation"]["name"] +
                      " | " + value["decision"])
        print("Остановка: " + result["terminal"])
        if result["report"]:
            print(result["report"], end="")
        print("Качество модели не подтверждено этим техническим прогоном.")

def skill_main():
    from .skill_loader import discover_skills, load_skill, read_skill_resource
    root = PROJECT_ROOT / "skills"
    print("1. До запроса: только metadata")
    print(json.dumps(discover_skills(root), ensure_ascii=False, indent=2))
    print("2. Учебный запрос загрузки: инструкции")
    print(load_skill(root, "project-status")["instructions"])
    print("3. Учебный запрос ресурса: reference")
    print(read_skill_resource(root, "project-status", "references/report-template.md")["content"])
    print("Это ручная демонстрация слоёв, а не выбор модели. См. agent_demo.py.")

def _format_summary(result):
    """Три строки из того же результата: счёт harness, статус модели, готовность."""
    harness, behavior = result["harness"], result["model_behavior"]
    scripted = sum(case["status"] == "scripted" for case in behavior["cases"])
    blockers = result["publication_blockers"]
    return "\n".join([
        "harness: " + str(harness["passed"]) + "/" + str(harness["total"]) + " passed",
        "model_behavior: " + behavior["status"] +
        " (verified_sessions: " + str(behavior["verified_sessions"]) +
        "; scripted: " + str(scripted) + ", excluded from scoring)",
        "publication_ready: " + json.dumps(result["publication_ready"]) +
        (" (" + ", ".join(blockers) + ")" if blockers else ""),
    ])

def eval_main(argv=None):
    from .evals import run_eval_cases
    parser = argparse.ArgumentParser()
    parser.add_argument("--summary", action="store_true",
                        help="три строки вместо полного отчёта; счёт тот же")
    args = parser.parse_args(argv)
    result = run_eval_cases()
    print(_format_summary(result) if args.summary
          else json.dumps(result, ensure_ascii=False, indent=2))
    raise SystemExit(0 if result["harness"]["passed"] == result["harness"]["total"] else 1)
