"""Глава 14. Учебная политика permissions: один источник правил для approval gate.

Формат ``workspace/my_agent/14_permissions.json``::

    {"default": "deny", "task_cards": "read_only", "status_update": "approval_required"}

``default`` и ``task_cards`` — явные объявления из матрицы урока 27: у них одно
допустимое значение, и программа проверяет, что их не ослабили.
``status_update`` — настоящий выбор: ``approval_required`` или ``deny``.
Автоматического применения изменения состояния нет ни при каком значении.
Модуль ничего не читает с диска и ничего не печатает. Это учебный формат, а не
модель прав реального продукта и не OS-sandbox.
"""

FIELDS = ("default", "task_cards", "status_update")
STATUS_UPDATE_CHOICES = ("approval_required", "deny")


class PermissionsError(ValueError):
    """Политика не соответствует учебному формату главы 14."""


def validate_permissions_config(value):
    """Разобранный JSON → нормализованная политика; иначе PermissionsError."""

    if not isinstance(value, dict):
        raise PermissionsError("ожидался JSON-объект")
    for key in value:
        if key not in FIELDS:
            raise PermissionsError("неизвестное поле " + str(key))
    for key in FIELDS:
        if key not in value:
            raise PermissionsError("нет поля " + key)
    if value["default"] != "deny":
        raise PermissionsError("default должен быть deny")
    if value["task_cards"] != "read_only":
        raise PermissionsError("task_cards должен быть read_only")
    if value["status_update"] not in STATUS_UPDATE_CHOICES:
        raise PermissionsError("автоматическое применение изменения состояния запрещено")
    return {key: value[key] for key in FIELDS}


def approval_allowed(policy):
    """Открыт ли approval gate: (можно ли применить после решения человека, причина)."""

    if policy is None:
        return False, "политики нет: default deny"
    if policy["status_update"] == "deny":
        return False, "политика status_update = deny"
    return True, "approval_required"
