"""Внешнее состояние проекта с атомарной записью внутри workspace."""

from __future__ import annotations

import json
import os
import tempfile
from pathlib import Path
from typing import Any

from .paths import WORKSPACE_ROOT, resolve_workspace_path
from .trace import SENSITIVE_PARTS


def load_state(
    relative_path: str = "project_state.json",
    *,
    workspace_root: str | Path = WORKSPACE_ROOT,
) -> dict[str, Any]:
    path = resolve_workspace_path(
        relative_path, workspace_root=workspace_root, must_exist=True
    )
    try:
        with path.open("r", encoding="utf-8") as source:
            value = json.load(source)
    except json.JSONDecodeError as exc:
        raise ValueError("файл состояния содержит некорректный JSON") from exc
    if not isinstance(value, dict):
        raise ValueError("состояние должно быть JSON-объектом")
    return value


def save_state(
    state: dict[str, Any],
    relative_path: str = "project_state.json",
    *,
    workspace_root: str | Path = WORKSPACE_ROOT,
) -> Path:
    if not isinstance(state, dict):
        raise TypeError("состояние должно быть словарём")
    path = resolve_workspace_path(relative_path, workspace_root=workspace_root)
    path.parent.mkdir(parents=True, exist_ok=True)
    descriptor, temporary_name = tempfile.mkstemp(
        prefix=f".{path.name}.", suffix=".tmp", dir=path.parent
    )
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8") as target:
            json.dump(state, target, ensure_ascii=False, indent=2, sort_keys=True)
            target.write("\n")
        os.replace(temporary_name, path)
    except Exception:
        try:
            os.unlink(temporary_name)
        except FileNotFoundError:
            pass
        raise
    return path


# Минимальное состояние для продолжения работы после перезапуска (глава 10).
REQUIRED_FIELDS = ("project", "goal", "status", "next_step")
HANDOFF_FIELDS = ("project", "goal", "status", "blocked_tasks", "pending_question", "next_step")


def _secret_keys(value: Any) -> list[str]:
    found: list[str] = []
    if isinstance(value, dict):
        for key, child in value.items():
            if any(part in str(key).lower() for part in SENSITIVE_PARTS):
                found.append(str(key))
            found.extend(_secret_keys(child))
    elif isinstance(value, list):
        for item in value:
            found.extend(_secret_keys(item))
    return found


def validate_project_state(state: Any) -> list[str]:
    """Пригодно ли сохранённое состояние для продолжения; пустой список — да."""

    if not isinstance(state, dict):
        return ["состояние должно быть JSON-объектом"]
    if _secret_keys(state):
        return ["forbidden secret field"]
    errors = [f"missing field {name}" for name in REQUIRED_FIELDS
              if not isinstance(state.get(name), str) or not state[name].strip()]
    blocked = state.get("blocked_tasks", [])
    if not isinstance(blocked, list) or not all(isinstance(item, str) for item in blocked):
        errors.append("blocked_tasks must be a list of strings")
    return errors


def build_handoff(state: dict[str, Any]) -> dict[str, Any]:
    """Передача продолжения: только поля HANDOFF_FIELDS; без секретов и истории."""

    errors = validate_project_state(state)
    if errors:
        raise ValueError(errors[0])
    return {name: state[name] for name in HANDOFF_FIELDS if name in state}
