"""Конструктор «Дежурного» (EC-24): чтение папки ``workspace/my_agent/``.

Ученик не пишет код harness — он кладёт в ``my_agent/`` конфигурацию и
небольшие артефакты, а этот модуль проверяет их и собирает профиль для
существующего ``run_agent``. Отсутствующий файл — значение по умолчанию и
строка «не настроено (глава N)». Код ученика (``08_my_tool.py``) не
исполняется: из него читаются имя и описание функции через ``ast``. Политику
главы 14 проверяет ``school_agent.permissions``. Решение аудита главы 15
применяет ``school_agent.trust``. План долгой работы главы 16 проверяет
``school_agent.long_work``, метку Release candidate главы 17 —
``school_agent.release_candidate``, снимки версий главы 13 —
``school_agent.versions``.
"""
import ast
import json
import re

from .config import MAX_RETRIES, MAX_STEPS
from .dispatcher import AVAILABLE_TOOLS
from .paths import PROJECT_ROOT, WORKSPACE_ROOT, resolve_workspace_path
from .permissions import PermissionsError, validate_permissions_config
from .trust import TrustError, connected_skills, validate_trust_config
from .long_work import RunPlanError, validate_run_plan
from .release_candidate import ReleaseCandidateError, validate_release_candidate
from .versions import VersionsError, validate_versions_dir
from .skill_loader import SkillFormatError, discover_skills, load_skill

DEFAULT_DIR = "my_agent"
REPLAY_SCENARIOS = tuple(sorted(json.loads(
    (PROJECT_ROOT / "data" / "model_replay.json").read_text(encoding="utf-8"))["scenarios"]))
TERMINALS = ("success", "needs_input", "error", "limit")
CONTRACT_SECTIONS = ("Цель", "Вход", "Результат", "Готово, когда", "Запрещено")
TOOL_NAME = re.compile(r"^[a-z][a-z0-9_]*$")

# Файл → глава → что даёт. Порядок — порядок глав; это и есть строки ``status``.
FILES = (
    ("01_goal.md", 1, "run: заголовок цитирует первую строку цели"),
    ("02_stop_policy.json", 2, "run: предел шагов и повторов"),
    ("03_workspace_policy.json", 3, "run: сохранение черновика только в разрешённую область"),
    ("05_task_contract.md", 5, "run: contract ok/violated по разделу «Готово, когда»"),
    ("07_tools.json", 7, "run: tool вне списка отклоняется до диспетчера"),
    ("08_my_tool.py", 8, "каталог tools: описание функции ученика"),
    ("09_skills", 9, "каталог skills: skill ученика, три слоя загрузки"),
    ("10_state.json", 10, "run: второй запуск видит первый"),
    ("11_evals.json", 11, "eval: таблица случаев ученика"),
    ("12_trace.json", 12, "run: trace в workspace/traces/dezhurny/; trace --last"),
    ("13_versions", 13, "version save сохраняет снимок конфигурации"),
    ("14_permissions.json", 14, "approval gate закрыт: изменение статуса не применяется"),
    ("15_trust.json", 15, "skills из 09_skills подключаются без записанного решения аудита"),
    ("16_run_plan.json", 16, "run — одна Session без checkpoint"),
    ("17_release_candidate.json", 17, "run: печатает метку Release candidate; изменение любого файла после фиксации делает её недействительной"),
)
# Механизм резерва остаётся; строка 13 получила формат при ретрофите главы 13.
RESERVED = set()
SERVICE_ENTRIES = {"README.md", "templates", "examples"}


class ConfigError(ValueError):
    """Файл my_agent/ не соответствует своему формату."""


class HarnessProfile:
    """То, что ``run_agent(profile=…)`` берёт из my_agent/; остальное — вне цикла."""

    def __init__(self, allowed_tools=None, extra_tools=(), skill_roots=(), skill_names=None):
        self.allowed_tools = None if allowed_tools is None else frozenset(allowed_tools)
        self.extra_tools = tuple(extra_tools)
        self.skill_roots = tuple(skill_roots)
        # None — подключены все skills ученика; иначе — только решённые аудитом (глава 15).
        self.skill_names = None if skill_names is None else frozenset(skill_names)

    def allows(self, name):
        return self.allowed_tools is None or name in self.allowed_tools

    def allows_skill(self, name):
        return self.skill_names is None or name in self.skill_names

    def summary(self):
        return {
            "allowed_tools": None if self.allowed_tools is None else sorted(self.allowed_tools),
            "extra_tools": [tool["name"] for tool in self.extra_tools],
            "skill_roots": len(self.skill_roots),
            "skill_names": None if self.skill_names is None else sorted(self.skill_names),
        }


def _json(path, name):
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except ValueError as exc:
        raise ConfigError(name + ": не JSON") from exc
    if not isinstance(value, dict):
        raise ConfigError(name + ": ожидался JSON-объект")
    return value


def _only_keys(value, name, allowed):
    extra = sorted(set(value) - set(allowed))
    if extra:
        raise ConfigError(name + ": неизвестное поле " + extra[0])


def _goal(path):
    for line in path.read_text(encoding="utf-8").splitlines():
        text = line.strip().lstrip("#").strip()
        if text:
            return text
    raise ConfigError("01_goal.md: файл пуст")


def _stop_policy(path):
    value = _json(path, "02_stop_policy.json")
    _only_keys(value, "02_stop_policy.json", ("max_steps", "max_retries"))
    steps = value.get("max_steps", MAX_STEPS)
    retries = value.get("max_retries", MAX_RETRIES)
    if type(steps) is not int or not 1 <= steps <= MAX_STEPS:
        raise ConfigError("02_stop_policy.json: max_steps должен быть от 1 до %d" % MAX_STEPS)
    if type(retries) is not int or not 0 <= retries <= MAX_RETRIES:
        raise ConfigError("02_stop_policy.json: max_retries должен быть от 0 до %d" % MAX_RETRIES)
    return {"max_steps": steps, "max_retries": retries}


def _workspace_policy(path):
    name = "03_workspace_policy.json"
    value = _json(path, name)
    _only_keys(value, name, ("allowed_operations", "writable_prefix", "save_report_to"))
    operations = value.get("allowed_operations", ["read"])
    if not isinstance(operations, list) or not operations or \
            any(item not in ("read", "write") for item in operations):
        raise ConfigError(name + ": allowed_operations — список из read и write")
    prefix = value.get("writable_prefix", "drafts/")
    # Область записи главы 3 — только drafts/; ученик может её сузить, но не расширить.
    if not isinstance(prefix, str) or not prefix.startswith("drafts/") or not prefix.endswith("/"):
        raise ConfigError(name + ": writable_prefix должен лежать внутри drafts/ и кончаться на /")
    target = value.get("save_report_to", prefix + "dezhurny_report.md")
    if not isinstance(target, str) or not target.strip():
        raise ConfigError(name + ": save_report_to — непустой относительный путь")
    return {"allowed_operations": sorted(set(operations)), "writable_prefix": prefix,
            "save_report_to": target}


def _task_contract(path):
    sections, current = {}, None
    for line in path.read_text(encoding="utf-8").splitlines():
        if line.startswith("## "):
            current = line[3:].strip()
            sections[current] = []
        elif current is not None and line.strip().startswith("- "):
            sections[current].append(line.strip()[2:].strip())
    missing = [title for title in CONTRACT_SECTIONS if title not in sections]
    if missing:
        raise ConfigError("05_task_contract.md: нет раздела «## " + missing[0] + "»")
    done_when = [item for item in sections["Готово, когда"] if item]
    if not done_when:
        raise ConfigError("05_task_contract.md: в разделе «Готово, когда» нет пунктов «- …»")
    return {"done_when": done_when}


def _my_tool(path):
    try:
        tree = ast.parse(path.read_text(encoding="utf-8"), filename="08_my_tool.py")
    except SyntaxError as exc:
        raise ConfigError("08_my_tool.py: синтаксическая ошибка в строке " + str(exc.lineno)) from exc
    functions = [node for node in tree.body if isinstance(node, ast.FunctionDef)]
    if len(functions) != 1:
        raise ConfigError("08_my_tool.py: нужна ровно одна функция верхнего уровня")
    function = functions[0]
    description = (ast.get_docstring(function) or "").strip()
    if not TOOL_NAME.fullmatch(function.name):
        raise ConfigError("08_my_tool.py: имя функции — строчные латинские буквы, цифры и _")
    if function.name in AVAILABLE_TOOLS:
        raise ConfigError("08_my_tool.py: имя " + function.name + " уже занято доменным tool")
    if not description:
        raise ConfigError("08_my_tool.py: у функции нет докстринга-описания")
    return {"name": function.name, "description": " ".join(description.split())}


def _skills(path):
    project = {skill["name"] for skill in discover_skills(PROJECT_ROOT / "skills")}
    try:
        catalog = discover_skills(path)
        for skill in catalog:
            load_skill(path, skill["name"])
    except SkillFormatError as exc:
        raise ConfigError("09_skills: " + str(exc)) from exc
    if not catalog:
        raise ConfigError("09_skills: нет ни одного каталога <имя>/SKILL.md")
    clash = sorted(project & {skill["name"] for skill in catalog})
    if clash:
        raise ConfigError("09_skills: имя " + clash[0] + " уже есть у skill проекта")
    return {"root": path, "catalog": catalog}


def _state(path):
    value = _json(path, "10_state.json")
    runs = value.get("runs", 0)
    if type(runs) is not int or runs < 0:
        raise ConfigError("10_state.json: runs — неотрицательное целое")
    return value


def _evals(path):
    name = "11_evals.json"
    value = _json(path, name)
    cases = value.get("cases")
    if not isinstance(cases, list) or not cases:
        raise ConfigError(name + ": нет списка cases")
    ids = []
    for case in cases:
        if not isinstance(case, dict) or not isinstance(case.get("id"), str):
            raise ConfigError(name + ": у случая нет id")
        if case.get("scenario") not in REPLAY_SCENARIOS:
            raise ConfigError(name + ": " + case["id"] + ": scenario — один из " + ", ".join(REPLAY_SCENARIOS))
        if case.get("expected_terminal") not in TERMINALS:
            raise ConfigError(name + ": " + case["id"] + ": expected_terminal — один из " + ", ".join(TERMINALS))
        ids.append(case["id"])
    if len(set(ids)) != len(ids):
        raise ConfigError(name + ": id случаев повторяются")
    return {"cases": cases}


def _trace(path):
    value = _json(path, "12_trace.json")
    _only_keys(value, "12_trace.json", ("enabled",))
    if not isinstance(value.get("enabled"), bool):
        raise ConfigError("12_trace.json: enabled — true или false")
    return value


def read_permissions_file(path):
    """14_permissions.json → политика; единственный читатель для status, run и permissions_demo."""

    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except ValueError as exc:
        raise PermissionsError("не JSON") from exc
    return validate_permissions_config(value)


def _permissions(path):
    try:
        return read_permissions_file(path)
    except PermissionsError as exc:
        raise ConfigError("14_permissions.json: " + str(exc)) from exc


def read_trust_file(path):
    """15_trust.json → решение аудита; единственный читатель для status, run и trust_demo."""

    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except ValueError as exc:
        raise TrustError("не JSON") from exc
    return validate_trust_config(value)


def _trust(path):
    try:
        return read_trust_file(path)
    except TrustError as exc:
        raise ConfigError("15_trust.json: " + str(exc)) from exc


def read_run_plan_file(path):
    """16_run_plan.json → план долгой работы; единственный читатель для status и run."""

    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except ValueError as exc:
        raise RunPlanError("не JSON") from exc
    return validate_run_plan(value)


def _run_plan(path):
    try:
        return read_run_plan_file(path)
    except RunPlanError as exc:
        raise ConfigError("16_run_plan.json: " + str(exc)) from exc


def _release_candidate(path):
    """17_release_candidate.json → метка и число зафиксированных файлов, если отпечаток совпадает."""

    value = _json(path, "17_release_candidate.json")
    try:
        errors = validate_release_candidate(value, path.parent)
    except ReleaseCandidateError as exc:
        errors = [str(exc)]
    if errors:
        raise ConfigError("17_release_candidate.json: " + errors[0])
    return {"label": value["label"], "files": len(value["files"])}


def _versions(path):
    """13_versions/ → манифесты снимков; каждый снимок сверяется со своим манифестом."""

    try:
        return validate_versions_dir(path.parent)
    except VersionsError as exc:
        raise ConfigError(str(exc)) from exc


READERS = {
    "01_goal.md": _goal, "02_stop_policy.json": _stop_policy,
    "03_workspace_policy.json": _workspace_policy, "05_task_contract.md": _task_contract,
    "08_my_tool.py": _my_tool, "09_skills": _skills, "10_state.json": _state,
    "11_evals.json": _evals, "12_trace.json": _trace, "13_versions": _versions,
    "14_permissions.json": _permissions,
    "15_trust.json": _trust, "16_run_plan.json": _run_plan,
    "17_release_candidate.json": _release_candidate,
}


def _tools(path, my_tool):
    name = "07_tools.json"
    value = _json(path, name)
    _only_keys(value, name, ("enabled",))
    enabled = value.get("enabled")
    if not isinstance(enabled, list) or not enabled or not all(isinstance(item, str) for item in enabled):
        raise ConfigError(name + ": enabled — непустой список имён tools")
    known = list(AVAILABLE_TOOLS) + ([my_tool["name"]] if my_tool else [])
    for item in enabled:
        if item not in known:
            raise ConfigError(name + ": неизвестный tool " + item + " (есть: " + ", ".join(known) + ")")
    return {"enabled": list(dict.fromkeys(enabled))}


def read_my_agent(relative_dir=DEFAULT_DIR, *, workspace_root=WORKSPACE_ROOT):
    """Строки status и разобранные значения. Ошибка файла — строка status, а не исключение."""

    directory = resolve_workspace_path(relative_dir, workspace_root=workspace_root, must_exist=True)
    if not directory.is_dir():
        raise ConfigError(str(relative_dir) + ": ожидалась папка my_agent")
    values, rows = {}, []
    for name, chapter, effect in FILES:
        path = directory / name
        row = {"file": name, "chapter": chapter, "effect": effect, "state": "not_configured", "detail": ""}
        if path.exists():
            try:
                if name in RESERVED:
                    row.update(state="reserved", detail="сейчас не читается")
                elif name == "07_tools.json":
                    # 08 читается позже по порядку глав; его ошибку покажет строка 08.
                    try:
                        my_tool = _my_tool(directory / "08_my_tool.py") \
                            if (directory / "08_my_tool.py").exists() else None
                    except ConfigError:
                        my_tool = None
                    values[name] = _tools(path, my_tool)
                    row["state"] = "configured"
                else:
                    values[name] = READERS[name](path)
                    row["state"] = "configured"
            except (ConfigError, OSError, UnicodeError) as exc:
                row.update(state="error", detail=str(exc))
        rows.append(row)
    trust = values.get("15_trust.json")
    if trust is not None:
        # Решение аудита относится к skills, которые реально лежат в 09_skills.
        found = {skill["name"] for skill in values.get("09_skills", {}).get("catalog", [])}
        unknown = sorted(name for name in trust["skills"] if name not in found)
        if unknown:
            del values["15_trust.json"]
            row = next(row for row in rows if row["file"] == "15_trust.json")
            row.update(state="error", detail="15_trust.json: нет skill " + unknown[0] + " в 09_skills")
    known = {name for name, _, _ in FILES} | SERVICE_ENTRIES
    unknown = sorted(entry.name for entry in directory.iterdir()
                     if entry.name not in known and not entry.name.startswith("."))
    return {"dir": directory, "rows": rows, "values": values, "unknown": unknown}


def require_valid(config):
    """Для run и eval: любой файл с ошибкой останавливает запуск до цикла."""

    for row in config["rows"]:
        if row["state"] == "error":
            raise ConfigError(row["detail"])
    return config


def build_profile(config):
    """Профиль для run_agent; None, если 07–09 ничего не меняют в цикле."""

    values = config["values"]
    tools, my_tool, skills = (values.get("07_tools.json"), values.get("08_my_tool.py"),
                              values.get("09_skills"))
    extra = []
    # Tool ученика регистрируется, только если его имя есть в allowlist 07_tools.json.
    if my_tool and tools and my_tool["name"] in tools["enabled"]:
        extra.append({"name": my_tool["name"], "description": my_tool["description"],
                      "input_schema": {"type": "object"}, "access": "not-executable",
                      "note": "описание ученика; dispatcher главы 7 исполняет только четыре доменных tools"})
    if tools is None and not extra and skills is None:
        return None
    names = None
    if skills is not None and values.get("15_trust.json") is not None:
        names = skill_connection(config)[0]
    return HarnessProfile(allowed_tools=None if tools is None else tools["enabled"],
                          extra_tools=extra,
                          skill_roots=() if skills is None else (skills["root"],),
                          skill_names=names)


def skill_connection(config):
    """(подключённые, [(имя, причина)]) для skills ученика по решению аудита 15_trust.json."""

    values = config["values"]
    found = [skill["name"] for skill in values.get("09_skills", {}).get("catalog", [])]
    return connected_skills(values.get("15_trust.json"), found)


def contract_check(done_when, report):
    """Пункты «Готово, когда», которых нет в черновике; пусто — contract ok."""

    return [item for item in done_when if not report or item not in report]


def check_save(policy, *, workspace_root=WORKSPACE_ROOT):
    """Можно ли сохранить черновик: те же три отказа, что у гейта главы 3."""

    target = policy["save_report_to"]
    if "write" not in policy["allowed_operations"]:
        return "denied", "operation_not_allowed", target
    try:
        path = resolve_workspace_path(target, workspace_root=workspace_root)
    except ValueError:
        return "denied", "path_outside_workspace", target
    root = resolve_workspace_path(".", workspace_root=workspace_root)
    if not path.relative_to(root).as_posix().startswith(policy["writable_prefix"]):
        return "denied", "path_not_writable", target
    return "allowed", "inside_writable_prefix", target
