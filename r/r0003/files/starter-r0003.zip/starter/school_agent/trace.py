"""Trace публичных событий. Фильтр по ключам НЕ гарантирует удаление секретов из строк."""

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


SENSITIVE_PARTS = ("password", "token", "secret", "api_key", "cookie")


def redact(value: Any) -> Any:
    if isinstance(value, dict):
        clean: dict[str, Any] = {}
        for key, child in value.items():
            lowered = str(key).lower()
            clean[key] = (
                "[REDACTED]"
                if any(part in lowered for part in SENSITIVE_PARTS)
                else redact(child)
            )
        return clean
    if isinstance(value, list):
        return [redact(item) for item in value]
    return value


class TraceRecorder:
    """Хранит события в памяти и, при заданном пути, добавляет их в JSONL."""

    def __init__(self, path: str | Path | None = None) -> None:
        self.path = Path(path) if path is not None else None
        self.events: list[dict[str, Any]] = []

    def record(self, event_type: str, *, initiator: str = "harness", **payload: Any) -> dict[str, Any]:
        event = {
            "event_id": len(self.events) + 1,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "type": event_type,
            "initiator": initiator,
            "payload": redact(payload),
        }
        self.events.append(event)
        if self.path is not None:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            with self.path.open("a", encoding="utf-8") as target:
                target.write(json.dumps(event, ensure_ascii=False) + "\n")
        return event
