"""Глава 8: паспорт tool и локальная проверка границ на заранее заданных случаях.

Здесь ничего не исполняется: ни один доменный tool не вызывается, сеть не
используется. Учебный маршрутизатор — прозрачное правило над текстом
description, а не модель; его выбор не является свидетельством model behavior.
"""
import json
import re

from .dispatcher import AVAILABLE_TOOLS
from .paths import PROJECT_ROOT
from .validation import validate_tool_arguments

CH08_ROOT = PROJECT_ROOT / "workspace" / "ch08"
PASSPORTS_PATH = CH08_ROOT / "tool_passports.json"
CASES_PATH = CH08_ROOT / "cases.json"

WHEN = re.compile(r"Используй для ([^.]+)\.")
WHEN_NOT = re.compile(r"Не используй для ([^.]+)\.")
WORD = re.compile(r"[0-9a-zа-я_-]+")
STEM = 4


def load_catalog(path=PASSPORTS_PATH):
    """Паспорта по именам; только имена из allowlist."""

    with open(path, encoding="utf-8") as source:
        tools = json.load(source)["tools"]
    catalog = {tool["name"]: tool for tool in tools}
    unknown = set(catalog) - set(AVAILABLE_TOOLS)
    if unknown:
        raise ValueError("паспорт для имени вне allowlist: " + ", ".join(sorted(unknown)))
    return catalog


def _load_cases():
    with open(CASES_PATH, encoding="utf-8") as source:
        return json.load(source)


def _stems(text):
    """Основы слов: первые четыре буквы каждого слова длиной от четырёх букв."""

    words = WORD.findall(text.lower().replace("ё", "е"))
    return {word[:STEM] for word in words if len(word) >= STEM}


def _boundary(description):
    when = WHEN.search(description)
    when_not = WHEN_NOT.search(description)
    return (when.group(1) if when else ""), (when_not.group(1) if when_not else "")


def _schema_summary(schema):
    required = schema.get("required", [])
    parts = []
    for name, rule in schema.get("properties", {}).items():
        details = [rule.get("type", "any")]
        if "minLength" in rule:
            details.append("minLength " + str(rule["minLength"]))
        if "enum" in rule:
            details.append("enum " + "/".join(rule["enum"]))
        details.append("обязательное" if name in required else "необязательное")
        parts.append(name + ": " + ", ".join(details))
    if not parts:
        parts.append("полей нет")
    if schema.get("additionalProperties") is False:
        parts.append("лишние поля запрещены")
    return "; ".join(parts)


def build_tool_passport(name, catalog, schemas):
    """Паспорт одного разрешённого tool: описание и сводка schema, без выполнения."""

    if name not in AVAILABLE_TOOLS or name not in catalog:
        raise ValueError("нет паспорта для " + str(name))
    entry = catalog[name]
    when, when_not = _boundary(entry["description"])
    return {
        "name": name,
        "scope": entry["scope"],
        "contract": dict(entry["contract"]),
        "description": entry["description"],
        "when": when,
        "when_not": when_not,
        "schema": _schema_summary(schemas[name]),
    }


def select_tool(request, catalog):
    """Учебное правило: совпадения основ с «когда применять» минус совпадения с «когда не».

    Выбирается единственный tool с наибольшим положительным счётом; при
    ничьей или нулевом счёте выбора нет. Имя сценария правило не читает.
    """

    words = _stems(request)
    scores = {}
    for name, entry in catalog.items():
        when, when_not = _boundary(entry["description"])
        scores[name] = len(words & _stems(when)) - len(words & _stems(when_not))
    best = max(scores.values())
    leaders = [name for name, score in scores.items() if score == best]
    selected = leaders[0] if best > 0 and len(leaders) == 1 else None
    return selected, scores


def check_route_case(case_name, catalog):
    """Один заранее заданный случай выбора; доменные tools не вызываются."""

    cases = _load_cases()["route"]
    if case_name not in cases:
        raise ValueError("неизвестный случай: " + str(case_name))
    case = cases[case_name]
    selected, scores = select_tool(case["request"], catalog)
    return {
        "case": case_name,
        "kind": case["kind"],
        "request": case["request"],
        "expected": case["expected"],
        "selected": selected,
        "scores": scores,
        "ok": selected == case["expected"],
    }


def _check_error_case(case_name, case):
    errors = validate_tool_arguments(case["tool"], case["arguments"])
    observed = "invalid" if errors else "valid"
    return {
        "case": case_name,
        "kind": case["kind"],
        "tool": case["tool"],
        "expected": case["expected"],
        "observed": observed,
        "errors": errors,
        "ok": observed == case["expected"],
    }


def run_quality_suite(catalog):
    """Три обязательных случая главы: positive, negative, error."""

    cases = _load_cases()
    results = [check_route_case(name, catalog) for name in cases["route"]]
    results += [_check_error_case(name, case) for name, case in cases["error"].items()]
    order = {"positive": 0, "negative": 1, "error": 2}
    results.sort(key=lambda item: order[item["kind"]])
    return {
        "results": results,
        "passed": sum(item["ok"] for item in results),
        "total": len(results),
    }

