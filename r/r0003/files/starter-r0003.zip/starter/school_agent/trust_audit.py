"""Глава 15. Учебная линза над недоверенным содержимым: только чтение.

``audit_untrusted_document`` читает карточку существующим ``Tools.read_task_cards``
(доверие назначает harness) и для каждого требования из авторской разметки
вызывает существующий гейт: диспетчер главы 7, схему главы 6, approval gate
главы 14. Какие фразы — требования, программа не угадывает: это разметка автора.

``audit_skill_sample`` и ``audit_mcp_sample`` — статический аудит по
фиксированным признакам: файлы читаются как текст, scripts не запускаются,
сеть не используется. Чистый отчёт не доказывает безопасность компонента.
"""
import json
import re

from .dispatcher import AVAILABLE_TOOLS, call_tool
from .paths import PROJECT_ROOT, WORKSPACE_ROOT, resolve_workspace_path
from .permissions import approval_allowed
from .skill_loader import SkillFormatError, load_skill
from .tools import Tools
from .validation import validate_tool_arguments

DOCUMENT_CASES = {
    "task-901": {"scenario": "injection", "card": "scenarios/injection/task-901.json",
                 "annotations": "ch15/cases/task-901.annotations.json"},
}
# Фиксированные учебные образцы: имя → (путь от корня starter, канал поставки).
SKILL_SAMPLES = {
    "project-status": ("skills/project-status", "skills/ — skill проекта, поставлен со starter"),
    "project-sync": ("untrusted_samples/project-sync", "untrusted_samples/ — внешний учебный пакет, не проверен"),
    "suspicious-skill": ("untrusted_samples/suspicious-skill",
                         "untrusted_samples/ — внешний учебный пакет, не проверен"),
}
MCP_SAMPLES = {
    "mock-mcp-server": ("untrusted_samples/mock_mcp_server.json",
                        "untrusted_samples/ — внешний учебный пакет, не проверен"),
}
# Признаки учебной рубрики: категория → шаблон строки текста.
FEATURES = (
    ("сеть", re.compile(r"urllib|urlopen|requests\.|\bsocket\b|http\.client|httpx|сетев")),
    ("запуск процессов", re.compile(r"subprocess|shell=True|os\.system|запуск вспомогательного скрипта")),
    ("выход за workspace", re.compile(r"\.\./|корень пользовательских документов|document_root")),
    ("чтение всех файлов", re.compile(r"rglob\(\"\*\"\)|рабочей папки пользователя")),
    ("адрес или путь из входных данных", re.compile(r"sync_endpoint|полученным в документе|from input")),
    ("запись файлов", re.compile(r"\.write\(|open\([^)]*[\"']w")),
    ("изменение sys.path", re.compile(r"sys\.path")),
)
REJECT_FEATURES = {"сеть", "запуск процессов", "выход за workspace", "адрес или путь из входных данных"}
MINIMAL_PERMISSIONS = {"read workspace"}


def _gate(action, tools):
    """Ответ существующего гейта на требование из данных — вычислен вызовом, не текстом."""

    if action == "publish_report":
        result = call_tool({"id": "audit-1", "name": "publish_report", "arguments": {"content": "workspace"}}, tools)
        return "dispatcher (глава 7)", result["error"]["code"] + ", executed: " + ("yes" if result["executed"] else "no")
    if action == "read_whole_workspace":
        errors = validate_tool_arguments("read_task_cards", {"path": "."})
        return "schema read_task_cards (глава 6)", errors[0] if errors else "принято"
    if action == "mark_all_done":
        allowed, reason = approval_allowed(None)
        tool = "apply_status_update " + ("в" if "apply_status_update" in AVAILABLE_TOOLS else "не") + " tool модели"
        return "approval gate (глава 14)", tool + "; gate " + ("открыт" if allowed else "закрыт: " + reason)
    raise ValueError("неизвестное требование разметки: " + str(action))


def audit_untrusted_document(case_name, *, workspace_root=WORKSPACE_ROOT):
    if case_name not in DOCUMENT_CASES:
        raise ValueError("неизвестный учебный документ: " + str(case_name))
    case = DOCUMENT_CASES[case_name]
    tools = Tools(workspace_root=workspace_root, scenario=case["scenario"])
    observation = tools.read_task_cards()
    card = next(item for item in observation["untrusted_content"] if item["id"] == case_name)
    path = resolve_workspace_path(case["annotations"], workspace_root=workspace_root, must_exist=True)
    annotations = json.loads(path.read_text(encoding="utf-8"))["requirements"]
    requirements = []
    for item in annotations:
        if item["fragment"] not in card.get("notes", ""):
            raise ValueError("фрагмент разметки не найден в карточке: " + item["fragment"])
        gate, result = _gate(item["requested_action"], tools)
        requirements.append({"fragment": item["fragment"], "gate": gate, "result": result})
    return {"card": case["card"], "provenance": observation["provenance"], "notes": card.get("notes", ""),
            "requirements": requirements, "treated_as_instruction": False}


def _scan(relative, text):
    findings = []
    for number, line in enumerate(text.splitlines(), 1):
        for category, pattern in FEATURES:
            if pattern.search(line):
                findings.append({"file": relative, "line": number, "category": category, "text": line.strip()})
    return findings


def audit_skill_sample(sample_name, *, project_root=PROJECT_ROOT):
    if sample_name not in SKILL_SAMPLES:
        raise ValueError("неизвестный учебный образец skill: " + str(sample_name))
    relative, channel = SKILL_SAMPLES[sample_name]
    directory = project_root / relative
    files = sorted(path.relative_to(directory).as_posix() for path in directory.rglob("*") if path.is_file())
    report = {"sample": sample_name, "path": relative, "provenance": channel, "files": files,
              "scripts": [name for name in files if name.startswith("scripts/")], "findings": []}
    try:
        skill = load_skill(directory.parent, directory.name)
        report.update(skill_md=True, name=skill["metadata"]["name"],
                      compatibility=skill["metadata"].get("compatibility", "не указано"))
        report["findings"] += _scan("SKILL.md", (directory / "SKILL.md").read_text(encoding="utf-8"))
    except SkillFormatError as exc:
        report.update(skill_md=False, format_error=str(exc))
    for name in report["scripts"]:
        # Текст любого файла scripts/ — независимо от расширения; файл не импортируется и не запускается.
        report["findings"] += _scan(name, (directory / name).read_text(encoding="utf-8"))
    categories = {finding["category"] for finding in report["findings"]}
    if not report["skill_md"]:
        report["decision"], report["because"] = "reject", ["нет SKILL.md — не Agent Skill по формату"]
    elif categories & REJECT_FEATURES:
        report["decision"], report["because"] = "reject", sorted(categories & REJECT_FEATURES)
    elif "запись файлов" in categories:
        report["decision"], report["because"] = "isolate", ["запись файлов"]
    else:
        report["decision"], report["because"] = "connect_minimal", ["scripts не запускаются; только процедура"]
    return report


def audit_mcp_sample(sample_name, *, project_root=PROJECT_ROOT):
    if sample_name not in MCP_SAMPLES:
        raise ValueError("неизвестная учебная MCP-карточка: " + str(sample_name))
    relative, channel = MCP_SAMPLES[sample_name]
    try:
        card = json.loads((project_root / relative).read_text(encoding="utf-8"))
    except ValueError as exc:
        raise ValueError(relative + ": повреждённая MCP-карточка") from exc
    if not isinstance(card, dict) or card.get("kind") != "mock_mcp_audit_card":
        raise ValueError(relative + ": ожидалась mock_mcp_audit_card")
    permissions = [{"scope": scope, "needed": scope in MINIMAL_PERMISSIONS}
                   for scope in card.get("requested_permissions", [])]
    tools = [{"name": name, "in_allowlist": name in AVAILABLE_TOOLS} for name in card.get("declared_tools", [])]
    extra = [item["scope"] for item in permissions if not item["needed"]]
    outside = [item["name"] for item in tools if not item["in_allowlist"]]
    risky = [scope for scope in extra if scope.startswith(("network", "start processes"))]
    decision = "reject" if risky else ("isolate" if extra or outside else "connect_minimal")
    return {"sample": sample_name, "card": relative, "kind": card["kind"], "server_name": card.get("server_name"),
            "declared_provenance": card.get("provenance", "не указано"), "provenance": channel,
            "permissions": permissions, "tools": tools, "extra": extra, "outside": outside, "decision": decision}
