"""Глава 15. Решение аудита о внешних компонентах: один источник правил.

Формат ``workspace/my_agent/15_trust.json``::

    {"external_content": "untrusted",
     "skills": {"lesson-notes": "connect_minimal", "project-sync": "reject"}}

``external_content`` — явное объявление с единственным значением, как
``default: deny`` в главе 14. ``skills`` — решение аудита по каждому skill из
``09_skills/``: ``connect_minimal | isolate | reject``. В каталог модели
попадает только ``connect_minimal``; и он не даёт права запускать scripts.
Значений вроде ``trusted`` или ``execute`` нет: файл не может повысить доверие.
Модуль ничего не читает с диска и ничего не печатает.
"""

FIELDS = ("external_content", "skills")
DECISIONS = ("connect_minimal", "isolate", "reject")


class TrustError(ValueError):
    """Решение аудита не соответствует учебному формату главы 15."""


def validate_trust_config(value):
    """Разобранный JSON → нормализованное решение аудита; иначе TrustError."""

    if not isinstance(value, dict):
        raise TrustError("ожидался JSON-объект")
    for key in value:
        if key not in FIELDS:
            raise TrustError("неизвестное поле " + str(key))
    for key in FIELDS:
        if key not in value:
            raise TrustError("нет поля " + key)
    if value["external_content"] != "untrusted":
        raise TrustError("external_content должен быть untrusted: файл не повышает доверие")
    skills = value["skills"]
    if not isinstance(skills, dict):
        raise TrustError("skills — объект «имя skill → решение»")
    for name, decision in skills.items():
        if decision not in DECISIONS:
            raise TrustError("решение для " + str(name) + " — одно из " + ", ".join(DECISIONS))
    return {"external_content": "untrusted", "skills": dict(skills)}


def connected_skills(policy, found_names):
    """(подключённые, [(имя, причина)] неподключённых). Без политики подключены все найденные."""

    if policy is None:
        return list(found_names), []
    connected, not_connected = [], []
    for name in found_names:
        decision = policy["skills"].get(name)
        if decision == "connect_minimal":
            connected.append(name)
        else:
            not_connected.append((name, decision or "нет решения аудита"))
    return connected, not_connected
