"""Глава 17. Release candidate: одна зафиксированная версия для всех итоговых проверок.

Формат ``workspace/my_agent/17_release_candidate.json`` (пишет команда
``python dezhurny.py candidate --label …``, не рука)::

    {"label": "festival-rc1",
     "files": {"01_goal.md": "<sha256>", "11_evals.json": "<sha256>"},
     "digest": "<sha256 всех файлов>"}

В отпечаток входят файлы конфигурации папки: файлы глав 1–16 и все файлы
``09_skills/``. Не входят ``10_state.json`` (его пишет сам harness),
снимки версий ``13_versions/`` (глава 13), ``templates/``, ``examples/``,
``README.md`` и сам файл 17. Любое изменение, добавление или удаление файла после фиксации
делает метку недействительной. Отпечаток удостоверяет только, что все
проверки относятся к одному объекту, а не качество. Модуль ничего не печатает.
"""

import hashlib
import re

LABEL = re.compile(r"^[A-Za-z0-9._-]{1,64}$")
FIELDS = ("label", "files", "digest")
FILE_NAME = "17_release_candidate.json"
# Не входят в отпечаток: состояние пишет harness, 13 — снимки версий, 17 — сама метка.
EXCLUDED = {"10_state.json", "13_versions", FILE_NAME}


class ReleaseCandidateError(ValueError):
    """Файл конфигурации вышел за папку или метка не соответствует формату главы 17."""


def _content(path):
    return path.read_bytes().replace(b"\r\n", b"\n")


def config_files(folder):
    """Файлы конфигурации папки: относительные POSIX-пути, отсортированы."""

    from .my_agent_config import FILES  # порядок и имена файлов глав — одна таблица конструктора

    root = folder.resolve()
    found = []
    for name, _, _ in FILES:
        path = folder / name
        if name in EXCLUDED or not path.exists():
            continue
        items = sorted(item for item in path.rglob("*") if item.is_file()) if path.is_dir() else [path]
        for item in items:
            try:
                item.resolve().relative_to(root)
            except ValueError:
                raise ReleaseCandidateError("файл вне папки конфигурации: " + item.name) from None
            found.append(item.relative_to(folder).as_posix())
    return sorted(found)


def file_hashes(folder, files):
    return {name: hashlib.sha256(_content(folder / name)).hexdigest() for name in files}


def digest(folder, files):
    """SHA-256 по «путь + содержимое» каждого файла; переводы строк нормализованы."""

    total = hashlib.sha256()
    for name in sorted(files):
        total.update(name.encode("utf-8") + b"\0" + _content(folder / name) + b"\0")
    return total.hexdigest()


def build_release_candidate(label, folder):
    """Значение файла 17 для текущего состояния папки."""

    if not isinstance(label, str) or not LABEL.match(label):
        raise ReleaseCandidateError("label — 1–64 символа [A-Za-z0-9._-]")
    files = config_files(folder)
    return {"label": label, "files": file_hashes(folder, files), "digest": digest(folder, files)}


def validate_release_candidate(value, folder):
    """Действительна ли метка для текущей папки; пустой список — да, иначе ошибки."""

    if not isinstance(value, dict):
        return ["ожидался JSON-объект"]
    extra = sorted(key for key in value if key not in FIELDS)
    if extra:
        return ["неизвестное поле " + str(extra[0])]
    label = value.get("label")
    if not isinstance(label, str) or not LABEL.match(label):
        return ["label — 1–64 символа [A-Za-z0-9._-]"]
    recorded, total = value.get("files"), value.get("digest")
    if not isinstance(recorded, dict) or not isinstance(total, str) \
            or not all(isinstance(item, str) for item in recorded.values()):
        return ["не зафиксирован — выполни python dezhurny.py candidate --label " + label]
    current = file_hashes(folder, config_files(folder))
    for name in sorted(set(recorded) | set(current)):
        if name not in recorded:
            return ["недействителен — добавлен " + name]
        if name not in current:
            return ["недействителен — удалён " + name]
        if recorded[name] != current[name]:
            return ["недействителен — " + name + " изменён после фиксации"]
    if total != digest(folder, sorted(current)):
        return ["недействителен — отпечаток не совпадает"]
    return []
