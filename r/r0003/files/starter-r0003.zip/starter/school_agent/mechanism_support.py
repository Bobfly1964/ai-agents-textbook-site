"""Глава 4. Пять механизмов: фрагменты, классификация и локальная карта MCP.

Материалы лежат в ``workspace/ch04``. Сеть не используется, scripts не
запускаются, карточки проекта не изменяются.

Фрагменты печатаются в той форме, в какой они существуют в самих артефактах.
Служебные поля, которые прямо называют механизм (``kind``, frontmatter,
заголовки), в вывод не попадают: иначе классификация свелась бы к чтению
подписи, а не к разбору формы.

Слои Agent Skill читает загрузчик главы 9 ``school_agent.skill_loader``.
Второго загрузчика skill в starter нет.
"""

import ast
import json
import re
from pathlib import Path

from .paths import PROJECT_ROOT, WorkspaceBoundaryError, resolve_workspace_path
from .skill_loader import load_skill


CH04_ROOT = (PROJECT_ROOT / "workspace" / "ch04").resolve()
FIXTURES_ROOT = (PROJECT_ROOT / "tests" / "fixtures").resolve()
SKILL_NAME = "status-summary"
REFERENCE_PATH = "references/report_fields.md"

# Честные флаги демонстрации. Их печатает сама программа: карточка сервера —
# недоверенные данные, и поле внутри данных не может назначать доверие (EC-05).
NETWORK_FLAG = "not used"
TRUST_FLAG = "not proven"

STEP_LINE = re.compile(r"^\d+\.\s+(.+?)\s*$")
FIELD_LINE = re.compile(r"^-\s+([A-Za-z_][A-Za-z0-9_]*)\b")

# Ожидаемая классификация пяти учебных фрагментов главы 4.
CHOICE_KEYS = (
    ("A", "prompt"),
    ("B", "structured output"),
    ("C", "tool"),
    ("D", "MCP"),
    ("E", "Agent Skill"),
)
# Отдельный набор границы: четыре особенно похожие роли.
BOUNDARY_KEYS = (
    ("read-one-card", "tool"),
    ("discover-resources", "MCP"),
    ("repeat-summary", "Agent Skill"),
    ("return-fields", "structured output"),
)
ANSWER_SETS = (CHOICE_KEYS, BOUNDARY_KEYS)


class ChoicesFormatError(ValueError):
    """Файл ответов не соответствует учебному формату ``ключ=механизм``."""


def skill_steps(instructions):
    """Порядок шагов процедуры из текста ``SKILL.md``."""

    steps = []
    for line in instructions.splitlines():
        match = STEP_LINE.match(line.strip())
        if match:
            steps.append(match.group(1))
    return steps


def report_fields(content):
    """Имена полей отчёта из reference-материала процедуры."""

    fields = []
    for line in content.splitlines():
        match = FIELD_LINE.match(line.strip())
        if match:
            fields.append(match.group(1))
    return fields


def _text_fragment(path):
    return path.read_text(encoding="utf-8").strip().splitlines()


def _operation_fragment(path):
    """Имя функции и первая строка её docstring — без тела и без имени файла."""

    tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
    for node in tree.body:
        if isinstance(node, ast.FunctionDef):
            doc = ast.get_docstring(node) or ""
            lines = [node.name + "()"]
            if doc:
                lines.append(doc.splitlines()[0])
            return lines
    raise ChoicesFormatError("во фрагменте нет объявленной операции")


def _connection_fragment(path):
    card = json.loads(path.read_text(encoding="utf-8"))
    return [card["server_name"]] + list(card["resources"])


def _procedure_fragment(skills_root, name):
    skill = load_skill(skills_root, name)
    return [skill["metadata"]["name"]] + skill_steps(skill["instructions"])


def list_mechanism_fragments(root=CH04_ROOT):
    """Пять нейтральных фрагментов A–E из учебных артефактов главы."""

    root = Path(root)
    return [
        {"letter": "A", "lines": _text_fragment(root / "fragments" / "A.md")},
        {"letter": "B", "lines": _text_fragment(root / "fragments" / "B.json")},
        {"letter": "C", "lines": _operation_fragment(root / "fragments" / "C.py")},
        {"letter": "D", "lines": _connection_fragment(root / "mcp" / "server.json")},
        {"letter": "E", "lines": _procedure_fragment(root / "skills", SKILL_NAME)},
    ]


def format_fragment_list(items):
    blocks = []
    for item in items:
        blocks.append("\n".join([item["letter"]] + list(item["lines"])))
    return "\n\n".join(blocks) + "\n"


def _resolve_choices_path(choices_path):
    """Файл ответов читается только из workspace/ ученика или из фикстур курса.

    Эталонный ключ намеренно лежит в ``tests/fixtures/ch04``, а не в рабочей
    папке ученика. Проверку границы в обоих случаях выполняет существующий
    ``resolve_workspace_path``.
    """

    raw = Path(choices_path)
    if raw.is_absolute():
        raise WorkspaceBoundaryError("ожидался относительный путь внутри starter")
    parts = raw.as_posix().split("/")
    if parts[0] == "workspace" and len(parts) > 1:
        return resolve_workspace_path(Path(*parts[1:]))
    if parts[:2] == ["tests", "fixtures"] and len(parts) > 2:
        return resolve_workspace_path(Path(*parts[2:]), workspace_root=FIXTURES_ROOT)
    raise WorkspaceBoundaryError(
        "файл ответов читается только из workspace/ или tests/fixtures/"
    )


def _parse_choices(path):
    answers = []
    seen = set()
    for raw in path.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        if "=" not in line:
            raise ChoicesFormatError("ожидалась строка вида ключ=механизм: " + line)
        key, value = line.split("=", 1)
        key = key.strip()
        if key in seen:
            raise ChoicesFormatError("повтор ключа " + key)
        seen.add(key)
        answers.append((key, value.strip()))
    return answers


def _pick_answer_set(keys):
    best = ANSWER_SETS[0]
    best_score = -1
    for candidate in ANSWER_SETS:
        score = len(set(keys) & {name for name, _ in candidate})
        if score > best_score:
            best = candidate
            best_score = score
    return best


def _same(given, expected):
    return " ".join(given.split()).casefold() == " ".join(expected.split()).casefold()


def check_mechanism_choices(choices_path, root=CH04_ROOT):
    """Сверить ответы ученика с ожидаемой классификацией.

    Неполный или несозданный вход не превращается в частичный балл: такой
    прогон честно возвращает статус «не принят».
    """

    path = _resolve_choices_path(choices_path)
    template = (Path(root) / "templates" / "choices.txt").relative_to(PROJECT_ROOT)
    if not path.is_file():
        return {
            "status": "not_created",
            "path": Path(choices_path).as_posix(),
            "template": template.as_posix(),
        }

    answers = _parse_choices(path)
    expected = _pick_answer_set([key for key, _ in answers])
    expected_names = [name for name, _ in expected]
    given = dict(answers)

    unknown = [key for key, _ in answers if key not in expected_names]
    if unknown:
        return {"status": "unknown_key", "unknown": unknown}

    missing = [name for name in expected_names if not given.get(name)]
    if missing:
        return {"status": "incomplete", "missing": missing}

    rows = []
    for name, mechanism in expected:
        rows.append({
            "key": name,
            "given": given[name],
            "expected": mechanism,
            "ok": _same(given[name], mechanism),
        })
    return {
        "status": "checked",
        "rows": rows,
        "correct": sum(1 for row in rows if row["ok"]),
        "total": len(rows),
    }


def format_choice_review(review):
    status = review["status"]
    if status == "not_created":
        lines = [
            "ошибка: файл ответов не создан: " + review["path"],
            "подсказка: скопируй " + review["template"] + " и заполни пять строк",
            "результат: не принят",
        ]
    elif status == "incomplete":
        lines = ["ошибка: отсутствует ответ " + key for key in review["missing"]]
        lines.append("результат: не принят")
    elif status == "unknown_key":
        lines = ["ошибка: неизвестный ключ " + key for key in review["unknown"]]
        lines.append("результат: не принят")
    else:
        lines = []
        for row in review["rows"]:
            tail = "ok" if row["ok"] else "expected " + row["expected"]
            lines.append(row["key"] + ": " + row["given"] + " — " + tail)
        lines.append("результат: " + str(review["correct"]) + "/" + str(review["total"]))
    return "\n".join(lines) + "\n"


def list_mcp_resources(root=CH04_ROOT):
    """Роли и объявленные ресурсы локальной mock-карты MCP.

    Файл читается с диска; никакого сетевого обращения здесь нет. Флаги
    ``network`` и ``trust`` — утверждение самой демонстрации, а не поле
    карточки: что бы ни было записано в ``server.json``, они не меняются.
    """

    card = json.loads((Path(root) / "mcp" / "server.json").read_text(encoding="utf-8"))
    return {
        "host": card["host"],
        "client": card["client"],
        "server": card["server_name"],
        "resources": list(card["resources"]),
        "network": NETWORK_FLAG,
        "trust": TRUST_FLAG,
    }


def format_mcp_map(model):
    lines = [
        "host: " + model["host"],
        "client: " + model["client"],
        "server: " + model["server"],
    ]
    lines += ["resource: " + uri for uri in model["resources"]]
    lines += ["network: " + model["network"], "trust: " + model["trust"]]
    return "\n".join(lines) + "\n"
