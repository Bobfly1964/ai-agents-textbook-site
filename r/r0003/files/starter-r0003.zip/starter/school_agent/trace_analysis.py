"""Учебная линза для Trace: только чтение наблюдаемых событий существующего TraceRecorder.

Второго agent loop и второго журнала здесь нет: события читаются из JSONL,
записанного ``run_agent``. Скрытые рассуждения модели не восстанавливаются —
их в Trace нет. Неполный Trace не превращается в частичный incident report.
"""
import json

from .paths import WORKSPACE_ROOT, resolve_workspace_path

EVENT_FIELDS = ("event_id", "timestamp", "type", "initiator", "payload")
# Отказы, записанные harness до или вместо observation.
REJECTION_EVENTS = ("response_rejected", "tool_rejected", "skill_request_rejected")


class TraceFormatError(ValueError):
    """Trace непригоден для расследования; частичный incident report не строится."""


def _field(event, *keys):
    value = event.get("payload")
    for key in keys:
        if not isinstance(value, dict) or key not in value:
            raise TraceFormatError(
                "событие " + str(event.get("event_id")) + ": нет поля " + key)
        value = value[key]
    return value


def _check_sequence(events):
    if not events:
        raise TraceFormatError("trace пуст: восстанавливать нечего")
    if events[0]["type"] != "run_started":
        raise TraceFormatError("нет события run_started: начало запуска потеряно")
    if events[-1]["type"] != "run_finished":
        raise TraceFormatError("нет события run_finished: конец запуска потерян")
    requested = set()
    for event in events:
        if event["type"] == "tool_requested":
            requested.add(_field(event, "request", "id"))
        elif event["type"] == "tool_observation":
            call_id = _field(event, "observation", "call_id")
            if call_id not in requested:
                raise TraceFormatError("observation " + call_id + " не связан с запросом")


def load_trace(relative_path, *, workspace_root=WORKSPACE_ROOT):
    """Прочитать JSONL внутри workspace; повреждённая запись — явный отказ."""

    path = resolve_workspace_path(relative_path, workspace_root=workspace_root, must_exist=True)
    events = []
    for number, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
        if not line.strip():
            continue
        try:
            event = json.loads(line)
        except ValueError as exc:
            raise TraceFormatError("строка " + str(number) + ": не JSON-объект события") from exc
        if not isinstance(event, dict) or any(field not in event for field in EVENT_FIELDS):
            raise TraceFormatError("строка " + str(number) + ": нет обязательных полей события")
        events.append(event)
    _check_sequence(events)
    return events


def count_approval_events(events):
    """События подтверждения узнаются по типу (approval_*), а не по списку случаев."""

    return sum(1 for event in events if event["type"].startswith("approval"))


def summarize_trace(events):
    """Счёт наблюдаемых событий. Approval узнаётся по типу события, а не по списку случаев."""

    errors = 0
    for event in events:
        if event["type"] == "tool_observation" and not _field(event, "observation", "ok"):
            errors += 1
        elif event["type"] in REJECTION_EVENTS:
            errors += 1
    return {
        "events": len(events),
        "tool_calls": sum(1 for event in events if event["type"] == "tool_requested"),
        "errors": errors,
        "approval_events": count_approval_events(events),
        "terminal": _field(events[-1], "terminal"),
        "steps": _field(events[-1], "steps"),
    }


def _request_event(events, call_id):
    for event in events:
        if event["type"] == "tool_requested" and _field(event, "request", "id") == call_id:
            return event
    raise TraceFormatError("нет запроса для call_id " + call_id)


def find_failure_point(events):
    """Первое наблюдаемое событие отклонения; скрытые причины не угадываются."""

    for event in events:
        if event["type"] in REJECTION_EVENTS:
            return {"event_id": event["event_id"], "type": event["type"], "call_id": None,
                    "tool": None, "root_cause": event["payload"].get("code", event["type"]),
                    "evidence_event_id": event["event_id"]}
        if event["type"] != "tool_observation":
            continue
        observation = _field(event, "observation")
        if observation.get("ok"):
            continue
        code = observation["error"]["code"]
        call_id, tool = observation["call_id"], observation["name"]
        if code == "unknown_tool":
            # Отклонение видно уже в запросе: модель назвала операцию вне allowlist.
            request = _request_event(events, call_id)
            return {"event_id": request["event_id"], "type": "tool_requested", "call_id": call_id,
                    "tool": tool, "root_cause": code, "evidence_event_id": event["event_id"]}
        return {"event_id": event["event_id"], "type": "tool_observation", "call_id": call_id,
                "tool": tool, "root_cause": code, "evidence_event_id": event["event_id"]}
    return None


def build_incident_report(events):
    """Симптом, место, причина и событие-доказательство. Версий и отката здесь нет."""

    summary = summarize_trace(events)
    point = find_failure_point(events)
    return {
        "terminal": summary["terminal"],
        "tool_calls": summary["tool_calls"],
        "errors": summary["errors"],
        "approval_events": summary["approval_events"],
        "failure_point": point,
        "root_cause": None if point is None else point["root_cause"],
        "evidence_event_id": None if point is None else point["evidence_event_id"],
    }
