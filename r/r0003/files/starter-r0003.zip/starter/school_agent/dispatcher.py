"""Только четыре доменных tools; никакого выполнения имени как кода."""
from .tools import Tools, ToolDataError
from .paths import WorkspaceBoundaryError
from .validation import validate_tool_arguments

AVAILABLE_TOOLS = {
    "read_task_cards": Tools.read_task_cards,
    "validate_task_card": Tools.validate_task_card,
    "build_status_report": Tools.build_status_report,
    "propose_status_update": Tools.propose_status_update,
}


def call_tool(tool_call, tools):
    name = tool_call.get("name") if isinstance(tool_call, dict) else None
    call_id = tool_call.get("id", "unknown") if isinstance(tool_call, dict) else "unknown"
    result = {"call_id": call_id, "name": name, "ok": False, "executed": False}
    if not isinstance(name, str) or name not in AVAILABLE_TOOLS:
        result["error"] = {"code": "unknown_tool", "message": "имя отсутствует в allowlist"}
        return result
    errors = validate_tool_arguments(name, tool_call.get("arguments"))
    if errors:
        result["error"] = {"code": "invalid_arguments", "message": "; ".join(errors)}
        return result
    result["executed"] = True
    try:
        value = AVAILABLE_TOOLS[name](tools, **tool_call["arguments"])
        result.update(ok=True, result=value)
    except WorkspaceBoundaryError:
        result["error"] = {"code": "outside_workspace", "message": "доступ вне workspace запрещён"}
    except ToolDataError as exc:
        result["error"] = {"code": exc.code, "message": str(exc)}
    except (OSError, ValueError, TypeError):
        result["error"] = {"code": "tool_error", "message": "операция с учебными данными не выполнена"}
    return result
