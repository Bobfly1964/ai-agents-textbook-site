"""Учебное сравнение двух Version одного Agent Skill: только чтение.

Change proposal проверяется по существующему incident report главы 12, а не
становится нормой. Version — каталог ``<метка>/<имя skill>/SKILL.md`` внутри
workspace; структуру проверяет существующий загрузчик главы 9. Проверка
Version — детерминированная rubric над текстом процедуры, а не запуск агента и
не оценка живой модели. Rollback здесь не выполняется: сравнение выдаёт только
решение ``keep`` или ``revert``. Файлы не создаются и не изменяются.
"""
import difflib
import hashlib
import json

from .paths import WORKSPACE_ROOT, resolve_workspace_path
from .skill_loader import SkillFormatError, load_skill
from .trace_analysis import build_incident_report, load_trace

PROPOSAL_FIELDS = ("feedback", "source_eval_case", "source_trace", "expected_root_cause",
                   "change_proposal", "cases", "status")


class VersioningError(ValueError):
    """Proposal, набор случаев или сравнение Version непригодны для решения."""


def _read_json(relative_path, workspace_root):
    path = resolve_workspace_path(relative_path, workspace_root=workspace_root, must_exist=True)
    try:
        document = json.loads(path.read_text(encoding="utf-8"))
    except ValueError as exc:
        raise VersioningError(str(relative_path) + ": не JSON") from exc
    if not isinstance(document, dict):
        raise VersioningError(str(relative_path) + ": ожидался JSON-объект")
    return document


def load_version_cases(cases_path, *, workspace_root=WORKSPACE_ROOT):
    """Один фиксированный набор: eval_set, target_case и cases с rubric по строке."""

    document = _read_json(cases_path, workspace_root)
    cases = document.get("cases")
    if not isinstance(document.get("eval_set"), str) or not isinstance(cases, list) or not cases:
        raise VersioningError("в наборе нет eval_set или cases")
    ids = []
    for case in cases:
        fragments = case.get("line_contains") if isinstance(case, dict) else None
        if not isinstance(case, dict) or not isinstance(case.get("id"), str) \
                or not isinstance(fragments, list) or not fragments:
            raise VersioningError("case без id или без rubric line_contains")
        ids.append(case["id"])
    if len(set(ids)) != len(ids):
        raise VersioningError("id случаев повторяются")
    if document.get("target_case") not in ids:
        raise VersioningError("target_case не входит в набор")
    return document


def review_change_proposal(relative_path, *, workspace_root=WORKSPACE_ROOT):
    """Связи proposal с Test case и Trace; сам proposal нормой не становится."""

    proposal = _read_json(relative_path, workspace_root)
    missing = [field for field in PROPOSAL_FIELDS if not isinstance(proposal.get(field), str)]
    if missing:
        raise VersioningError("в proposal нет поля " + missing[0])
    if proposal["status"] != "proposed":
        raise VersioningError("proposal не может сам объявить себя нормой: status должен быть proposed")
    cases = load_version_cases(proposal["cases"], workspace_root=workspace_root)
    ids = [case["id"] for case in cases["cases"]]
    if proposal["source_eval_case"] not in ids:
        raise VersioningError("source_eval_case не найден в наборе " + cases["eval_set"])
    for case_id in proposal.get("must_not_change", []):
        if case_id not in ids or case_id == proposal["source_eval_case"]:
            raise VersioningError("must_not_change: неизвестный case " + str(case_id))
    report = build_incident_report(load_trace(proposal["source_trace"], workspace_root=workspace_root))
    if report["root_cause"] != proposal["expected_root_cause"]:
        raise VersioningError("evidence не подтверждает proposal: root_cause в Trace — "
                              + str(report["root_cause"]))
    return {
        "feedback": proposal["feedback"],
        "source_eval_case": proposal["source_eval_case"],
        "source_trace": proposal["source_trace"],
        "root_cause": report["root_cause"],
        "evidence_event_id": report["evidence_event_id"],
        "change_proposal": proposal["change_proposal"],
        "eval_set": cases["eval_set"],
        "must_not_change": list(proposal.get("must_not_change", [])),
        "status": proposal["status"],
        "new_norm": False,
    }


def _version(version_path, workspace_root):
    """Каталог skill внутри workspace; метка Version — имя родительского каталога."""

    directory = resolve_workspace_path(version_path, workspace_root=workspace_root, must_exist=True)
    if not directory.is_dir():
        raise VersioningError(str(version_path) + ": ожидался каталог skill")
    return directory.parent.name, directory


def diff_skill_versions(before_path, after_path, *, workspace_root=WORKSPACE_ROOT):
    """Изменённые строки SKILL.md двух Version; качество diff не оценивает."""

    sides = []
    for raw in (before_path, after_path):
        label, directory = _version(raw, workspace_root)
        load_skill(directory.parent, directory.name)
        sides.append((label, (directory / "SKILL.md").read_text(encoding="utf-8").splitlines()))
    (before, old), (after, new) = sides
    lines = []
    matcher = difflib.SequenceMatcher(a=old, b=new, autojunk=False)
    for tag, i1, i2, j1, j2 in matcher.get_opcodes():
        if tag == "equal":
            continue
        removed, added = old[i1:i2], new[j1:j2]
        # Внутри замены строки идут парами: было → стало.
        for index in range(max(len(removed), len(added))):
            if index < len(removed):
                lines.append("- " + removed[index])
            if index < len(added):
                lines.append("+ " + added[index])
    return {"before": before, "after": after, "file": "SKILL.md", "lines": lines}


def run_version_cases(version_path, cases_path, *, workspace_root=WORKSPACE_ROOT):
    """Один набор случаев для одной Version; повреждённая Version не получает частичный счёт."""

    cases = load_version_cases(cases_path, workspace_root=workspace_root)
    label, directory = _version(version_path, workspace_root)
    result = {"version": label, "eval_set": cases["eval_set"], "target_case": cases["target_case"]}
    try:
        instructions = load_skill(directory.parent, directory.name)["instructions"]
    except SkillFormatError as exc:
        result.update(accepted=False, reason=str(exc), cases=[], passed=0, total=0)
        return result
    lines = instructions.splitlines()
    checked = []
    for case in cases["cases"]:
        passed = any(all(fragment in line for fragment in case["line_contains"]) for line in lines)
        checked.append({"id": case["id"], "passed": passed})
    result.update(accepted=True, reason=None, cases=checked,
                  passed=sum(1 for case in checked if case["passed"]), total=len(checked))
    return result


def compare_version_results(before, after):
    """Regression — только pass старой Version → fail новой на том же eval_set."""

    if not before["accepted"] or not after["accepted"]:
        raise VersioningError("сравнивать можно только принятые Version")
    if before["eval_set"] != after["eval_set"]:
        raise VersioningError("сравнение возможно только на одном eval_set")
    old = {case["id"]: case["passed"] for case in before["cases"]}
    new = {case["id"]: case["passed"] for case in after["cases"]}
    if list(old) != list(new):
        raise VersioningError("у Version разные наборы случаев")
    target = before["target_case"]
    regressions = [case_id for case_id in old if old[case_id] and not new[case_id]]
    keep = not regressions and new[target]
    return {
        "before": before["version"], "after": after["version"],
        "before_score": (before["passed"], before["total"]),
        "after_score": (after["passed"], after["total"]),
        "eval_set": before["eval_set"],
        "target_case": target, "target_before": old[target], "target_after": new[target],
        "regressions": regressions,
        "decision": "keep" if keep else "revert",
        "rollback_to": None if keep else before["version"],
    }


def snapshot_files(*directories):
    """SHA-256 всех файлов каталогов: доказательство, что сравнение ничего не изменило."""

    digests = {}
    for directory in directories:
        for path in sorted(item for item in directory.rglob("*") if item.is_file()):
            digests[str(path)] = hashlib.sha256(path.read_bytes()).hexdigest()
    return digests
