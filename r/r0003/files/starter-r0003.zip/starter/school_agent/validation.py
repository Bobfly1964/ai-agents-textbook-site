"""Небольшой учебный валидатор подмножества JSON Schema."""

from __future__ import annotations

import json
from typing import Any

from .paths import PROJECT_ROOT

with (PROJECT_ROOT / "data" / "tool_schemas.json").open("r", encoding="utf-8") as source:
    _SCHEMA_DOCUMENT: dict[str, Any] = json.load(source)

CARD_SCHEMA: dict[str, Any] = _SCHEMA_DOCUMENT["$defs"]["task_card"]
TOOL_SCHEMAS: dict[str, dict[str, Any]] = {
    key: value
    for key, value in _SCHEMA_DOCUMENT.items()
    if not key.startswith("$")
}


_TYPE_CHECKS = {
    "object": lambda value: isinstance(value, dict),
    "array": lambda value: isinstance(value, list),
    "string": lambda value: isinstance(value, str),
    "integer": lambda value: isinstance(value, int) and not isinstance(value, bool),
    "boolean": lambda value: isinstance(value, bool),
}


def _validate(value: Any, schema: dict[str, Any], path: str) -> list[str]:
    if schema.get("$ref") == "#/$defs/task_card":
        schema = CARD_SCHEMA
    errors: list[str] = []
    expected_type = schema.get("type")
    if expected_type and not _TYPE_CHECKS[expected_type](value):
        return [f"{path}: ожидался тип {expected_type}"]

    if "enum" in schema and value not in schema["enum"]:
        errors.append(f"{path}: значение не входит в enum")

    if isinstance(value, str) and len(value) < schema.get("minLength", 0):
        errors.append(f"{path}: строка слишком короткая")

    if isinstance(value, list) and "items" in schema:
        for index, item in enumerate(value):
            errors.extend(_validate(item, schema["items"], f"{path}[{index}]"))

    if isinstance(value, dict):
        properties = schema.get("properties", {})
        for required in schema.get("required", []):
            if required not in value:
                errors.append(f"{path}: нет обязательного поля {required}")
        if schema.get("additionalProperties") is False:
            for key in value:
                if key not in properties:
                    errors.append(f"{path}: лишнее поле {key}")
        for key, child_schema in properties.items():
            if key in value:
                errors.extend(_validate(value[key], child_schema, f"{path}.{key}"))
    return errors


def validate_tool_arguments(name: str, arguments: Any) -> list[str]:
    """Вернуть список ошибок; пустой список означает успех."""

    schema = TOOL_SCHEMAS.get(name)
    if schema is None:
        return ["неизвестная schema tool"]
    return _validate(arguments, schema, "arguments")


def validate_task_card_schema(card: Any) -> list[str]:
    """Вернуть список ошибок карточки по CARD_SCHEMA; пустой список — успех."""

    return _validate(card, CARD_SCHEMA, "card")
