"""Глава 13. Версии конфигурации «Дежурного»: снимки папки my_agent/.

Формат ``workspace/my_agent/13_versions/<метка>/`` (пишет команда
``python dezhurny.py version save <метка>``, не рука): копии файлов
конфигурации с теми же относительными путями и ``manifest.json``::

    {"label": "1.0.0",
     "files": {"07_tools.json": "<sha256>", "11_evals.json": "<sha256>"},
     "digest": "<sha256 всех файлов>"}

Какие файлы входят в снимок, как считается отпечаток и какой должна быть
метка — решает ``school_agent.release_candidate`` (один источник правил с
главой 17). Времени, автора и git в манифесте нет: снимок детерминирован.
Снимок неизменяем: изменённая конфигурация — новая метка. Это снимок всей
конфигурации, а не Version личного skill: тот по-прежнему сравнивает
``change_demo.py``. Модуль ничего не печатает и пишет только внутри
``13_versions/``.
"""

import json
import os
import tempfile

from .paths import WORKSPACE_ROOT
from .release_candidate import LABEL, config_files, digest, file_hashes
from .state_store import save_state

FOLDER = "13_versions"
MANIFEST = "manifest.json"
FIELDS = ("label", "files", "digest")
EVALS = "11_evals.json"
TEMPLATE = "README.md"
REPAIR = " — удали папку снимка или сохрани заново под новой меткой"
TEMPLATE_HINT = ": это шаблон, а не снимок — удали папку и выполни python dezhurny.py version save <метка>"


class VersionsError(ValueError):
    """Снимок в 13_versions/ не соответствует формату главы 13 или метка занята."""


def build_manifest(folder, label):
    """Манифест снимка для текущего состояния папки конфигурации."""

    if not isinstance(label, str) or not LABEL.match(label):
        raise VersionsError("метка — 1–64 символа [A-Za-z0-9._-]")
    # Пустая конфигурация — тоже снимок (как у candidate главы 17): «до первого файла».
    files = config_files(folder)
    return {"label": label, "files": file_hashes(folder, files), "digest": digest(folder, files)}


def _copy(source, target):
    """Байты файла — во временный файл рядом, затем замена: запись атомарна по файлу."""

    target.parent.mkdir(parents=True, exist_ok=True)
    descriptor, temporary = tempfile.mkstemp(prefix="." + target.name + ".", suffix=".tmp", dir=target.parent)
    try:
        with os.fdopen(descriptor, "wb") as stream:
            stream.write(source.read_bytes())
        os.replace(temporary, target)
    except Exception:
        try:
            os.unlink(temporary)
        except FileNotFoundError:
            pass
        raise


def save_version(folder, label, *, workspace_root=WORKSPACE_ROOT):
    """Сохранить снимок ``folder/13_versions/<label>/``; вернуть манифест.

    Та же метка с теми же файлами — ничего не пишется; с другими — отказ.
    """

    manifest = build_manifest(folder, label)
    target = folder / FOLDER / label
    if target.exists():
        if _read_snapshot(target) == manifest:
            return manifest
        raise VersionsError("версия " + label + " уже есть и отличается — выбери новую метку")
    for name in manifest["files"]:
        _copy(folder / name, target / name)
    # Манифест пишется последним: снимок без манифеста — недописанный, его покажет ошибка строки 13.
    relative = (target / MANIFEST).resolve().relative_to(os.path.realpath(workspace_root))
    save_state(manifest, relative.as_posix(), workspace_root=workspace_root)
    return manifest


def _problem(snapshot, text):
    return VersionsError(FOLDER + ": " + snapshot.name + ": " + text + REPAIR)


def _read_snapshot(snapshot):
    """Манифест проверенного снимка; ``VersionsError`` — что с ним не так."""

    files = sorted(item.relative_to(snapshot).as_posix() for item in snapshot.rglob("*") if item.is_file())
    if MANIFEST not in files:
        if files == [TEMPLATE]:
            raise VersionsError(FOLDER + "/" + snapshot.name + TEMPLATE_HINT)
        raise _problem(snapshot, "нет " + MANIFEST)
    if not LABEL.match(snapshot.name):
        raise _problem(snapshot, "метка не соответствует формату")
    try:
        value = json.loads((snapshot / MANIFEST).read_text(encoding="utf-8"))
    except (ValueError, UnicodeError):
        value = None
    recorded = value.get("files") if isinstance(value, dict) else None
    if not isinstance(value, dict) or sorted(value) != sorted(FIELDS) or value["label"] != snapshot.name \
            or not isinstance(recorded, dict) \
            or not all(isinstance(item, str) for item in recorded.values()):
        raise _problem(snapshot, MANIFEST + " повреждён")
    for name in files:
        if name != MANIFEST and name not in recorded:
            raise _problem(snapshot, "лишний файл " + name)
    for name in sorted(recorded):
        if name not in files or file_hashes(snapshot, [name])[name] != recorded[name]:
            raise _problem(snapshot, "файл " + name + " не совпадает с манифестом")
    if value["digest"] != digest(snapshot, sorted(recorded)):
        raise _problem(snapshot, MANIFEST + " повреждён")
    return value


def validate_versions_dir(folder):
    """Манифесты всех снимков ``folder/13_versions/`` по метке; первая ошибка — ``VersionsError``."""

    root = folder / FOLDER
    if not root.is_dir():
        raise VersionsError(FOLDER + ": ожидалась папка")
    loose = sorted(item.name for item in root.iterdir() if not item.is_dir())
    if loose:
        # Скопированный шаблон templates/13_versions/ — README.md прямо в 13_versions/.
        if loose == [TEMPLATE]:
            raise VersionsError(FOLDER + TEMPLATE_HINT)
        raise VersionsError(FOLDER + ": лишний файл " + loose[0] + " — снимки лежат в папках <метка>/")
    return [_read_snapshot(item) for item in sorted(root.iterdir(), key=lambda item: item.name)]


def list_versions(folder):
    """Манифесты снимков в строковом порядке меток; нет папки — пустой список."""

    return validate_versions_dir(folder) if (folder / FOLDER).exists() else []


def find_version(folder, label):
    for manifest in list_versions(folder):
        if manifest["label"] == label:
            return manifest
    raise VersionsError("версии " + label + " нет — выполни python dezhurny.py version list")


def compare_versions(folder, first, second):
    """Что изменилось между снимками и одинаков ли в них набор случаев главы 11."""

    a, b = find_version(folder, first), find_version(folder, second)
    before, after = a["files"], b["files"]
    return {
        "changed": sorted(name for name in before if name in after and before[name] != after[name]),
        "added": sorted(name for name in after if name not in before),
        "removed": sorted(name for name in before if name not in after),
        "same_cases": EVALS in before and before.get(EVALS) == after.get(EVALS),
    }
