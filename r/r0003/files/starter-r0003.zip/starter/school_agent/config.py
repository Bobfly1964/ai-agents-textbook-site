"""Конфигурация harness: модель не выбирает файловые пути."""
from .paths import WORKSPACE_ROOT

ERROR_CARDS = "Ошибка: учебные карточки недоступны"
MAX_STEPS = 5
MAX_RETRIES = 1
MAX_MODEL_TURNS = 20
SCENARIOS = {
    "success": "tasks", "one_match": "tasks", "normal": "tasks",
    "two_matches": "scenarios/ambiguous", "needs_input": "scenarios/ambiguous",
    "missing_file": "scenarios/missing", "permanent_error": "scenarios/missing",
    "temporary_error": "tasks", "limit": "tasks",
    "unknown_tool": "tasks", "injection": "scenarios/injection",
    "status_update": "tasks",
}
