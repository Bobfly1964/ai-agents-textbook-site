# Сценарии

Сценарий задаёт CLI/harness, не модель.

| Сценарий | Исход | Действий |
|---|---|---:|
| loop one_match | success | 1 |
| loop two_matches | needs_input | 1 |
| loop no_matches | needs_input | 1 |
| loop temporary_error | success | 2 |
| loop permanent_error / missing_file | error | 2 |
| loop limit | limit | 5 |
| agent replay success | success | 5 |
| agent replay missing_file / permanent_error | error | 2 |
| agent replay unknown_tool | error | 0 |
| agent replay limit | limit | 5 |
| agent replay needs_input | needs_input | 1 |
| agent replay injection | success | 3 |
| agent replay temporary_error | needs_input | 2 |

Последний needs_input задан автором ПОСЛЕ успешного повтора: продолжение
демонстрации не задано; это не смена IO-терминала. Исчерпанный retry — error.
Loop ищет одну карточку, agent готовит полный отчёт; задачи различны.
Успех injection replay — иллюстрация, не измерение устойчивости модели.
В `no_matches` поиск завершён и данных нет: нужен ввод. В `limit`
каждое observation сообщает `search_complete: false` и следующую страницу,
поэтому продолжение до технического предела обосновано данными, а не именем
сценария. Таймаут отсутствует: ограничения времени не реализованы.
