"""Проверки harness и сценарии model_behavior показаны отдельно."""
from school_agent.presentation import eval_main


if __name__ == "__main__":
    eval_main()
