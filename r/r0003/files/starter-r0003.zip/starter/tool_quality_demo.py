"""Глава 8. Хороший tool: паспорт и локальная проверка границ.

Сеть не используется, доменные tools не вызываются, карточки не читаются.
Выбор в ``route`` делает учебное правило над description, а не модель.
"""

import argparse

from school_agent.tool_quality import (
    build_tool_passport,
    check_route_case,
    load_catalog,
    run_quality_suite,
)
from school_agent.validation import TOOL_SCHEMAS

ROUTER_NOTE = "учебное правило по when/when_not — не модель"
CASE_NAMES = ["should-validate-card", "should-read-board"]
TOOL_NAMES = ["read_task_cards", "validate_task_card", "build_status_report",
              "propose_status_update"]


def _passport(name):
    passport = build_tool_passport(name, load_catalog(), TOOL_SCHEMAS)
    print("passport: " + passport["name"])
    print("scope: " + passport["scope"])
    print("contract:")
    for part, value in passport["contract"].items():
        print("  " + part + ": " + value)
    print("description: " + passport["description"])
    print("when: " + passport["when"])
    print("when_not: " + passport["when_not"])
    print("schema: " + passport["schema"])
    print("execution: not performed")


def _route(case_name):
    review = check_route_case(case_name, load_catalog())
    print("case: " + review["case"])
    print("request: " + review["request"])
    print("expected: " + review["expected"])
    print("selected: " + (review["selected"] or "none"))
    print("result: " + ("ok" if review["ok"] else "fail"))
    print("router: " + ROUTER_NOTE)


def _suite():
    summary = run_quality_suite(load_catalog())
    for item in summary["results"]:
        print(item["kind"] + ": " + item["case"] + " — " + ("ok" if item["ok"] else "fail"))
    print("result: " + str(summary["passed"]) + "/" + str(summary["total"]))


def main(argv=None):
    parser = argparse.ArgumentParser(
        description="Паспорт tool и три обязательных случая главы 8 на локальных данных.",
    )
    commands = parser.add_subparsers(dest="command", required=True)
    passport = commands.add_parser("passport", help="паспорт одного разрешённого tool")
    passport.add_argument("name", choices=TOOL_NAMES)
    route = commands.add_parser("route", help="учебный выбор tool на заранее заданном случае")
    route.add_argument("--case", required=True, choices=CASE_NAMES)
    commands.add_parser("suite", help="positive, negative и error case")
    args = parser.parse_args(argv)

    if args.command == "passport":
        _passport(args.name)
    elif args.command == "route":
        _route(args.case)
    else:
        _suite()
    return 0


if __name__ == "__main__":
    main()
