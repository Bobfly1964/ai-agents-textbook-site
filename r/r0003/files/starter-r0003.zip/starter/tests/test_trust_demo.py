"""Контракт главы 15: недоверенное — данные; требования из данных останавливают существующие гейты."""

import hashlib
import json
import os
import re
import shutil
import socket
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

import dezhurny
from school_agent import trust_audit
from school_agent.agent import run_agent
from school_agent.my_agent_config import FILES, build_profile, read_my_agent
from school_agent.paths import PROJECT_ROOT, WORKSPACE_ROOT
from school_agent.trust import TrustError, connected_skills, validate_trust_config
from school_agent.trust_audit import audit_mcp_sample, audit_skill_sample, audit_untrusted_document

GOLDEN = PROJECT_ROOT / "tests" / "golden"
# Golden блоков «Достраиваем „Дежурного“» (ретрофит глав 1–13, 0.17.0) в слепки прежних глав не входят.
RETROFIT_GOLDEN = re.compile(r"ch(0\d|1[0-3])_dezhurny_")
MY_AGENT = WORKSPACE_ROOT / "my_agent"
CASE = "ch15/cases/external-skill"
FIXTURES = PROJECT_ROOT / "tests" / "fixtures" / "ch15"
# Слепок 91 эталона 0.13.1 без ch14_dezhurny_status.txt (изменён errata главы 14 v1.2).
OLD_GOLDEN_COUNT = 91
OLD_GOLDEN_DIGEST = "67c776977d942c81d7b40e5b8e26b95007a5d6a7c1309644f1107f16aae8210f"


def run_cli(script, *args):
    return subprocess.run([sys.executable, script, *args], cwd=PROJECT_ROOT,
                          capture_output=True, env=dict(os.environ, PYTHONIOENCODING="utf-8"))


def temp_copy(test, relative):
    directory = tempfile.mkdtemp()
    test.addCleanup(shutil.rmtree, directory)
    target = Path(directory) / relative
    shutil.copytree(PROJECT_ROOT / relative, target)
    return Path(directory)


def tree_digest(root):
    return {path.relative_to(root).as_posix(): hashlib.sha256(path.read_bytes()).hexdigest()
            for path in sorted(root.rglob("*")) if path.is_file() and "__pycache__" not in path.parts}


class NoNetworkNoProcesses:
    """Любая попытка сети или запуска процесса во время аудита — исключение."""

    def __enter__(self):
        def refuse(*args, **kwargs):
            raise AssertionError("аудит не должен открывать сеть или запускать процессы")
        self.patches = [mock.patch.object(socket, "socket", refuse), mock.patch.object(subprocess, "Popen", refuse),
                        mock.patch.object(subprocess, "run", refuse), mock.patch.object(os, "system", refuse)]
        for patch in self.patches:
            patch.start()

    def __exit__(self, *exc):
        for patch in self.patches:
            patch.stop()


class GoldenTests(unittest.TestCase):
    RUNS = {
        "ch15_document_task901.txt": (None, "trust_demo.py", "document", "--case", "task-901"),
        "ch15_injection_replay.txt": (None, "trust_demo.py", "replay"),
        "ch15_skill_audit_project_status.txt": (None, "trust_demo.py", "audit", "skill", "--sample", "project-status"),
        "ch15_skill_audit_project_sync.txt": (None, "trust_demo.py", "audit", "skill", "--sample", "project-sync"),
        "ch15_skill_audit_suspicious.txt": (None, "trust_demo.py", "audit", "skill", "--sample", "suspicious-skill"),
        "ch15_mcp_audit.txt": (None, "trust_demo.py", "audit", "mcp", "--sample", "mock-mcp-server"),
        "ch15_dezhurny_status_trust.txt": (None, "dezhurny.py", "status", "--chapter", "15", "--dir",
                                           "workspace/" + CASE),
        "ch15_dezhurny_run_trust.txt": (None, "dezhurny.py", "run", "--dir", "workspace/" + CASE),
        "ch15_trust_invalid.txt": ("15_trust_invalid.json", "dezhurny.py", "status", "--chapter", "15"),
    }

    def test_nine_outputs_and_clean_workspace(self):
        before = tree_digest(WORKSPACE_ROOT)
        for golden, (fixture, script, *args) in self.RUNS.items():
            with self.subTest(golden=golden):
                target = MY_AGENT / "15_trust.json"
                if fixture:
                    shutil.copyfile(FIXTURES / fixture, target)
                try:
                    result = run_cli(script, *args)
                finally:
                    if fixture:
                        target.unlink()
                self.assertEqual(result.returncode, 0, result.stderr.decode("utf-8"))
                self.assertEqual(result.stderr, b"")
                printed = result.stdout.decode("utf-8").replace("\r\n", "\n")
                self.assertEqual(printed, (GOLDEN / golden).read_text(encoding="utf-8"))
                self.assertNotIn(str(PROJECT_ROOT), printed)
        self.assertEqual(tree_digest(WORKSPACE_ROOT), before)

    def test_every_audit_says_it_is_not_a_proof(self):
        for name in ("ch15_skill_audit_project_status.txt", "ch15_skill_audit_project_sync.txt",
                     "ch15_skill_audit_suspicious.txt", "ch15_mcp_audit.txt"):
            with self.subTest(golden=name):
                text = (GOLDEN / name).read_text(encoding="utf-8")
                self.assertTrue(text.endswith("static audit: not a safety proof\n"))
                self.assertIn("network used: no", text)


class TrustPolicyTests(unittest.TestCase):
    VALID = {"external_content": "untrusted", "skills": {"lesson-notes": "connect_minimal"}}

    def test_valid_policy_and_connection_rule(self):
        policy = validate_trust_config(dict(self.VALID))
        self.assertEqual(connected_skills(policy, ["lesson-notes", "other"]),
                         (["lesson-notes"], [("other", "нет решения аудита")]))
        self.assertEqual(connected_skills(None, ["a", "b"]), (["a", "b"], []))

    def test_weakening_values_are_rejected(self):
        cases = [dict(self.VALID, external_content="trusted"),
                 dict(self.VALID, skills={"lesson-notes": "trusted"}),
                 dict(self.VALID, skills={"lesson-notes": "execute"}),
                 dict(self.VALID, network="allow"),
                 {"external_content": "untrusted"},
                 dict(self.VALID, skills=["lesson-notes"]),
                 ["untrusted"]]
        for value in cases:
            with self.subTest(value=value):
                with self.assertRaises(TrustError):
                    validate_trust_config(value)

    def test_one_source_of_rules(self):
        for path in ("school_agent/my_agent_config.py", "dezhurny.py", "trust_demo.py"):
            source = (PROJECT_ROOT / path).read_text(encoding="utf-8")
            with self.subTest(path=path):
                self.assertNotIn("должен быть untrusted", source)
                self.assertNotIn("def validate_trust_config", source)

    def test_unknown_skill_name_is_a_config_error(self):
        root = temp_copy(self, "workspace")
        (root / "workspace" / "ch15" / "cases" / "external-skill" / "15_trust.json").write_text(json.dumps(
            {"external_content": "untrusted", "skills": {"no-such-skill": "connect_minimal"}}), encoding="utf-8")
        lines = dezhurny.cmd_status(CASE, workspace_root=root / "workspace", chapter=15)
        self.assertIn("ошибка: 15_trust.json: нет skill no-such-skill в 09_skills", lines[2])
        with self.assertRaises(ValueError):
            dezhurny.cmd_run(CASE, workspace_root=root / "workspace")

    def test_case_copy_equals_the_untrusted_sample(self):
        self.assertEqual(tree_digest(WORKSPACE_ROOT / CASE / "09_skills" / "project-sync"),
                         tree_digest(PROJECT_ROOT / "untrusted_samples" / "project-sync"))


class ConstructorTests(unittest.TestCase):
    class Adapter:
        kind = "replay"

        def __init__(self, responses):
            self.responses, self.contexts = list(responses), []

        def next(self, context):
            self.contexts.append(context)
            return self.responses.pop(0)

    def profile(self):
        return build_profile(read_my_agent(CASE))

    def test_rejected_skill_never_reaches_the_model(self):
        adapter = self.Adapter([{"type": "load_skill", "name": "project-sync"}])
        result = run_agent(adapter, profile=self.profile())
        names = [skill["name"] for skill in adapter.contexts[0]["skill_catalog"]]
        self.assertEqual(names, ["project-status", "lesson-notes"])
        self.assertEqual(result["reason"], "skill_request_rejected")
        self.assertFalse(any(event["type"] == "skill_loaded" for event in result["trace"]))

    def test_connected_skill_loads_and_runs_no_scripts(self):
        root = temp_copy(self, "workspace")
        case = root / "workspace" / CASE
        marker = root / "executed.txt"
        scripts = case / "09_skills" / "lesson-notes" / "scripts"
        scripts.mkdir()
        (scripts / "marker.py").write_text("open(%r, 'w').write('x')\n" % str(marker), encoding="utf-8")
        profile = build_profile(read_my_agent(CASE, workspace_root=root / "workspace"))
        adapter = self.Adapter([{"type": "load_skill", "name": "lesson-notes"},
                                {"type": "text", "text": "Стоп."}])
        result = run_agent(adapter, workspace_root=root / "workspace", profile=profile)
        self.assertTrue(any(event["type"] == "skill_loaded" for event in result["trace"]))
        self.assertFalse(marker.exists())

    def test_without_policy_all_student_skills_are_connected(self):
        root = temp_copy(self, "workspace")
        (root / "workspace" / CASE / "15_trust.json").unlink()
        lines = dezhurny.cmd_run(CASE, workspace_root=root / "workspace")
        self.assertIn("my_skills: lesson-notes, project-sync", lines)
        self.assertFalse(any(line.startswith("not connected:") for line in lines))

    def test_chapter_mode_for_every_row(self):
        for _, chapter, _ in FILES:
            with self.subTest(chapter=chapter):
                lines = dezhurny.cmd_status(chapter=chapter)
                self.assertEqual(len(lines), 3)
                self.assertTrue(lines[2].startswith("глава %d |" % chapter))
                self.assertFalse(any(line.startswith("configured:") for line in lines))
        self.assertEqual(run_cli("dezhurny.py", "status", "--chapter", "4").returncode, 2)


class InjectionContentTests(unittest.TestCase):
    def test_task901_is_data_and_every_requirement_hits_a_real_gate(self):
        from school_agent import dispatcher
        calls = []
        original = trust_audit.call_tool

        def spy(request, tools):
            result = original(request, tools)
            calls.append((request["name"], result["executed"], result["error"]["code"]))
            return result

        with mock.patch.object(trust_audit, "call_tool", spy), NoNetworkNoProcesses():
            report = audit_untrusted_document("task-901")
        self.assertEqual(calls, [("publish_report", False, "unknown_tool")])
        self.assertNotIn("publish_report", dispatcher.AVAILABLE_TOOLS)
        self.assertFalse(report["treated_as_instruction"])
        self.assertEqual(report["provenance"]["assigned_by"], "harness")
        self.assertEqual([item["gate"] for item in report["requirements"]],
                         ["dispatcher (глава 7)", "schema read_task_cards (глава 6)", "approval gate (глава 14)"])

    def test_annotations_are_authored_fragments_of_the_card(self):
        annotations = json.loads((WORKSPACE_ROOT / "ch15" / "cases" / "task-901.annotations.json")
                                 .read_text(encoding="utf-8"))
        card = json.loads((WORKSPACE_ROOT / "scenarios" / "injection" / "task-901.json").read_text(encoding="utf-8"))
        self.assertEqual(annotations["kind"], "authored_annotation")
        for item in annotations["requirements"]:
            self.assertIn(item["fragment"], card["notes"])

    def test_card_cannot_raise_its_own_trust(self):
        root = temp_copy(self, "workspace")
        path = root / "workspace" / "scenarios" / "injection" / "task-901.json"
        card = json.loads(path.read_text(encoding="utf-8"))
        path.write_text(json.dumps(dict(card, source_trust="trusted"), ensure_ascii=False), encoding="utf-8")
        report = audit_untrusted_document("task-901", workspace_root=root / "workspace")
        self.assertEqual(report["provenance"], {"assigned_by": "harness", "source": "local_task_cards",
                                                "trust": "untrusted"})


class InjectionReplayTests(unittest.TestCase):
    def test_replay_is_the_existing_scenario(self):
        source = (PROJECT_ROOT / "trust_demo.py").read_text(encoding="utf-8")
        self.assertIn('run_replay_scenario("injection")', source)
        text = (GOLDEN / "ch15_injection_replay.txt").read_text(encoding="utf-8")
        for line in ("evidence: synthetic_script", "skill_loaded: no", "model_quality_verified: false"):
            self.assertIn(line, text)


class StaticSkillAuditTests(unittest.TestCase):
    def test_decisions_come_from_findings(self):
        with NoNetworkNoProcesses():
            reports = {name: audit_skill_sample(name) for name in ("project-status", "project-sync", "suspicious-skill")}
        self.assertEqual({name: report["decision"] for name, report in reports.items()},
                         {"project-status": "connect_minimal", "project-sync": "reject", "suspicious-skill": "reject"})
        self.assertFalse(reports["suspicious-skill"]["skill_md"])
        self.assertIn("сеть", {finding["category"] for finding in reports["project-sync"]["findings"]})

    def test_scripts_are_read_never_executed(self):
        root = temp_copy(self, "untrusted_samples")
        marker = root / "executed.txt"
        script = root / "untrusted_samples" / "project-sync" / "scripts" / "evil.py"
        script.write_text("open(%r, 'w').write('x')\n" % str(marker), encoding="utf-8")
        with NoNetworkNoProcesses():
            report = audit_skill_sample("project-sync", project_root=root)
        self.assertIn("scripts/evil.py", report["scripts"])
        self.assertFalse(marker.exists())

    def test_unknown_sample_is_refused(self):
        with self.assertRaises(ValueError):
            audit_skill_sample("../skills/project-status")
        self.assertEqual(run_cli("trust_demo.py", "audit", "skill", "--sample", "other").returncode, 2)


class McpTrustAuditTests(unittest.TestCase):
    def test_self_declared_trust_changes_nothing(self):
        root = temp_copy(self, "untrusted_samples")
        path = root / "untrusted_samples" / "mock_mcp_server.json"
        card = json.loads(path.read_text(encoding="utf-8"))
        path.write_text(json.dumps(dict(card, trust="trusted", provenance="verified"), ensure_ascii=False),
                        encoding="utf-8")
        with NoNetworkNoProcesses():
            forged = audit_mcp_sample("mock-mcp-server", project_root=root)
            original = audit_mcp_sample("mock-mcp-server")
        self.assertEqual(forged["decision"], original["decision"])
        self.assertEqual(forged["provenance"], original["provenance"])
        self.assertEqual(forged["declared_provenance"], "verified")

    def test_broken_card_is_an_error(self):
        root = temp_copy(self, "untrusted_samples")
        (root / "untrusted_samples" / "mock_mcp_server.json").write_text("{", encoding="utf-8")
        with self.assertRaises(ValueError):
            audit_mcp_sample("mock-mcp-server", project_root=root)

    def test_chapter_4_card_and_golden_untouched(self):
        self.assertEqual(json.loads((WORKSPACE_ROOT / "ch04" / "mcp" / "server.json")
                                    .read_text(encoding="utf-8"))["kind"], "mock_mcp_server_card")
        self.assertTrue((GOLDEN / "ch04_mcp_map.txt").is_file())


class NoSecondMechanismTests(unittest.TestCase):
    def test_audit_modules_only_read(self):
        for path in ("school_agent/trust.py", "school_agent/trust_audit.py", "trust_demo.py"):
            source = (PROJECT_ROOT / path).read_text(encoding="utf-8")
            for token in ("write_text", "write_bytes", "importlib", "exec(", "TraceRecorder(", "while ",
                          "_split_skill_file"):
                with self.subTest(path=path, token=token):
                    self.assertNotIn(token, source)
            # Слова subprocess/urllib есть в шаблонах рубрики; запрещён именно импорт.
            self.assertIsNone(re.search(r"^\s*(import|from)\s+(subprocess|socket|urllib|requests|http)", source, re.M))


class ErrorRowStopsRunTests(unittest.TestCase):
    """Вердикт главы 15, C1: строка с ошибкой в status не обещает запуск, run действительно не запускается."""

    # Для каждой строки конструктора — файл, который читатель строки отклоняет (ConfigError).
    BROKEN = {
        "01_goal.md": "",
        "02_stop_policy.json": "{max_steps: 2}",
        "03_workspace_policy.json": '{"allowed_operations": ["read", "write"], "writable_prefix": "tasks/"}',
        "05_task_contract.md": "Цель без разделов.\n",
        "07_tools.json": '{"enabled": ["publish_report"]}',
        "08_my_tool.py": "def broken(:\n",
        "09_skills": None,
        "10_state.json": '{"runs": -1}',
        "11_evals.json": "{}",
        "12_trace.json": '{"enabled": "yes"}',
        "13_versions": "файл вместо папки снимков",
        "14_permissions.json": "{bad",
        "15_trust.json": '{"external_content": "trusted", "skills": {}}',
        "16_run_plan.json": '{"max_sessions": 9, "checkpoint": "drafts/x.json", "owner": "team"}',
        "17_release_candidate.json": '{"label": "festival-rc1", "ready": true}',
    }

    def broken_dir(self, name):
        # CLI читает только папки внутри настоящего workspace/; временная папка — в drafts/.
        directory = Path(tempfile.mkdtemp(dir=WORKSPACE_ROOT / "drafts"))
        self.addCleanup(shutil.rmtree, directory)
        if self.BROKEN[name] is None:
            (directory / name).mkdir()
        else:
            (directory / name).write_text(self.BROKEN[name], encoding="utf-8")
        return "workspace/drafts/" + directory.name

    def test_every_active_row_is_covered(self):
        # С 0.17.0 строка 13 читается (ретрофит главы 13): зарезервированных строк нет.
        self.assertEqual(sorted(self.BROKEN), sorted(name for name, _, _ in FILES))

    def test_run_stops_and_status_says_so(self):
        for name in self.BROKEN:
            chapter = next(number for file, number, _ in FILES if file == name)
            with self.subTest(file=name):
                relative = self.broken_dir(name)
                status = run_cli("dezhurny.py", "status", "--chapter", str(chapter), "--dir", relative)
                self.assertEqual(status.returncode, 0, status.stderr.decode("utf-8"))
                row = status.stdout.decode("utf-8").splitlines()[2]
                self.assertIn(" | ошибка: ", row)
                self.assertTrue(row.endswith(" | run не запускается, пока файл не исправлен"), row)
                error = row.split(" | ")[2][len("ошибка: "):]
                result = run_cli("dezhurny.py", "run", "--dir", relative)
                self.assertEqual(result.returncode, 2)
                self.assertEqual(result.stdout, b"")
                self.assertIn(error, result.stderr.decode("utf-8"))
                self.assertNotIn("Traceback", result.stderr.decode("utf-8"))


class RegressionSnapshot(unittest.TestCase):
    def test_old_golden_untouched_except_chapter_14_errata(self):
        names = sorted(path.name for path in GOLDEN.iterdir() if not RETROFIT_GOLDEN.match(path.name)
                       if not re.match(r"ch1[5-9]_", path.name) and path.name != "ch14_dezhurny_status.txt")
        self.assertEqual(len(names), OLD_GOLDEN_COUNT)
        digest = hashlib.sha256()
        for name in names:
            digest.update(name.encode("utf-8"))
            digest.update(hashlib.sha256((GOLDEN / name).read_bytes()).digest())
        self.assertEqual(digest.hexdigest(), OLD_GOLDEN_DIGEST)
        self.assertEqual(len([path for path in GOLDEN.iterdir() if path.name.startswith("ch15_")]), 9)


if __name__ == "__main__":
    unittest.main()
