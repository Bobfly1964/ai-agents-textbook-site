"""Golden и технические границы access-демо главы 3."""

import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import access_demo
from access_demo import check_workspace_access
from school_agent.paths import PROJECT_ROOT


GOLDEN = PROJECT_ROOT / "tests" / "golden"

ACCESS_CASES = (
    (
        "access_read_inside",
        ("--access", "read", "--path", "tasks/task-003.json"),
    ),
    (
        "access_write_denied",
        ("--access", "write", "--path", "tasks/task-003.json"),
    ),
    (
        "access_missing",
        ("--access", "read", "--path", "tasks/missing.json"),
    ),
    (
        "access_outside",
        ("--access", "read", "--path", "../outside.json"),
    ),
)


class AccessDemoTests(unittest.TestCase):
    def check_output(self, golden, *args):
        result = subprocess.run(
            [sys.executable, "access_demo.py", *args],
            cwd=PROJECT_ROOT,
            capture_output=True,
            text=True,
            encoding="utf-8",
            env=dict(os.environ, PYTHONIOENCODING="utf-8"),
            check=True,
        )
        expected = (GOLDEN / golden).read_text(encoding="utf-8")
        self.assertEqual(result.stdout.replace("\r\n", "\n"), expected)
        self.assertEqual(result.stderr, "")

    def test_human_and_json_goldens(self):
        for basename, args in ACCESS_CASES:
            with self.subTest(case=basename, mode="human"):
                self.check_output(basename + ".txt", *args)
            with self.subTest(case=basename, mode="json"):
                self.check_output(basename + ".json", *args, "--json")

    def test_json_is_opt_in(self):
        result = subprocess.run(
            [
                sys.executable,
                "access_demo.py",
                "--access",
                "read",
                "--path",
                "tasks/task-003.json",
            ],
            cwd=PROJECT_ROOT,
            capture_output=True,
            text=True,
            encoding="utf-8",
            env=dict(os.environ, PYTHONIOENCODING="utf-8"),
            check=True,
        )
        self.assertTrue(result.stdout.startswith("операция: read\n"))
        with self.assertRaises(json.JSONDecodeError):
            json.loads(result.stdout)

    def test_default_write_is_stopped_before_file_open(self):
        target = PROJECT_ROOT / "workspace" / "tasks" / "task-003.json"
        before = target.read_bytes()
        with patch.object(Path, "write_text") as writer:
            result = check_workspace_access("tasks/task-003.json", "write")
        writer.assert_not_called()
        self.assertEqual(result["status"], "denied")
        self.assertEqual(result["reason"], "operation_not_allowed")
        self.assertEqual(target.read_bytes(), before)

    def test_write_branch_is_reachable_for_service_draft(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            target = root / "drafts" / "write-proof.txt"
            target.parent.mkdir()
            target.write_text("before\n", encoding="utf-8")
            with patch.object(access_demo, "WORKSPACE_ROOT", root):
                with patch.object(
                    access_demo,
                    "ALLOWED_OPERATIONS",
                    frozenset({"read", "write"}),
                ):
                    result = check_workspace_access(
                        "drafts/write-proof.txt",
                        "write",
                    )
            self.assertEqual(result["status"], "allowed")
            self.assertEqual(result["reason"], "write_completed")
            self.assertEqual(
                target.read_text(encoding="utf-8"),
                access_demo.WRITE_PROOF_TEXT,
            )

    def test_enabled_write_cannot_modify_learning_card_and_matches_goldens(self):
        target = PROJECT_ROOT / "workspace" / "tasks" / "task-003.json"
        before = target.read_bytes()
        with patch.object(
            access_demo,
            "ALLOWED_OPERATIONS",
            frozenset({"read", "write"}),
        ):
            with patch.object(Path, "write_text") as writer:
                result = check_workspace_access("tasks/task-003.json", "write")
        writer.assert_not_called()
        self.assertEqual(result["status"], "denied")
        self.assertEqual(result["reason"], "path_not_writable")
        self.assertEqual(target.read_bytes(), before)
        self.assertEqual(
            access_demo.format_access_observation(result),
            (GOLDEN / "access_write_outside_drafts.txt").read_text(
                encoding="utf-8"
            ),
        )
        self.assertEqual(
            json.dumps(result, ensure_ascii=False) + "\n",
            (GOLDEN / "access_write_outside_drafts.json").read_text(
                encoding="utf-8"
            ),
        )

    def test_absolute_path_is_denied(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            with patch.object(access_demo, "WORKSPACE_ROOT", root):
                result = check_workspace_access(root / "file.txt", "read")
        self.assertEqual(result["status"], "denied")
        self.assertEqual(result["reason"], "path_outside_workspace")

    def test_symlink_outside_is_denied(self):
        with tempfile.TemporaryDirectory() as directory:
            base = Path(directory)
            root = base / "workspace"
            root.mkdir()
            outside = base / "outside.txt"
            outside.write_text("outside\n", encoding="utf-8")
            link = root / "link.txt"
            try:
                link.symlink_to(outside)
            except OSError as exc:
                self.skipTest("symbolic links unavailable: " + str(exc))
            with patch.object(access_demo, "WORKSPACE_ROOT", root):
                result = check_workspace_access("link.txt", "read")
        self.assertEqual(result["status"], "denied")
        self.assertEqual(result["reason"], "path_outside_workspace")

    def test_unknown_operation_is_not_executed(self):
        with patch.object(Path, "read_text") as reader, patch.object(Path, "write_text") as writer:
            result = check_workspace_access("tasks/task-003.json", "delete")
        reader.assert_not_called()
        writer.assert_not_called()
        self.assertEqual(result["status"], "error")
        self.assertEqual(result["reason"], "unknown_operation")


if __name__ == "__main__":
    unittest.main()
