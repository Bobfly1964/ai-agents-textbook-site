"""Контракт главы 16: Session — один run «Дежурного», checkpoint между Session пишет и проверяет harness."""

import hashlib
import json
import os
import re
import shutil
import socket
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

import dezhurny
import long_work_demo
from school_agent import approval
from school_agent.long_work import (
    RunPlanError, build_checkpoint, session_number, validate_architecture_handoff, validate_run_plan,
)
from school_agent.my_agent_config import ConfigError, read_my_agent
from school_agent.paths import PROJECT_ROOT, WORKSPACE_ROOT
from school_agent.state_store import build_handoff, validate_project_state

GOLDEN = PROJECT_ROOT / "tests" / "golden"
# Golden блоков «Достраиваем „Дежурного“» (ретрофит глав 1–13, 0.17.0) в слепки прежних глав не входят.
RETROFIT_GOLDEN = re.compile(r"ch(0\d|1[0-3])_dezhurny_")
FIXTURES = PROJECT_ROOT / "tests" / "fixtures" / "ch16"
CASE = "ch16/cases/long-work"
CHECKPOINT = "drafts/ch16/run_state.json"
PLAN = {"max_sessions": 2, "checkpoint": CHECKPOINT, "owner": "project-team"}
# Слепок 101 эталона 0.14.1 (главы 1–15): глава 16 не меняет ни одного прежнего вывода.
OLD_GOLDEN_COUNT = 101
OLD_GOLDEN_DIGEST = "3b77f0a4eadb2460f48f979925be4cb09a4c1a892347e49b273039afaf9d09e0"
STATE_STORE_SHA256 = "60b6ad0de3d498d6320e17977a7ee7412586eacb2cd0c45d12a317a864cc0f4b"


def run_cli(script, *args):
    return subprocess.run([sys.executable, script, *args], cwd=PROJECT_ROOT,
                          capture_output=True, env=dict(os.environ, PYTHONIOENCODING="utf-8"))


def temp_workspace(test):
    directory = tempfile.mkdtemp()
    test.addCleanup(shutil.rmtree, directory)
    workspace = Path(directory) / "workspace"
    shutil.copytree(WORKSPACE_ROOT, workspace)
    return workspace


def tasks_digest(workspace):
    return {path.name: hashlib.sha256(path.read_bytes()).hexdigest()
            for path in sorted((workspace / "tasks").glob("*.json"))}


class GoldenTests(unittest.TestCase):
    def check(self, golden, script, *args):
        result = run_cli(script, *args)
        self.assertEqual(result.returncode, 0, result.stderr.decode("utf-8"))
        self.assertEqual(result.stderr, b"")
        printed = result.stdout.decode("utf-8").replace("\r\n", "\n")
        self.assertEqual(printed, (GOLDEN / golden).read_text(encoding="utf-8"))
        self.assertNotIn(str(PROJECT_ROOT), printed)

    def with_fixture(self, fixture, golden):
        target = WORKSPACE_ROOT / "my_agent" / "16_run_plan.json"
        self.assertFalse(target.exists())
        shutil.copyfile(FIXTURES / fixture, target)
        try:
            self.check(golden, "dezhurny.py", "status", "--chapter", "16")
        finally:
            target.unlink()

    def test_status_with_plan(self):
        self.with_fixture("16_run_plan.json", "ch16_dezhurny_status.txt")

    def test_status_with_invalid_plan(self):
        self.with_fixture("16_run_plan_invalid.json", "ch16_run_plan_invalid.txt")

    def test_three_sessions_in_order(self):
        # Как в главе: три одинаковые команды подряд; checkpoint — в настоящем drafts/, потом убирается.
        folder = WORKSPACE_ROOT / "drafts" / "ch16"
        self.assertFalse(folder.exists())
        self.addCleanup(shutil.rmtree, folder, True)
        for golden in ("ch16_run_session_1.txt", "ch16_run_session_2.txt", "ch16_run_outer_stop.txt"):
            with self.subTest(golden=golden):
                self.check(golden, "dezhurny.py", "run", "--dir", "workspace/" + CASE)

    def test_long_work_demo_outputs(self):
        for golden, args in (("ch16_repeat_applied_once.txt", ("repeat",)),
                             ("ch16_subagent_handoff.txt", ("handoff", "--case", "analyzer")),
                             ("ch16_handoff_missing_owner.txt", ("handoff", "--case", "missing-owner"))):
            with self.subTest(golden=golden):
                self.check(golden, "long_work_demo.py", *args)


class RunPlanTests(unittest.TestCase):
    def test_valid_plan(self):
        self.assertEqual(validate_run_plan(dict(PLAN)), PLAN)
        self.assertEqual(validate_run_plan(json.loads((FIXTURES / "16_run_plan.json").read_text(encoding="utf-8")))
                         ["max_sessions"], 3)

    def test_invalid_plans(self):
        cases = [[], dict(PLAN, handoff_to="subagent"), {"max_sessions": 2, "checkpoint": CHECKPOINT},
                 dict(PLAN, max_sessions=0), dict(PLAN, max_sessions=6), dict(PLAN, max_sessions=True),
                 dict(PLAN, max_sessions="2"), dict(PLAN, checkpoint="../outside.json"),
                 dict(PLAN, checkpoint="tasks/task-001.json"), dict(PLAN, checkpoint="drafts/../tasks/x.json"),
                 dict(PLAN, checkpoint="/drafts/x.json"), dict(PLAN, checkpoint="drafts"),
                 dict(PLAN, checkpoint="drafts\\x.json"), dict(PLAN, checkpoint=5), dict(PLAN, owner=" ")]
        for value in cases:
            with self.subTest(value=value):
                with self.assertRaises(RunPlanError):
                    validate_run_plan(value)

    def test_plan_outside_drafts_is_rejected_without_reading_disk(self):
        with mock.patch.object(Path, "exists", side_effect=AssertionError("диск не читается")), \
                mock.patch.object(Path, "read_text", side_effect=AssertionError("диск не читается")):
            with self.assertRaises(RunPlanError):
                validate_run_plan(dict(PLAN, checkpoint="../outside.json"))

    def test_invalid_plan_is_a_status_error_and_stops_run(self):
        workspace = temp_workspace(self)
        shutil.copyfile(FIXTURES / "16_run_plan_invalid.json", workspace / "my_agent" / "16_run_plan.json")
        lines = dezhurny.cmd_status(workspace_root=workspace, chapter=16)
        self.assertEqual(lines[2], "глава 16 | 16_run_plan.json | ошибка: 16_run_plan.json: checkpoint — "
                                   "относительный путь внутри drafts/ | run не запускается, пока файл не исправлен")
        with mock.patch.object(dezhurny, "run_replay_scenario") as loop, \
                mock.patch.object(dezhurny, "load_state") as load:
            with self.assertRaises(ConfigError):
                dezhurny.cmd_run(workspace_root=workspace)
        loop.assert_not_called()
        load.assert_not_called()

    def test_one_source_of_rules(self):
        for path in ("school_agent/my_agent_config.py", "dezhurny.py", "long_work_demo.py"):
            source = (PROJECT_ROOT / path).read_text(encoding="utf-8")
            with self.subTest(path=path):
                self.assertNotIn("def validate_run_plan", source)
                self.assertNotIn("max_sessions — целое", source)
                self.assertNotIn("def validate_architecture_handoff", source)

    def test_session_number(self):
        self.assertEqual(session_number(None), 1)
        self.assertEqual(session_number({"sessions_used": 2}), 3)
        for value in ({}, {"sessions_used": 0}, {"sessions_used": "1"}, {"sessions_used": True}):
            with self.subTest(value=value):
                with self.assertRaises(RunPlanError):
                    session_number(value)

    def test_checkpoint_by_terminal(self):
        report = ("# Черновик\n\n## Блокеры\n- `task-003`: Нет списка\n- `task-003`: Нет зала\n"
                  "\nЧерновик. Отправка и изменение карточек не выполнялись.\n")
        cases = {"limit": ("Новая Session", None), "needs_input": ("Ответить на вопрос", "Какая копия верна?"),
                 "error": ("Устранить причину", None), "success": ("Передать сводку Owner: project-team", None)}
        for terminal, (step, question) in cases.items():
            with self.subTest(terminal=terminal):
                result = {"terminal": terminal, "reason": question, "report": report, "scenario": "success"}
                state = build_checkpoint({"sessions_used": 1}, result, PLAN, "Проверить карточки")
                self.assertTrue(state["next_step"].startswith(step))
                self.assertEqual(state["sessions_used"], 2)
                self.assertEqual(state["blocked_tasks"], ["task-003"])
                self.assertEqual(state.get("pending_question"), question)
                self.assertEqual(validate_project_state(state), [])
                self.assertNotIn("sessions_used", build_handoff(state))
        state = build_checkpoint(None, {"terminal": "limit", "report": None}, PLAN, None)
        self.assertEqual((state["project"], state["blocked_tasks"], state["sessions_used"]), ("Дежурный", [], 1))


class SessionTests(unittest.TestCase):
    def setUp(self):
        self.workspace = temp_workspace(self)
        self.checkpoint = self.workspace / "drafts" / "ch16" / "run_state.json"

    def run_case(self):
        return dezhurny.cmd_run(CASE, workspace_root=self.workspace)

    def test_three_sessions(self):
        first = self.run_case()
        self.assertIn("session: 1/2 | checkpoint: нет — первая Session", first)
        self.assertIn("Остановка: limit", first)
        saved = json.loads(self.checkpoint.read_text(encoding="utf-8"))
        self.assertEqual((saved["sessions_used"], saved["last_terminal"]), (1, "limit"))
        self.assertEqual(validate_project_state(saved), [])

        second = self.run_case()
        self.assertTrue(any(line.startswith("session: 2/2 | checkpoint loaded | previous: limit | next step: ")
                            for line in second))
        self.assertEqual(json.loads(self.checkpoint.read_text(encoding="utf-8"))["sessions_used"], 2)

        before = self.checkpoint.read_bytes()
        with mock.patch.object(dezhurny, "run_replay_scenario") as loop:
            third = self.run_case()
        loop.assert_not_called()
        self.assertEqual(third[-2], "outer loop: стоп — sessions 2/2 использованы; "
                                    "продолжение решает Owner: project-team")
        self.assertEqual(self.checkpoint.read_bytes(), before)
        self.assertFalse(any(line.startswith("Шаг ") for line in third))

    def test_handoff_line_has_no_transcript_or_secrets(self):
        lines = self.run_case()
        self.assertIn("handoff: build_handoff — поля project, goal, status, blocked_tasks, next_step | "
                      "transcript: no | secrets: 0 | owner: project-team", lines)

    def test_invalid_checkpoint_stops_before_the_loop(self):
        self.checkpoint.parent.mkdir(parents=True)
        cases = {"missing field next_step": {"project": "p", "goal": "g", "status": "limit", "sessions_used": 1},
                 "forbidden secret field": {"project": "p", "goal": "g", "status": "limit", "next_step": "n",
                                            "sessions_used": 1, "api_token": "x"},
                 "некорректный JSON": None,
                 "missing field sessions_used": {"project": "p", "goal": "g", "status": "limit", "next_step": "n"}}
        for message, value in cases.items():
            with self.subTest(message=message):
                self.checkpoint.write_text("{bad" if value is None else json.dumps(value), encoding="utf-8")
                with mock.patch.object(dezhurny, "run_replay_scenario") as loop:
                    with self.assertRaises(ConfigError) as caught:
                        self.run_case()
                loop.assert_not_called()
                self.assertTrue(str(caught.exception).startswith("checkpoint: not accepted — "))
                self.assertIn(message, str(caught.exception))

    def test_invalid_checkpoint_cli_exit_2(self):
        folder = WORKSPACE_ROOT / "drafts" / "ch16"
        self.assertFalse(folder.exists())
        self.addCleanup(shutil.rmtree, folder, True)
        folder.mkdir()
        (folder / "run_state.json").write_text('{"project": "p", "goal": "g", "status": "limit", '
                                                '"sessions_used": 1}', encoding="utf-8")
        result = run_cli("dezhurny.py", "run", "--dir", "workspace/" + CASE)
        self.assertEqual(result.returncode, 2)
        self.assertEqual(result.stdout, b"")
        self.assertIn("checkpoint: not accepted — missing field next_step", result.stderr.decode("utf-8"))

    def test_without_plan_run_is_unchanged(self):
        (self.workspace / CASE / "16_run_plan.json").unlink()
        lines = self.run_case()
        self.assertFalse(any(line.startswith(("session:", "checkpoint:", "handoff:", "outer loop:"))
                             for line in lines))
        self.assertFalse(self.checkpoint.exists())

    def test_state_and_plan_are_independent(self):
        (self.workspace / CASE / "10_state.json").write_text('{"runs": 0}', encoding="utf-8")
        lines = self.run_case()
        self.assertIn("state: первый запуск (запусков теперь: 1)", lines)
        self.assertTrue(self.checkpoint.exists())
        self.assertEqual(json.loads((self.workspace / CASE / "10_state.json").read_text(encoding="utf-8"))["runs"], 1)

    def test_eval_does_not_touch_checkpoint(self):
        shutil.copyfile(WORKSPACE_ROOT / "my_agent" / "examples" / "full" / "11_evals.json",
                        self.workspace / CASE / "11_evals.json")
        dezhurny.cmd_eval(CASE, workspace_root=self.workspace)
        self.assertFalse(self.checkpoint.exists())

    def test_status_row(self):
        config = read_my_agent(CASE, workspace_root=self.workspace)
        row = next(row for row in config["rows"] if row["file"] == "16_run_plan.json")
        self.assertEqual(row["state"], "configured")
        lines = dezhurny.cmd_status(CASE, workspace_root=self.workspace, chapter=16)
        self.assertEqual(lines[2], "глава 16 | 16_run_plan.json | настроено: max_sessions 2; checkpoint "
                                   "drafts/ch16/run_state.json; owner project-team | run: Session с checkpoint; "
                                   "после max_sessions — остановка до цикла")


class RepeatTests(unittest.TestCase):
    def test_second_application_has_no_effect(self):
        shipped = tasks_digest(WORKSPACE_ROOT)
        with mock.patch.object(approval, "save_state", wraps=approval.save_state) as save:
            lines = long_work_demo.cmd_repeat()
        self.assertEqual(save.call_count, 1)
        self.assertIn("card changed: once", lines)
        self.assertTrue(lines[4].startswith("second: applied: no | already_applied: yes"))
        self.assertEqual(tasks_digest(WORKSPACE_ROOT), shipped)
        self.assertNotIn(tempfile.gettempdir(), "\n".join(lines))


class ArchitectureHandoffTests(unittest.TestCase):
    VALID = {"subtask": "анализ карточек", "executor": "analyzer", "result": {"count": 3},
             "owner": "project-team", "basis": "fact", "evidence": "observation build_status_report"}

    def test_analyzer_uses_no_model_network_or_processes(self):
        def refuse(*args, **kwargs):
            raise AssertionError("анализатор не запускает модель, сеть или процессы")
        with mock.patch("school_agent.agent.run_agent", refuse), \
                mock.patch("school_agent.agent.run_replay_scenario", refuse), \
                mock.patch.object(socket, "socket", refuse), mock.patch.object(subprocess, "Popen", refuse):
            lines = long_work_demo.cmd_handoff("analyzer")
        self.assertIn("model/network: not used", lines)
        self.assertIn("decision made by executor: no", lines)
        self.assertEqual(lines[-1], "result: accepted")

    def test_missing_owner_is_not_accepted(self):
        lines = long_work_demo.cmd_handoff("missing-owner")
        self.assertEqual(lines[-2], "result: not accepted — нет owner")

    def test_rules(self):
        self.assertEqual(validate_architecture_handoff(dict(self.VALID)), [])
        heuristic = dict(self.VALID, basis="heuristic")
        del heuristic["evidence"]
        self.assertEqual(validate_architecture_handoff(heuristic), [])
        fact = dict(self.VALID)
        del fact["evidence"]
        self.assertEqual(validate_architecture_handoff(fact), ["basis fact требует evidence"])
        self.assertIn("basis — одно из fact, heuristic, hypothesis, forecast",
                      validate_architecture_handoff(dict(self.VALID, basis="guess")))
        self.assertEqual(validate_architecture_handoff(dict(self.VALID, owner="")), ["нет owner"])
        for field in ("transcript", "history", "permissions", "trust"):
            with self.subTest(field=field):
                self.assertIn("запрещено поле " + field, validate_architecture_handoff(dict(self.VALID, **{field: []})))
        self.assertEqual(validate_architecture_handoff(dict(self.VALID, result={"password": "x"})),
                         ["forbidden secret field"])
        self.assertIn("result должен быть объектом", validate_architecture_handoff(dict(self.VALID, result=[])))


class NoSecondLoopTests(unittest.TestCase):
    def test_sources(self):
        for path in ("school_agent/long_work.py", "long_work_demo.py"):
            source = (PROJECT_ROOT / path).read_text(encoding="utf-8")
            with self.subTest(path=path):
                self.assertNotIn("while ", source)
                self.assertNotIn("def run_agent", source)
                self.assertNotIn("run_agent(", source)
                self.assertIsNone(re.search(r"^\s*(import|from)\s+(subprocess|socket|urllib|requests|http)",
                                            source, re.M))

    def test_long_work_module_neither_reads_nor_prints(self):
        source = (PROJECT_ROOT / "school_agent" / "long_work.py").read_text(encoding="utf-8")
        for token in ("open(", "read_text", "write_text", "print(", "load_state(", "save_state("):
            with self.subTest(token=token):
                self.assertNotIn(token, source)


class RegressionSnapshot(unittest.TestCase):
    def test_old_golden_and_state_store_untouched(self):
        names = sorted(path.name for path in GOLDEN.iterdir() if not RETROFIT_GOLDEN.match(path.name) if not re.match(r"ch1[6-9]_", path.name))
        self.assertEqual(len(names), OLD_GOLDEN_COUNT)
        digest = hashlib.sha256()
        for name in names:
            digest.update(name.encode("utf-8"))
            digest.update(hashlib.sha256((GOLDEN / name).read_bytes()).digest())
        self.assertEqual(digest.hexdigest(), OLD_GOLDEN_DIGEST)
        self.assertEqual(len([path for path in GOLDEN.iterdir() if path.name.startswith("ch16_")]), 8)
        self.assertEqual(hashlib.sha256((PROJECT_ROOT / "school_agent" / "state_store.py").read_bytes()).hexdigest(),
                         STATE_STORE_SHA256)


if __name__ == "__main__":
    unittest.main()
