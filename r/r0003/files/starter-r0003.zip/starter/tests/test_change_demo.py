"""Контракт главы 13: proposal не норма, diff не Eval, Regression — только pass → fail на том же наборе."""

import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

from school_agent.paths import PROJECT_ROOT, WORKSPACE_ROOT, WorkspaceBoundaryError
from school_agent.versioning import (
    VersioningError,
    compare_version_results,
    diff_skill_versions,
    load_version_cases,
    review_change_proposal,
    run_version_cases,
    snapshot_files,
)

GOLDEN = PROJECT_ROOT / "tests" / "golden"
# Golden блоков «Достраиваем „Дежурного“» (ретрофит глав 1–13, 0.17.0) в слепки прежних глав не входят.
RETROFIT_GOLDEN = re.compile(r"ch(0\d|1[0-3])_dezhurny_")
CH13 = WORKSPACE_ROOT / "ch13"
CASES = "ch13/version_cases.json"
PROPOSAL = "ch13/change_proposals/validate-task-id.json"
V1 = "ch13/versions/1.0.0/project-status"
CANDIDATE = "ch13/versions/1.1.0-candidate/project-status"
GOOD = "ch13/versions/1.1.0-good/project-status"
BROKEN = "ch13/cases/broken-version/project-status"
CLI_CASES = ("--cases", "workspace/" + CASES)
# Слепок 78 эталонов глав 1–12: имя и SHA-256 каждого файла, по порядку имён.
OLD_GOLDEN_COUNT = 78
OLD_GOLDEN_DIGEST = "dbc0e91d26c9700bc133836936ee2b176925fb5b162a9513fee158b4efd42d94"


def run_cli(*args):
    return subprocess.run([sys.executable, "change_demo.py", *args], cwd=PROJECT_ROOT,
                          capture_output=True, env=dict(os.environ, PYTHONIOENCODING="utf-8"))


def temp_workspace(test):
    directory = tempfile.mkdtemp()
    test.addCleanup(shutil.rmtree, directory)
    workspace = Path(directory) / "workspace"
    shutil.copytree(WORKSPACE_ROOT, workspace)
    return workspace


class ChangeDemoGoldenTests(unittest.TestCase):
    def check_output(self, golden, *args):
        result = run_cli(*args)
        self.assertEqual(result.returncode, 0)
        printed = result.stdout.decode("utf-8").replace("\r\n", "\n")
        self.assertEqual(printed, (GOLDEN / golden).read_text(encoding="utf-8"))
        self.assertEqual(result.stderr, b"")
        self.assertNotIn(str(PROJECT_ROOT), printed)
        return printed

    def test_six_outputs(self):
        runs = {
            "ch13_change_proposal.txt": ("proposal", "workspace/" + PROPOSAL),
            "ch13_diff_regression.txt": ("diff", "workspace/" + V1, "workspace/" + CANDIDATE),
            "ch13_eval_v1.txt": ("eval", "workspace/" + V1, *CLI_CASES),
            "ch13_compare_regression.txt": ("compare", "workspace/" + V1, "workspace/" + CANDIDATE,
                                            *CLI_CASES),
            "ch13_compare_good.txt": ("compare", "workspace/" + V1, "workspace/" + GOOD, *CLI_CASES),
            "ch13_broken_version.txt": ("eval", "workspace/" + BROKEN, *CLI_CASES),
        }
        for golden, args in runs.items():
            with self.subTest(golden=golden):
                self.check_output(golden, *args)


class ProposalTests(unittest.TestCase):
    def rewrite(self, workspace, **changes):
        path = workspace / PROPOSAL
        document = json.loads(path.read_text(encoding="utf-8"))
        document.update(changes)
        path.write_text(json.dumps(document, ensure_ascii=False), encoding="utf-8")

    def test_root_cause_comes_from_the_trace_not_the_proposal(self):
        review = review_change_proposal(PROPOSAL)
        self.assertEqual(review["root_cause"], "invalid_arguments")
        self.assertEqual(review["new_norm"], False)
        self.assertEqual(review["status"], "proposed")
        self.assertIsNotNone(review["evidence_event_id"])

    def test_proposal_cannot_declare_itself_a_norm(self):
        workspace = temp_workspace(self)
        self.rewrite(workspace, status="accepted")
        with self.assertRaises(VersioningError):
            review_change_proposal(PROPOSAL, workspace_root=workspace)

    def test_evidence_must_confirm_the_proposal(self):
        workspace = temp_workspace(self)
        self.rewrite(workspace, expected_root_cause="unknown_tool")
        with self.assertRaises(VersioningError):
            review_change_proposal(PROPOSAL, workspace_root=workspace)

    def test_source_case_must_be_in_the_same_set(self):
        workspace = temp_workspace(self)
        self.rewrite(workspace, source_eval_case="no-such-case")
        with self.assertRaises(VersioningError):
            review_change_proposal(PROPOSAL, workspace_root=workspace)

    def test_proposal_targets_the_case_set_target(self):
        review = review_change_proposal(PROPOSAL)
        self.assertEqual(review["source_eval_case"], load_version_cases(CASES)["target_case"])


class DiffTests(unittest.TestCase):
    def test_diff_shows_the_fix_and_two_lost_rules(self):
        result = diff_skill_versions(V1, CANDIDATE)
        self.assertEqual([line[0] for line in result["lines"]], ["-", "+", "-", "-"])
        self.assertIn("для каждого task_id", result["lines"][1])
        self.assertIn("needs_input", result["lines"][2])
        self.assertEqual(result["lines"][3], "- Не меняй статусы.")

    def test_good_candidate_changes_one_line(self):
        self.assertEqual(len(diff_skill_versions(V1, GOOD)["lines"]), 2)

    def test_same_version_has_empty_diff(self):
        self.assertEqual(diff_skill_versions(V1, V1)["lines"], [])

    def test_broken_version_has_no_diff(self):
        with self.assertRaises(ValueError):
            diff_skill_versions(V1, BROKEN)


class SameSetTests(unittest.TestCase):
    def test_candidate_fixes_target_and_breaks_two(self):
        report = compare_version_results(run_version_cases(V1, CASES), run_version_cases(CANDIDATE, CASES))
        self.assertEqual((report["target_before"], report["target_after"]), (False, True))
        self.assertEqual(report["regressions"], ["asks-on-ambiguity", "no-status-write"])
        self.assertEqual((report["decision"], report["rollback_to"]), ("revert", "1.0.0"))

    def test_good_candidate_keeps_every_old_pass(self):
        report = compare_version_results(run_version_cases(V1, CASES), run_version_cases(GOOD, CASES))
        self.assertEqual(report["regressions"], [])
        self.assertEqual((report["decision"], report["rollback_to"]), ("keep", None))

    def test_new_fail_without_old_pass_is_not_a_regression(self):
        before = run_version_cases(V1, CASES)
        after = run_version_cases(V1, CASES)
        report = compare_version_results(before, after)
        self.assertEqual(report["regressions"], [])
        self.assertEqual(report["decision"], "revert")  # целевой случай не исправлен

    def test_different_eval_sets_are_not_compared(self):
        before = run_version_cases(V1, CASES)
        after = dict(run_version_cases(GOOD, CASES), eval_set="other-set")
        with self.assertRaises(VersioningError):
            compare_version_results(before, after)

    def test_dropping_failed_cases_is_not_compared(self):
        before = run_version_cases(V1, CASES)
        after = run_version_cases(CANDIDATE, CASES)
        after["cases"] = [case for case in after["cases"] if case["passed"]]
        with self.assertRaises(VersioningError):
            compare_version_results(before, after)

    def test_compare_takes_one_cases_path(self):
        result = run_cli("compare", "workspace/" + V1, "workspace/" + GOOD,
                         "--cases", "workspace/" + CASES, "--cases-after", "workspace/" + CASES)
        self.assertEqual(result.returncode, 2)

    def test_decision_comes_from_content_not_from_the_name(self):
        workspace = temp_workspace(self)
        good = workspace / GOOD / "SKILL.md"
        good.write_bytes((workspace / CANDIDATE / "SKILL.md").read_bytes())
        report = compare_version_results(run_version_cases(V1, CASES, workspace_root=workspace),
                                         run_version_cases(GOOD, CASES, workspace_root=workspace))
        self.assertEqual(report["after"], "1.1.0-good")
        self.assertEqual(report["decision"], "revert")


class BrokenVersionTests(unittest.TestCase):
    def test_broken_version_gets_no_partial_score(self):
        result = run_version_cases(BROKEN, CASES)
        self.assertFalse(result["accepted"])
        self.assertEqual((result["cases"], result["passed"], result["total"]), ([], 0, 0))
        self.assertEqual(result["reason"], "у project-status нет SKILL.md")

    def test_broken_version_is_not_compared(self):
        with self.assertRaises(VersioningError):
            compare_version_results(run_version_cases(V1, CASES), run_version_cases(BROKEN, CASES))
        printed = run_cli("compare", "workspace/" + V1, "workspace/" + BROKEN, *CLI_CASES)
        self.assertEqual(printed.returncode, 0)
        self.assertIn(b"decision: not compared", printed.stdout)
        self.assertNotIn(b"regressions:", printed.stdout)


class BoundaryTests(unittest.TestCase):
    def test_functions_read_only_inside_workspace(self):
        for raw in ("../skills/project-status", "/etc", "ch13/../../skills/project-status"):
            with self.subTest(path=raw):
                with self.assertRaises((WorkspaceBoundaryError, FileNotFoundError)):
                    run_version_cases(raw, CASES)

    def test_cli_rejects_path_outside_workspace(self):
        for raw in ("skills/project-status", "workspace/../skills/project-status"):
            with self.subTest(path=raw):
                result = run_cli("eval", raw, *CLI_CASES)
                self.assertEqual(result.returncode, 2)
                self.assertEqual(result.stdout, b"")
                self.assertNotIn(b"Traceback", result.stderr)

    def test_commands_change_no_files(self):
        before = snapshot_files(WORKSPACE_ROOT, PROJECT_ROOT / "skills")
        for args in (("proposal", "workspace/" + PROPOSAL),
                     ("diff", "workspace/" + V1, "workspace/" + CANDIDATE),
                     ("compare", "workspace/" + V1, "workspace/" + CANDIDATE, *CLI_CASES)):
            self.assertEqual(run_cli(*args).returncode, 0)
        self.assertEqual(snapshot_files(WORKSPACE_ROOT, PROJECT_ROOT / "skills"), before)

    def test_student_copies_in_drafts_are_compared_the_same_way(self):
        workspace = temp_workspace(self)
        for label, source in (("v1", V1), ("v2", GOOD)):
            shutil.copytree(workspace / source, workspace / "drafts" / "ch13" / label / "project-status")
        report = compare_version_results(
            run_version_cases("drafts/ch13/v1/project-status", CASES, workspace_root=workspace),
            run_version_cases("drafts/ch13/v2/project-status", CASES, workspace_root=workspace))
        self.assertEqual((report["before"], report["after"], report["decision"]), ("v1", "v2", "keep"))


class DataTests(unittest.TestCase):
    def test_prepared_versions_are_valid_skills_and_not_the_runtime(self):
        runtime = (PROJECT_ROOT / "skills" / "project-status" / "SKILL.md").read_bytes()
        for version in (V1, CANDIDATE, GOOD):
            with self.subTest(version=version):
                self.assertTrue(run_version_cases(version, CASES)["accepted"])
                self.assertNotEqual((WORKSPACE_ROOT / version / "SKILL.md").read_bytes(), runtime)

    def test_prepared_versions_carry_no_scripts(self):
        self.assertEqual([path for path in CH13.rglob("*") if path.suffix == ".py"], [])

    def test_case_set_is_a_text_rubric_not_a_model_eval(self):
        document = load_version_cases(CASES)
        self.assertEqual(document["kind"], "procedure_text_check")
        self.assertIn("не оценка живой модели", document["note"])


class NoSecondMechanismTests(unittest.TestCase):
    def test_versioning_only_reads_and_reuses_loaders(self):
        source = (PROJECT_ROOT / "school_agent" / "versioning.py").read_text(encoding="utf-8")
        self.assertIn("load_skill", source)
        self.assertIn("build_incident_report", source)
        for token in ("write_text", "write_bytes", "open(", "json.dump", "unlink", "rmtree",
                      "copytree", "os.replace", "subprocess", "socket", "urllib",
                      "_split_skill_file", "TraceRecorder(", "run_agent", "decide"):
            with self.subTest(token=token):
                self.assertNotIn(token, source)

    def test_demo_does_not_run_scripts_or_switch_versions(self):
        source = (PROJECT_ROOT / "change_demo.py").read_text(encoding="utf-8")
        for token in ("subprocess", "write_text", "write_bytes", "copytree", "os.replace",
                      "shutil", "socket", "urllib"):
            with self.subTest(token=token):
                self.assertNotIn(token, source)


class RegressionSnapshot(unittest.TestCase):
    def test_old_golden_untouched_and_six_new(self):
        # Эталоны следующих глав в слепок главы 13 не входят (как в тестах глав 11 и 12).
        names = sorted(path.name for path in GOLDEN.iterdir() if not RETROFIT_GOLDEN.match(path.name)
                       if not re.match(r"ch1[4-9]_", path.name))
        new = [name for name in names if name.startswith("ch13_")]
        old = [name for name in names if not name.startswith("ch13_")]
        self.assertEqual(len(new), 6)
        self.assertEqual(len(old), OLD_GOLDEN_COUNT)
        digest = hashlib.sha256()
        for name in old:
            digest.update(name.encode("utf-8"))
            digest.update(hashlib.sha256((GOLDEN / name).read_bytes()).digest())
        self.assertEqual(digest.hexdigest(), OLD_GOLDEN_DIGEST)


if __name__ == "__main__":
    unittest.main()
