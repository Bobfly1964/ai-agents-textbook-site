"""Контракт главы 12: Trace читается как последовательность событий, причина — из наблюдения."""

import copy
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

from school_agent.agent import run_agent
from school_agent.paths import PROJECT_ROOT, WORKSPACE_ROOT, WorkspaceBoundaryError
from school_agent.replay_model import ReplayModel
from school_agent.trace_analysis import (
    TraceFormatError,
    build_incident_report,
    find_failure_point,
    load_trace,
    summarize_trace,
)

GOLDEN = PROJECT_ROOT / "tests" / "golden"
# Golden блоков «Достраиваем „Дежурного“» (ретрофит глав 1–13, 0.17.0) в слепки прежних глав не входят.
RETROFIT_GOLDEN = re.compile(r"ch(0\d|1[0-3])_dezhurny_")
CASES = "ch12/cases/"
REPLAY = WORKSPACE_ROOT / "ch12" / "replay" / "trace_cases.json"
LESSON_TRACE = WORKSPACE_ROOT / "traces" / "ch12_lesson23.jsonl"
RECORD = ("record", "--scenario", "missing_file", "--out", "traces/ch12_lesson23.jsonl")
# Как сняты учебные traces: сценарий replay -> (сценарий Tools, max_retries).
FIXTURES = {"wrong_tool": ("success", 1), "invalid_arguments": ("success", 1),
            "tool_exception": ("missing_file", 0)}
# Слепок 72 эталонов глав 1–11: имя и SHA-256 каждого файла, по порядку имён.
OLD_GOLDEN_COUNT = 72
OLD_GOLDEN_DIGEST = "e336a876fa47f03f2aa4e2c46f27f28985f37daa4350efc495b9a47ffa2587d0"


def run_cli(*args):
    return subprocess.run([sys.executable, "trace_demo.py", *args], cwd=PROJECT_ROOT,
                          capture_output=True, env=dict(os.environ, PYTHONIOENCODING="utf-8"))


def case_events(name):
    return load_trace(CASES + name + ".jsonl")


class TraceDemoGoldenTests(unittest.TestCase):
    def tearDown(self):
        if LESSON_TRACE.exists():
            LESSON_TRACE.unlink()

    def check_output(self, golden, *args):
        result = run_cli(*args)
        self.assertEqual(result.returncode, 0)
        printed = result.stdout.decode("utf-8").replace("\r\n", "\n")
        self.assertEqual(printed, (GOLDEN / golden).read_text(encoding="utf-8"))
        self.assertEqual(result.stderr, b"")
        self.assertNotIn(str(PROJECT_ROOT), printed)
        return printed

    def test_record_show_and_second_record(self):
        self.check_output("ch12_trace_record_missing_file.txt", *RECORD)
        self.assertTrue(LESSON_TRACE.exists())
        before = LESSON_TRACE.read_bytes()
        printed = self.check_output("ch12_trace_show_missing_file.txt",
                                    "show", "traces/ch12_lesson23.jsonl")
        # Карта событий, а не выгрузка payload: ни ответа модели, ни контекста.
        for token in ("arguments", "instruction", "tool_calls", "observations"):
            with self.subTest(token=token):
                self.assertNotIn(token, printed)
        self.check_output("ch12_trace_existing_path.txt", *RECORD)
        self.assertEqual(LESSON_TRACE.read_bytes(), before)

    def test_analyze_three_traces(self):
        for name in FIXTURES:
            with self.subTest(case=name):
                self.check_output("ch12_analyze_" + name + ".txt",
                                  "analyze", "workspace/" + CASES + name + ".jsonl")


class SameTerminalDifferentCauseTests(unittest.TestCase):
    def test_one_terminal_three_failure_points(self):
        reports = {name: build_incident_report(case_events(name)) for name in FIXTURES}
        self.assertEqual({report["terminal"] for report in reports.values()}, {"error"})
        self.assertEqual(reports["wrong_tool"]["root_cause"], "unknown_tool")
        self.assertEqual(reports["invalid_arguments"]["root_cause"], "invalid_arguments")
        self.assertEqual(reports["tool_exception"]["root_cause"], "cards_unavailable")
        places = {name: report["failure_point"]["type"] for name, report in reports.items()}
        self.assertEqual(places, {"wrong_tool": "tool_requested",
                                  "invalid_arguments": "tool_observation",
                                  "tool_exception": "tool_observation"})

    def test_evidence_points_at_the_observation_event(self):
        for name in FIXTURES:
            with self.subTest(case=name):
                events = case_events(name)
                report = build_incident_report(events)
                evidence = events[report["evidence_event_id"] - 1]
                self.assertEqual(evidence["type"], "tool_observation")
                observation = evidence["payload"]["observation"]
                self.assertFalse(observation["ok"])
                self.assertEqual(observation["error"]["code"], report["root_cause"])

    def test_unknown_tool_is_rejected_before_execution(self):
        report = build_incident_report(case_events("wrong_tool"))
        evidence = case_events("wrong_tool")[report["evidence_event_id"] - 1]
        self.assertFalse(evidence["payload"]["observation"]["executed"])

    def test_cards_unavailable_happens_after_execution(self):
        report = build_incident_report(case_events("tool_exception"))
        evidence = case_events("tool_exception")[report["evidence_event_id"] - 1]
        self.assertTrue(evidence["payload"]["observation"]["executed"])

    def test_successful_run_has_no_failure_point(self):
        events = case_events("wrong_tool")
        clean = [event for event in events if event["type"] != "tool_observation"]
        clean = [event for event in clean if event["type"] != "tool_requested"]
        self.assertIsNone(find_failure_point(clean))


class SummaryTests(unittest.TestCase):
    def test_counts_come_from_the_events(self):
        summary = summarize_trace(case_events("tool_exception"))
        self.assertEqual(summary["tool_calls"], 1)
        self.assertEqual(summary["errors"], 1)
        self.assertEqual(summary["approval_events"], 0)
        self.assertEqual(summary["events"], 6)
        self.assertEqual(summary["terminal"], "error")

    def test_approval_events_are_recognised_by_type(self):
        events = case_events("wrong_tool")
        approval = copy.deepcopy(events[-1])
        approval["type"] = "approval_requested"
        events.insert(-1, approval)
        self.assertEqual(summarize_trace(events)["approval_events"], 1)


class BrokenTraceTests(unittest.TestCase):
    def broken(self, lines):
        directory = tempfile.mkdtemp()
        self.addCleanup(shutil.rmtree, directory)
        workspace = Path(directory) / "workspace"
        (workspace / "traces").mkdir(parents=True)
        (workspace / "traces" / "broken.jsonl").write_text("\n".join(lines) + "\n", encoding="utf-8")
        return workspace

    def lines(self, name="wrong_tool"):
        path = WORKSPACE_ROOT / "ch12" / "cases" / (name + ".jsonl")
        return path.read_text(encoding="utf-8").splitlines()

    def load(self, lines):
        return load_trace("traces/broken.jsonl", workspace_root=self.broken(lines))

    def test_damaged_line_is_not_skipped(self):
        lines = self.lines()
        lines[2] = "{oops"
        with self.assertRaises(TraceFormatError):
            self.load(lines)

    def test_event_without_required_fields_is_rejected(self):
        lines = self.lines()
        event = json.loads(lines[1])
        del event["initiator"]
        lines[1] = json.dumps(event, ensure_ascii=False)
        with self.assertRaises(TraceFormatError):
            self.load(lines)

    def test_observation_without_request_is_rejected(self):
        lines = [line for line in self.lines() if '"tool_requested"' not in line]
        with self.assertRaises(TraceFormatError):
            self.load(lines)

    def test_missing_run_finished_is_rejected(self):
        with self.assertRaises(TraceFormatError):
            self.load(self.lines()[:-1])

    def test_cli_prints_refusal_without_partial_report(self):
        lines = self.lines()
        lines[2] = "{oops"
        broken = WORKSPACE_ROOT / "traces" / "ch12_broken.jsonl"
        broken.write_text("\n".join(lines) + "\n", encoding="utf-8")
        self.addCleanup(broken.unlink)
        result = run_cli("analyze", "traces/ch12_broken.jsonl")
        printed = result.stdout.decode("utf-8")
        self.assertEqual(result.returncode, 0)
        self.assertIn("result: not analyzable", printed)
        self.assertNotIn("root_cause", printed)
        self.assertNotIn(b"Traceback", result.stderr)


class BoundaryTests(unittest.TestCase):
    def test_analysis_reads_only_inside_workspace(self):
        for raw in ("../README.md", "/etc/passwd", "traces/../../README.md"):
            with self.subTest(path=raw):
                with self.assertRaises((WorkspaceBoundaryError, FileNotFoundError)):
                    load_trace(raw)

    def test_cli_rejects_path_outside_workspace(self):
        for raw in ("../README.md", "workspace/../README.md", "traces/../../README.md"):
            with self.subTest(path=raw):
                result = run_cli("analyze", raw)
                self.assertEqual(result.returncode, 2)
                self.assertEqual(result.stdout, b"")
                self.assertNotIn(b"Traceback", result.stderr)

    def test_record_writes_only_inside_traces(self):
        for out in ("drafts/x.jsonl", "traces/../tasks/x.jsonl", "../x.jsonl"):
            with self.subTest(out=out):
                result = run_cli("record", "--scenario", "missing_file", "--out", out)
                self.assertEqual(result.returncode, 2)
                self.assertEqual(result.stdout, b"")
        self.assertFalse((WORKSPACE_ROOT / "tasks" / "x.jsonl").exists())
        self.assertFalse((WORKSPACE_ROOT / "drafts" / "x.jsonl").exists())

    def test_analysis_does_not_change_the_fixture(self):
        digests = {}
        for name in FIXTURES:
            path = WORKSPACE_ROOT / "ch12" / "cases" / (name + ".jsonl")
            digests[name] = hashlib.sha256(path.read_bytes()).hexdigest()
            build_incident_report(case_events(name))
        for name, digest in digests.items():
            path = WORKSPACE_ROOT / "ch12" / "cases" / (name + ".jsonl")
            self.assertEqual(hashlib.sha256(path.read_bytes()).hexdigest(), digest)


class FixtureProvenanceTests(unittest.TestCase):
    """Учебные traces сняты фактическим TraceRecorder, а не написаны руками."""

    def recorded(self, name):
        tools_scenario, max_retries = FIXTURES[name]
        directory = tempfile.mkdtemp()
        self.addCleanup(shutil.rmtree, directory)
        workspace = Path(directory) / "workspace"
        shutil.copytree(WORKSPACE_ROOT, workspace)
        shutil.rmtree(workspace / "traces", ignore_errors=True)
        relative = "traces/" + name + ".jsonl"
        run_agent(ReplayModel(REPLAY, name), workspace_root=workspace, scenario=tools_scenario,
                  max_retries=max_retries, trace_relative_path=relative)
        return [json.loads(line) for line
                in (workspace / relative).read_text(encoding="utf-8").splitlines()]

    def test_fixtures_repeat_the_recorder_format(self):
        for name in FIXTURES:
            with self.subTest(case=name):
                fresh = self.recorded(name)
                stored = case_events(name)
                self.assertEqual([event["type"] for event in fresh],
                                 [event["type"] for event in stored])
                self.assertEqual([event["initiator"] for event in fresh],
                                 [event["initiator"] for event in stored])
                self.assertEqual([event["payload"] for event in fresh],
                                 [event["payload"] for event in stored])

    def test_replay_file_is_an_author_script(self):
        document = json.loads(REPLAY.read_text(encoding="utf-8"))
        self.assertEqual(document["provenance"]["kind"], "synthetic_script")
        self.assertFalse(document["provenance"]["verified_real_model_output"])


class NoSecondLoopTests(unittest.TestCase):
    def test_demo_reuses_existing_run_agent_and_recorder(self):
        source = (PROJECT_ROOT / "trace_demo.py").read_text(encoding="utf-8")
        self.assertIn("run_replay_scenario", source)
        for token in ("TraceRecorder(", "while ", "decide", "call_tool", "socket", "urllib"):
            with self.subTest(token=token):
                self.assertNotIn(token, source)

    def test_analysis_module_only_reads(self):
        source = (PROJECT_ROOT / "school_agent" / "trace_analysis.py").read_text(encoding="utf-8")
        for token in ("write_text", "write_bytes", "open(", "json.dump", "socket", "urllib"):
            with self.subTest(token=token):
                self.assertNotIn(token, source)


class RegressionSnapshot(unittest.TestCase):
    def test_old_golden_untouched_and_six_new(self):
        # Эталоны следующих глав в слепок главы 12 не входят (как в тесте главы 11).
        names = sorted(path.name for path in GOLDEN.iterdir() if not RETROFIT_GOLDEN.match(path.name)
                       if not re.match(r"ch1[3-9]_", path.name))
        new = [name for name in names if name.startswith("ch12_")]
        old = [name for name in names if not name.startswith("ch12_")]
        self.assertEqual(len(new), 6)
        self.assertEqual(len(old), OLD_GOLDEN_COUNT)
        digest = hashlib.sha256()
        for name in old:
            digest.update(name.encode("utf-8"))
            digest.update(hashlib.sha256((GOLDEN / name).read_bytes()).digest())
        self.assertEqual(digest.hexdigest(), OLD_GOLDEN_DIGEST)


if __name__ == "__main__":
    unittest.main()
