"""Контракт главы 14: политика — один источник правил, approval — решение о конкретном предложении."""

import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

import dezhurny
import permissions_demo
from school_agent.agent import run_agent, run_replay_scenario
from school_agent.approval import apply_status_update
from school_agent.dispatcher import AVAILABLE_TOOLS
from school_agent.my_agent_config import HarnessProfile
from school_agent.paths import PROJECT_ROOT, WORKSPACE_ROOT
from school_agent.permissions import PermissionsError, approval_allowed, validate_permissions_config
from school_agent.tools import Tools

GOLDEN = PROJECT_ROOT / "tests" / "golden"
# Golden блоков «Достраиваем „Дежурного“» (ретрофит глав 1–13, 0.17.0) в слепки прежних глав не входят.
RETROFIT_GOLDEN = re.compile(r"ch(0\d|1[0-3])_dezhurny_")
FIXTURE = PROJECT_ROOT / "tests" / "fixtures" / "ch14" / "14_permissions.json"
MY_AGENT = WORKSPACE_ROOT / "my_agent"
VALID = {"default": "deny", "task_cards": "read_only", "status_update": "approval_required"}
# Слепок 84 эталонов глав 1–13 — тот же, что в test_dezhurny.py.
OLD_GOLDEN_COUNT = 84
OLD_GOLDEN_DIGEST = "8b9f03584a1e6057c76123a861ad5e380cb608e88e6433bb1c16b2b7d21601b5"


def run_cli(script, *args):
    return subprocess.run([sys.executable, script, *args], cwd=PROJECT_ROOT,
                          capture_output=True, env=dict(os.environ, PYTHONIOENCODING="utf-8"))


def temp_workspace(test):
    directory = tempfile.mkdtemp()
    test.addCleanup(shutil.rmtree, directory)
    workspace = Path(directory) / "workspace"
    shutil.copytree(WORKSPACE_ROOT, workspace)
    return workspace


def tasks_digest(workspace=WORKSPACE_ROOT):
    return {path.name: hashlib.sha256(path.read_bytes()).hexdigest()
            for path in sorted((workspace / "tasks").glob("*.json"))}


class WithFixture:
    """Фикстура ученика кладётся в поставляемую папку только на время одной команды."""

    def __init__(self):
        self.target = MY_AGENT / "14_permissions.json"

    def __enter__(self):
        assert not self.target.exists(), "в поставке my_agent/ не должно быть 14_permissions.json"
        shutil.copyfile(FIXTURE, self.target)

    def __exit__(self, *exc):
        self.target.unlink()


class GoldenTests(unittest.TestCase):
    RUNS = {
        "ch14_permissions_policy.txt": (True, "permissions_demo.py", "policy", "--dir", "workspace/my_agent"),
        "ch14_permissions_too_broad.txt": (False, "permissions_demo.py", "policy", "--dir",
                                           "workspace/ch14/cases/too-broad"),
        "ch14_dezhurny_status.txt": (True, "dezhurny.py", "status", "--chapter", "14"),
        "ch14_dezhurny_status_update.txt": (True, "dezhurny.py", "run", "--scenario", "status_update"),
        "ch14_approval_approved.txt": (True, "permissions_demo.py", "approval", "--decision", "approve"),
        "ch14_approval_denied.txt": (True, "permissions_demo.py", "approval", "--decision", "deny"),
        "ch14_approval_policy_deny.txt": (False, "permissions_demo.py", "approval", "--dir",
                                          "workspace/ch14/cases/status-deny", "--decision", "approve"),
        "ch14_approval_card_changed.txt": (True, "permissions_demo.py", "approval", "--decision", "approve",
                                           "--case", "card-changed"),
    }

    def test_eight_outputs_and_shipped_cards_untouched(self):
        before = tasks_digest()
        for golden, (fixture, script, *args) in self.RUNS.items():
            with self.subTest(golden=golden):
                if fixture:
                    with WithFixture():
                        result = run_cli(script, *args)
                else:
                    result = run_cli(script, *args)
                self.assertEqual(result.returncode, 0, result.stderr.decode("utf-8"))
                self.assertEqual(result.stderr, b"")
                printed = result.stdout.decode("utf-8").replace("\r\n", "\n")
                self.assertEqual(printed, (GOLDEN / golden).read_text(encoding="utf-8"))
                self.assertNotIn(str(PROJECT_ROOT), printed)
                self.assertNotIn(tempfile.gettempdir(), printed)
        self.assertEqual(tasks_digest(), before)
        self.assertEqual({entry.name for entry in MY_AGENT.iterdir()}, {"README.md", "templates", "examples"})

    def test_run_and_approval_name_the_same_operation(self):
        ids = [re.search(r"operation_id: ([0-9a-f]{16})", (GOLDEN / name).read_text(encoding="utf-8")).group(1)
               for name in ("ch14_dezhurny_status_update.txt", "ch14_approval_approved.txt",
                            "ch14_approval_denied.txt", "ch14_approval_card_changed.txt")]
        self.assertEqual(len(set(ids)), 1)


class PolicyValidatorTests(unittest.TestCase):
    def test_exact_policy_is_accepted(self):
        self.assertEqual(validate_permissions_config(dict(VALID)), VALID)
        self.assertEqual(validate_permissions_config(dict(VALID, status_update="deny"))["status_update"], "deny")

    def test_everything_else_is_rejected_with_a_reason(self):
        cases = {
            "default должен быть deny": dict(VALID, default="allow"),
            "task_cards должен быть read_only": dict(VALID, task_cards="read_write"),
            "неизвестное поле network": dict(VALID, network="deny"),
            "нет поля status_update": {"default": "deny", "task_cards": "read_only"},
            "ожидался JSON-объект": ["deny"],
        }
        for value in ("auto", "allow", "approved", True):
            cases["автоматическое применение изменения состояния запрещено " + str(value)] = \
                dict(VALID, status_update=value)
        for message, value in cases.items():
            with self.subTest(message=message):
                with self.assertRaises(PermissionsError) as refused:
                    validate_permissions_config(value)
                self.assertTrue(message.startswith(str(refused.exception)))

    def test_gate_decision(self):
        self.assertEqual(approval_allowed(None), (False, "политики нет: default deny"))
        self.assertEqual(approval_allowed(dict(VALID, status_update="deny")),
                         (False, "политика status_update = deny"))
        self.assertEqual(approval_allowed(VALID), (True, "approval_required"))

    def test_one_source_of_rules(self):
        for path in ("school_agent/my_agent_config.py", "permissions_demo.py", "dezhurny.py"):
            source = (PROJECT_ROOT / path).read_text(encoding="utf-8")
            with self.subTest(path=path):
                self.assertNotIn("должен быть deny", source)
                self.assertNotIn("def validate_permissions_config", source)

    def test_broken_or_broad_policy_stops_run_before_the_loop(self):
        for text in ("{не JSON", json.dumps(dict(VALID, default="allow"))):
            with self.subTest(text=text):
                workspace = temp_workspace(self)
                (workspace / "my_agent" / "14_permissions.json").write_text(text, encoding="utf-8")
                with mock.patch.object(dezhurny, "run_replay_scenario") as loop:
                    with self.assertRaises(ValueError):
                        dezhurny.cmd_run(workspace_root=workspace, scenario="status_update")
                    loop.assert_not_called()


class ProposalAndApprovalTests(unittest.TestCase):
    def proposal(self, workspace):
        return Tools(workspace_root=workspace).propose_status_update(
            "task-002", "done", permissions_demo.REASON)

    def test_proposal_never_writes(self):
        workspace = temp_workspace(self)
        before = tasks_digest(workspace)
        proposal = self.proposal(workspace)
        self.assertFalse(proposal["applied"])
        self.assertEqual(tasks_digest(workspace), before)

    def test_denied_approval_writes_nothing(self):
        workspace = temp_workspace(self)
        before = tasks_digest(workspace)
        result = apply_status_update(self.proposal(workspace), approved=False, workspace_root=workspace)
        self.assertFalse(result["applied"])
        self.assertEqual(tasks_digest(workspace), before)

    def test_approved_change_touches_only_status(self):
        workspace = temp_workspace(self)
        path = workspace / "tasks" / "task-002.json"
        before = json.loads(path.read_text(encoding="utf-8"))
        self.assertTrue(apply_status_update(self.proposal(workspace), approved=True,
                                            workspace_root=workspace)["applied"])
        after = json.loads(path.read_text(encoding="utf-8"))
        self.assertEqual(dict(after, status=before["status"]), before)
        self.assertEqual(after["status"], "done")

    def test_apply_is_not_a_model_tool(self):
        self.assertNotIn("apply_status_update", AVAILABLE_TOOLS)
        catalog = json.loads((PROJECT_ROOT / "data" / "tool_catalog.json").read_text(encoding="utf-8"))
        self.assertNotIn("apply_status_update", [tool["name"] for tool in catalog["tools"]])

    def test_policy_deny_never_calls_apply_with_approval(self):
        with mock.patch.object(permissions_demo, "apply_status_update") as apply:
            lines = permissions_demo.cmd_approval("ch14/cases/status-deny", decision="approve")
        apply.assert_not_called()
        self.assertIn("apply_status_update: not called | reason: политика status_update = deny", lines)
        self.assertIn("human_decision: не запрашивалось — approval gate закрыт политикой", lines)

    def test_no_policy_means_gate_closed(self):
        lines = permissions_demo.cmd_approval("my_agent", decision="approve")
        self.assertIn("apply_status_update: not called | reason: политики нет: default deny", lines)
        self.assertIn("observed_status: in_progress", lines)

    def test_card_changed_decision_does_not_apply(self):
        with WithFixture():
            lines = permissions_demo.cmd_approval("my_agent", decision="approve", case="card-changed")
        self.assertIn("apply_status_update: not applied | reason: карточка изменилась после создания предложения",
                      lines)
        self.assertIn("changed_fields: нет", lines)

    def test_approval_events_are_written_by_the_existing_recorder(self):
        recorded = []
        original = permissions_demo.TraceRecorder

        class Spy(original):
            def record(self, event_type, **kwargs):
                recorded.append((event_type, kwargs.get("initiator", "harness")))
                return super().record(event_type, **kwargs)

        with mock.patch.object(permissions_demo, "TraceRecorder", Spy), WithFixture():
            lines = permissions_demo.cmd_approval("my_agent", decision="deny")
        self.assertEqual(recorded, [("approval_requested", "harness"), ("approval_decision", "human")])
        self.assertIn("approval_events: 2", lines)


class ClosedGateAsksNobodyTests(unittest.TestCase):
    """Вердикт главы 14, C1: сначала политика; при закрытом gate человека не спрашивают."""

    def test_no_events_and_no_apply_when_gate_is_closed(self):
        for relative in ("ch14/cases/status-deny", "my_agent"):
            with self.subTest(policy=relative):
                with mock.patch.object(permissions_demo, "TraceRecorder") as recorder,                         mock.patch.object(permissions_demo, "apply_status_update") as apply:
                    lines = permissions_demo.cmd_approval(relative, decision="approve")
                recorder.assert_not_called()
                apply.assert_not_called()
                self.assertIn("approval_events: 0", lines)
                self.assertFalse(any(line == "human_decision: approve" for line in lines))


class RunScenarioTests(unittest.TestCase):
    def test_replay_status_update_is_an_author_script(self):
        document = json.loads((PROJECT_ROOT / "data" / "model_replay.json").read_text(encoding="utf-8"))
        self.assertEqual(document["provenance"]["kind"], "synthetic_script")
        self.assertFalse(document["provenance"]["verified_real_model_output"])
        calls = [call for row in document["scenarios"]["status_update"]
                 for call in row["response"].get("tool_calls", [])]
        self.assertEqual([call["name"] for call in calls], ["propose_status_update"])

    def test_run_stops_at_needs_input_and_never_applies(self):
        workspace = temp_workspace(self)
        shutil.copyfile(FIXTURE, workspace / "my_agent" / "14_permissions.json")
        before = tasks_digest(workspace)
        with mock.patch("school_agent.approval.apply_status_update") as apply:
            lines = dezhurny.cmd_run(workspace_root=workspace, scenario="status_update")
        apply.assert_not_called()
        self.assertIn("Остановка: needs_input", lines)
        self.assertIn("approval: required", lines)
        self.assertIn("applied: no", lines)
        self.assertEqual(tasks_digest(workspace), before)
        self.assertNotIn("apply_status_update", (PROJECT_ROOT / "dezhurny.py").read_text(encoding="utf-8"))

    def test_without_policy_the_gate_is_closed_in_run(self):
        workspace = temp_workspace(self)
        lines = dezhurny.cmd_run(workspace_root=workspace, scenario="status_update")
        self.assertIn("approval: gate closed — политики нет: default deny", lines)
        self.assertFalse(any(line.startswith("permissions:") for line in lines))

    def test_agent_demo_status_update_writes_nothing(self):
        before = tasks_digest()
        result = run_cli("agent_demo.py", "--scenario", "status_update")
        self.assertEqual(result.returncode, 0)
        self.assertEqual(tasks_digest(), before)


class ThreeGatesTests(unittest.TestCase):
    class Adapter:
        kind = "replay"

        def __init__(self, response):
            self.response = response

        def next(self, context):
            response, self.response = self.response, {"type": "text", "text": "Стоп."}
            return response

    def test_profile_rejects_the_whole_batch_before_the_dispatcher(self):
        batch = {"type": "tool_calls", "tool_calls": [
            {"id": "b1", "name": "read_task_cards", "arguments": {}},
            {"id": "b2", "name": "propose_status_update",
             "arguments": {"task_id": "task-002", "new_status": "done", "reason": "Проверка."}}]}
        profile = HarnessProfile(allowed_tools=["read_task_cards"])
        result = run_agent(self.Adapter(batch), profile=profile)
        self.assertEqual(result["executed_tools"], [])
        self.assertEqual(result["terminal"], "error")

    def test_dispatcher_still_checks_each_call_after_the_profile(self):
        call = {"type": "tool_calls", "tool_calls": [
            {"id": "c1", "name": "propose_status_update", "arguments": {"task_id": "task-002"}}]}
        profile = HarnessProfile(allowed_tools=["propose_status_update"])
        result = run_agent(self.Adapter(call), profile=profile)
        observations = [event["payload"]["observation"] for event in result["trace"]
                        if event["type"] == "tool_observation"]
        self.assertEqual(observations[0]["error"]["code"], "invalid_arguments")
        self.assertFalse(observations[0]["executed"])


class VerifierRestoresMyAgentTests(unittest.TestCase):
    VERIFY = PROJECT_ROOT.parent / "tools" / "verify_chapter.py"

    @unittest.skipUnless((PROJECT_ROOT.parent / "tools" / "verify_chapter.py").is_file(),
                         "верификатор книги есть только в репозитории учебника")
    def test_tree_is_restored_byte_for_byte(self):
        def tree():
            return {path.relative_to(MY_AGENT).as_posix(): hashlib.sha256(path.read_bytes()).hexdigest()
                    for path in MY_AGENT.rglob("*") if path.is_file()}

        before = tree()
        golden = (GOLDEN / "ch14_dezhurny_status.txt").read_text(encoding="utf-8")
        chapter = ("```sh\n# запуск из корня starter\n"
                   "# фикстура: tests/fixtures/ch14/14_permissions.json -> workspace/my_agent/14_permissions.json\n"
                   "python dezhurny.py status --chapter 14\n```\n\n```text\n" + golden + "```\n\n"
                   "```sh\n# запуск из корня starter\npython dezhurny.py status\n```\n")
        directory = tempfile.mkdtemp()
        self.addCleanup(shutil.rmtree, directory)
        md = Path(directory) / "chapter.md"
        md.write_text(chapter, encoding="utf-8")
        result = subprocess.run([sys.executable, str(self.VERIFY), str(md)], cwd=PROJECT_ROOT.parent,
                                capture_output=True, env=dict(os.environ, PYTHONIOENCODING="utf-8", PYTHONUTF8="1"))
        self.assertIn("ошибок 0", result.stdout.decode("utf-8"))
        self.assertEqual(tree(), before)


class RegressionSnapshot(unittest.TestCase):
    def test_old_golden_untouched_and_eight_new(self):
        names = sorted(path.name for path in GOLDEN.iterdir() if not RETROFIT_GOLDEN.match(path.name) if not re.match(r"ch1[5-9]_", path.name))
        new = [name for name in names if name.startswith("ch14_")]
        old = [name for name in names if not name.startswith("ch14_")]
        self.assertEqual(len(new), 8)
        self.assertEqual(len(old), OLD_GOLDEN_COUNT)
        digest = hashlib.sha256()
        for name in old:
            digest.update(name.encode("utf-8"))
            digest.update(hashlib.sha256((GOLDEN / name).read_bytes()).digest())
        self.assertEqual(digest.hexdigest(), OLD_GOLDEN_DIGEST)


if __name__ == "__main__":
    unittest.main()
