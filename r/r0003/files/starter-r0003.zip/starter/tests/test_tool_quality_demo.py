"""Контракт главы 8: паспорт tool, учебный выбор по description и три обязательных случая."""

import copy
import hashlib
import inspect
import json
import os
import re
import subprocess
import sys
import unittest

import tool_quality_demo
from school_agent import tool_quality
from school_agent import validation
from school_agent.dispatcher import AVAILABLE_TOOLS
from school_agent.paths import PROJECT_ROOT
from school_agent.tool_quality import (
    build_tool_passport,
    check_route_case,
    load_catalog,
    run_quality_suite,
    select_tool,
)
from tests.test_tool_call_demo import spy_on


GOLDEN = PROJECT_ROOT / "tests" / "golden"
# Golden блоков «Достраиваем „Дежурного“» (ретрофит глав 1–13, 0.17.0) в слепки прежних глав не входят.
RETROFIT_GOLDEN = re.compile(r"ch(0\d|1[0-3])_dezhurny_")
ALL_TOOLS = tuple(AVAILABLE_TOOLS)
NETWORK_TOKENS = ("socket", "urllib", "http.client", "requests", "httpx")
MARK_DESCRIPTION = "Работает с данными и помогает пользователю."
# Слепок 52 эталонов глав 1–7: имя и SHA-256 каждого файла, по порядку имён.
OLD_GOLDEN_COUNT = 52
OLD_GOLDEN_DIGEST = "63af95970ccb435794d05f6f6781fef013b59bcbdf181ff7c05d4ff14ba7eddd"


class ToolQualityGoldenTests(unittest.TestCase):
    def check_output(self, golden, *args):
        result = subprocess.run(
            [sys.executable, "tool_quality_demo.py", *args],
            cwd=PROJECT_ROOT,
            capture_output=True,
            env=dict(os.environ, PYTHONIOENCODING="utf-8"),
            check=True,
        )
        expected = (GOLDEN / golden).read_text(encoding="utf-8")
        printed = result.stdout.decode("utf-8").replace("\r\n", "\n")
        self.assertEqual(printed, expected)
        self.assertEqual(result.stderr, b"")
        return printed

    def test_passport_validate_task_card(self):
        printed = self.check_output("ch08_passport_validate_task_card.txt",
                                    "passport", "validate_task_card")
        self.assertIn("scope: ", printed)
        self.assertIn("when: проверки конкретной карточки", printed)
        self.assertIn("schema: task_id: string, minLength 1, обязательное", printed)
        self.assertIn("execution: not performed", printed)

    def test_route_positive(self):
        printed = self.check_output("ch08_route_should_validate_card.txt",
                                    "route", "--case", "should-validate-card")
        self.assertIn("selected: validate_task_card", printed)
        self.assertIn("result: ok", printed)
        self.assertIn("не модель", printed)

    def test_route_negative(self):
        printed = self.check_output("ch08_route_should_read_board.txt",
                                    "route", "--case", "should-read-board")
        self.assertIn("selected: read_task_cards", printed)
        self.assertIn("result: ok", printed)

    def test_suite(self):
        printed = self.check_output("ch08_suite.txt", "suite")
        self.assertIn("result: 3/3", printed)


class RouteTests(unittest.TestCase):
    def test_two_similar_requests_go_to_different_tools(self):
        catalog = load_catalog()
        positive = check_route_case("should-validate-card", catalog)
        negative = check_route_case("should-read-board", catalog)
        self.assertEqual(positive["selected"], "validate_task_card")
        self.assertEqual(negative["selected"], "read_task_cards")
        self.assertNotEqual(positive["selected"], negative["selected"])

    def test_unknown_case_is_rejected(self):
        with self.assertRaises(ValueError):
            check_route_case("delete-everything", load_catalog())
        result = subprocess.run(
            [sys.executable, "tool_quality_demo.py", "route", "--case", "delete-everything"],
            cwd=PROJECT_ROOT, capture_output=True,
            env=dict(os.environ, PYTHONIOENCODING="utf-8"),
        )
        self.assertEqual(result.returncode, 2)
        self.assertEqual(result.stdout, b"")

    def test_broad_description_changes_the_choice(self):
        """Описание Марка из сцены: выбор меняется только в учебном маршрутизаторе."""

        catalog = copy.deepcopy(load_catalog())
        catalog["validate_task_card"]["description"] = MARK_DESCRIPTION
        review = check_route_case("should-validate-card", catalog)
        self.assertNotEqual(review["selected"], "validate_task_card")
        self.assertFalse(review["ok"])
        self.assertTrue(check_route_case("should-validate-card", load_catalog())["ok"])

    def test_selection_reads_only_request_and_catalog(self):
        self.assertEqual(list(inspect.signature(select_tool).parameters), ["request", "catalog"])
        self.assertEqual(select_tool("", load_catalog())[0], None)

    def test_no_domain_tool_is_called(self):
        commands = [["passport", name] for name in ALL_TOOLS]
        commands += [["route", "--case", "should-validate-card"],
                     ["route", "--case", "should-read-board"], ["suite"]]
        for argv in commands:
            with self.subTest(argv=argv):
                with spy_on(*ALL_TOOLS) as calls:
                    tool_quality_demo.main(argv)
                self.assertEqual(calls, [])


class SuiteTests(unittest.TestCase):
    def test_suite_has_positive_negative_and_error(self):
        summary = run_quality_suite(load_catalog())
        self.assertEqual([item["kind"] for item in summary["results"]],
                         ["positive", "negative", "error"])
        self.assertEqual((summary["passed"], summary["total"]), (3, 3))

    def test_error_case_uses_the_existing_validator(self):
        error = run_quality_suite(load_catalog())["results"][2]
        self.assertEqual(error["observed"], "invalid")
        self.assertEqual(error["errors"],
                         validation.validate_tool_arguments("validate_task_card", {}))


class PassportSourceTests(unittest.TestCase):
    def test_passports_cover_exactly_the_allowlist(self):
        self.assertEqual(sorted(load_catalog()), sorted(AVAILABLE_TOOLS))

    def test_schema_has_a_single_source(self):
        raw = json.loads(tool_quality.PASSPORTS_PATH.read_text(encoding="utf-8"))
        for tool in raw["tools"]:
            with self.subTest(tool=tool["name"]):
                self.assertFalse({"schema", "input_schema", "arguments"} & set(tool))
        self.assertIs(tool_quality_demo.TOOL_SCHEMAS, validation.TOOL_SCHEMAS)
        self.assertEqual(list((PROJECT_ROOT / "workspace" / "ch08").rglob("*.schema.json")), [])

    def test_catalog_descriptions_match_passports(self):
        """Модель в bridge видит те же описания, что проверяет глава."""

        catalog = json.loads((PROJECT_ROOT / "data" / "tool_catalog.json").read_text(encoding="utf-8"))
        bridge = {tool["name"]: tool["description"] for tool in catalog["tools"]}
        passports = load_catalog()
        for name in AVAILABLE_TOOLS:
            with self.subTest(tool=name):
                self.assertEqual(bridge[name], passports[name]["description"])

    def test_every_description_has_when_and_when_not(self):
        catalog = load_catalog()
        for name in catalog:
            with self.subTest(tool=name):
                passport = build_tool_passport(name, catalog, validation.TOOL_SCHEMAS)
                self.assertTrue(passport["when"])
                self.assertTrue(passport["when_not"])

    def test_propose_keeps_proposal_boundary(self):
        passport = build_tool_passport("propose_status_update", load_catalog(),
                                       validation.TOOL_SCHEMAS)
        self.assertIn("не применяет", passport["description"])

    def test_unknown_name_has_no_passport(self):
        with self.assertRaises(ValueError):
            build_tool_passport("delete_everything", load_catalog(), validation.TOOL_SCHEMAS)

    def test_chapter_files_stay_local(self):
        for path in (PROJECT_ROOT / "tool_quality_demo.py",
                     PROJECT_ROOT / "school_agent" / "tool_quality.py"):
            source = path.read_text(encoding="utf-8")
            for token in NETWORK_TOKENS:
                with self.subTest(file=path.name, token=token):
                    self.assertNotIn(token, source)


class GoldenSnapshotTests(unittest.TestCase):
    def test_old_golden_untouched_and_four_new(self):
        names = sorted(path.name for path in GOLDEN.iterdir() if not RETROFIT_GOLDEN.match(path.name)
                       if not re.match(r"ch(09|1\d)_", path.name))
        new = [name for name in names if name.startswith("ch08_")]
        old = [name for name in names if not name.startswith("ch08_")]
        self.assertEqual(len(new), 4)
        self.assertEqual(len(old), OLD_GOLDEN_COUNT)
        digest = hashlib.sha256()
        for name in old:
            digest.update(name.encode("utf-8"))
            digest.update(hashlib.sha256((GOLDEN / name).read_bytes()).digest())
        self.assertEqual(digest.hexdigest(), OLD_GOLDEN_DIGEST)


if __name__ == "__main__":
    unittest.main()
