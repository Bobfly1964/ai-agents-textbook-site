"""Контракт главы 4: пять механизмов, локальная карта MCP и слои Agent Skill."""

import json
import os
import socket
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

import mechanisms_demo
from school_agent.mechanism_support import (
    CHOICE_KEYS,
    check_mechanism_choices,
    list_mcp_resources,
)
from school_agent.paths import PROJECT_ROOT, WorkspaceBoundaryError


GOLDEN = PROJECT_ROOT / "tests" / "golden"
FIXTURE_KEY = PROJECT_ROOT / "tests" / "fixtures" / "ch04" / "choices_correct.txt"
TEMPLATE = PROJECT_ROOT / "workspace" / "ch04" / "templates" / "choices.txt"
LOADER_FUNCTIONS = ("discover_skills", "load_skill", "read_skill_resource")


class MechanismsDemoTests(unittest.TestCase):
    def check_output(self, golden, *args):
        """Сверить полный stdout команды с эталоном.

        Дочернему процессу явно задаётся UTF-8: иначе на консоли cp1251
        сравнение эталона ломается по кодировке, а не по содержанию.
        """

        result = subprocess.run(
            [sys.executable, "mechanisms_demo.py", *args],
            cwd=PROJECT_ROOT,
            capture_output=True,
            env=dict(os.environ, PYTHONIOENCODING="utf-8"),
            check=True,
        )
        expected = (GOLDEN / golden).read_text(encoding="utf-8")
        self.assertEqual(result.stdout.decode("utf-8").replace("\r\n", "\n"), expected)
        self.assertEqual(result.stderr, b"")
        return expected

    def test_fragments_match_golden(self):
        printed = self.check_output("ch04_fragments.txt", "fragments")
        for letter in ("A", "B", "C", "D", "E"):
            self.assertIn("\n" + letter + "\n", "\n" + printed)
        for label in ("prompt", "structured output", "tool", "Agent Skill", "MCP"):
            self.assertNotIn(label, printed)

    def test_choices_correct_matches_golden(self):
        printed = self.check_output(
            "ch04_choices_correct.txt", "check", "tests/fixtures/ch04/choices_correct.txt"
        )
        self.assertIn("результат: 5/5", printed)

    def test_choices_all_prompt_matches_golden(self):
        printed = self.check_output(
            "ch04_choices_all_prompt.txt",
            "check",
            "workspace/ch04/cases/choices_all_prompt.txt",
        )
        self.assertIn("результат: 1/5", printed)

    def test_choices_missing_matches_golden(self):
        printed = self.check_output(
            "ch04_choices_missing.txt", "check", "workspace/ch04/cases/choices_missing.txt"
        )
        self.assertIn("результат: не принят", printed)
        self.assertNotIn("/5", printed)

    def test_choices_boundary_matches_golden(self):
        printed = self.check_output(
            "ch04_choices_boundary.txt",
            "check",
            "workspace/ch04/cases/choices_boundary.txt",
        )
        self.assertIn("результат: 4/4", printed)

    def test_choices_not_created_matches_golden(self):
        """Ученический файл ответов не поставляется; команда главы это печатает."""

        printed = self.check_output(
            "ch04_choices_not_created.txt", "check", "workspace/drafts/ch04_choices.txt"
        )
        self.assertIn("результат: не принят", printed)

    def test_mcp_map_matches_golden(self):
        printed = self.check_output("ch04_mcp_map.txt", "mcp")
        self.assertIn("network: not used", printed)
        self.assertIn("trust: not proven", printed)

    def test_skill_catalog_matches_golden(self):
        self.check_output("ch04_skill_catalog.txt", "skill", "--layer", "catalog")

    def test_skill_instructions_matches_golden(self):
        self.check_output("ch04_skill_instructions.txt", "skill", "--layer", "instructions")

    def test_skill_reference_matches_golden(self):
        self.check_output("ch04_skill_reference.txt", "skill", "--layer", "reference")


class McpMapTests(unittest.TestCase):
    def test_mcp_map_uses_no_network(self):
        """Локальная карта читается с диска; сетевой вызов запрещён."""

        def refuse(*args, **kwargs):
            raise AssertionError("локальная демонстрация MCP не обращается к сети")

        with mock.patch.object(socket, "socket", refuse), \
                mock.patch.object(socket, "create_connection", refuse):
            model = list_mcp_resources()
        self.assertEqual(model["network"], "not used")
        self.assertEqual(model["trust"], "not proven")
        self.assertEqual(model["resources"], ["tasks://open", "tasks://blocked"])

    def test_flags_are_not_read_from_card(self):
        """Поле внутри данных не назначает доверие (EC-05): флаги печатает программа."""

        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "mcp").mkdir()
            (root / "mcp" / "server.json").write_text(json.dumps({
                "kind": "mock_mcp_server_card",
                "host": "h", "client": "c", "server_name": "s",
                "resources": ["tasks://open"],
                "network": "used", "trust": "proven",
            }), encoding="utf-8")
            model = list_mcp_resources(root)
        self.assertEqual(model["network"], "not used")
        self.assertEqual(model["trust"], "not proven")


class ProgressiveDisclosureTests(unittest.TestCase):
    """Слой загружает себя и не подтягивает два остальных."""

    def run_layer(self, layer):
        called = []
        patches = {}
        for name in LOADER_FUNCTIONS:
            original = getattr(mechanisms_demo, name)

            def spy(*args, _name=name, _original=original, **kwargs):
                called.append(_name)
                return _original(*args, **kwargs)

            patches[name] = mock.patch.object(mechanisms_demo, name, spy)
        with patches["discover_skills"], patches["load_skill"], patches["read_skill_resource"]:
            with mock.patch("sys.stdout"):
                mechanisms_demo.main(["skill", "--layer", layer])
        return called

    def test_catalog_layer_loads_only_catalog(self):
        self.assertEqual(self.run_layer("catalog"), ["discover_skills"])

    def test_instructions_layer_does_not_read_reference(self):
        self.assertEqual(self.run_layer("instructions"), ["load_skill"])

    def test_reference_layer_does_not_rescan_catalog(self):
        self.assertEqual(self.run_layer("reference"), ["read_skill_resource"])

    def test_unknown_layer_is_rejected_without_reading_a_path(self):
        with mock.patch("sys.stderr"):
            with self.assertRaises(SystemExit) as raised:
                mechanisms_demo.main(["skill", "--layer", "../../README.md"])
        self.assertEqual(raised.exception.code, 2)

    def test_starter_has_no_second_skill_loader(self):
        """B7–B9 используют загрузчик главы 9; нового загрузчика нет."""

        definitions = []
        for path in sorted(PROJECT_ROOT.rglob("*.py")):
            if "__pycache__" in path.parts:
                continue
            text = path.read_text(encoding="utf-8")
            for name in LOADER_FUNCTIONS:
                if ("def " + name) in text:
                    definitions.append((path.name, name))
        self.assertEqual(
            sorted({name for _, name in definitions}), sorted(LOADER_FUNCTIONS)
        )
        self.assertEqual({file for file, _ in definitions}, {"skill_loader.py"})


class ChoicesBoundaryTests(unittest.TestCase):
    def test_path_outside_workspace_is_rejected(self):
        for path in ("workspace/../README.md", "README.md", "tests/test_paths.py"):
            with self.subTest(path=path):
                with self.assertRaises(WorkspaceBoundaryError):
                    check_mechanism_choices(path)

    def test_absolute_path_is_rejected(self):
        with self.assertRaises(WorkspaceBoundaryError):
            check_mechanism_choices(str(FIXTURE_KEY))

    def test_answer_key_is_not_in_student_workspace(self):
        """Эталонный ключ лежит в фикстурах курса, а не в рабочей папке ученика."""

        self.assertTrue(FIXTURE_KEY.is_file())
        workspace = PROJECT_ROOT / "workspace"
        for path in workspace.rglob("*.txt"):
            body = path.read_text(encoding="utf-8")
            self.assertNotEqual(body, FIXTURE_KEY.read_text(encoding="utf-8"))

    def test_template_lists_five_unfilled_keys(self):
        lines = TEMPLATE.read_text(encoding="utf-8").strip().splitlines()
        self.assertEqual([line.split("=", 1)[0] for line in lines],
                         [key for key, _ in CHOICE_KEYS])
        self.assertTrue(all(line.endswith("=") for line in lines))

    def test_unfilled_template_is_not_a_partial_score(self):
        review = check_mechanism_choices("workspace/ch04/templates/choices.txt")
        self.assertEqual(review["status"], "incomplete")
        self.assertEqual(review["missing"], [key for key, _ in CHOICE_KEYS])


if __name__ == "__main__":
    unittest.main()
