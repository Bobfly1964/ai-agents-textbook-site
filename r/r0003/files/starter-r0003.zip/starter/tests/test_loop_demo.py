import copy
import unittest
from loop_demo import decide, run_loop

class LoopTests(unittest.TestCase):
    def test_same_step_success(self):
        result = run_loop("one_match")
        self.assertEqual((result["terminal"], result["state"]["steps"]), ("success", 1))
        self.assertEqual(result["events"][-1]["decision"], "success")

    def test_permanent_error_is_second_action(self):
        for scenario in ("permanent_error", "missing_file"):
            with self.subTest(scenario=scenario):
                result = run_loop(scenario)
                self.assertEqual((result["terminal"], result["state"]["steps"]), ("error", 2))
                self.assertEqual(result["state"]["failures"], 2)
                self.assertEqual([e["decision"] for e in result["events"]], ["continue", "error"])

    def test_temporary_error_has_one_retry(self):
        result = run_loop("temporary_error")
        self.assertEqual((result["terminal"], result["state"]["steps"], result["state"]["failures"]), ("success", 2, 1))

    def test_ambiguity_and_absence(self):
        for scenario in ("two_matches", "no_matches"):
            with self.subTest(scenario=scenario):
                self.assertEqual(run_loop(scenario)["terminal"], "needs_input")
        matches = run_loop("two_matches")["events"][0]["observation"]["matches"]
        self.assertEqual(matches, ["task-003", "task-003-copy"])

    def test_decide_does_not_depend_on_scenario_name(self):
        base = {
            "observation": {"ok": True, "matches": []},
            "steps": 1,
            "failures": 0,
            "max_steps": 5,
            "max_retries": 1,
        }
        decisions = set()
        for scenario in ("no_matches", "limit", "one_match"):
            state = copy.deepcopy(base)
            state["scenario"] = scenario
            decisions.add(decide(state))
        self.assertEqual(decisions, {"needs_input"})

    def test_limit_observation_honestly_allows_more_work(self):
        result = run_loop("limit")
        for event in result["events"][:-1]:
            self.assertFalse(event["observation"]["search_complete"])
            self.assertEqual(event["decision"], "continue")
        self.assertEqual(result["events"][-1]["decision"], "limit")

    def test_limit_not_fake_timeout(self):
        result = run_loop("limit")
        self.assertEqual((result["terminal"], result["state"]["steps"]), ("limit", 5))
        self.assertEqual(run_loop("limit", max_steps=2)["state"]["steps"], 2)
        with self.assertRaises(ValueError):
            run_loop("timeout_simulated")

    def test_no_retry(self):
        self.assertEqual(run_loop("permanent_error", max_retries=0)["state"]["steps"], 1)

    def test_invalid_limits(self):
        for value in (0, 6, True, "5"):
            with self.assertRaises(ValueError):
                run_loop(max_steps=value)
