"""Контракт главы 10: state отдельно от процедуры, checkpoint, продолжение и handoff без секретов."""

import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import unittest

import state_demo
from school_agent import state_store
from school_agent.paths import PROJECT_ROOT, WORKSPACE_ROOT
from school_agent.state_store import (
    HANDOFF_FIELDS,
    build_handoff,
    load_state,
    validate_project_state,
)

GOLDEN = PROJECT_ROOT / "tests" / "golden"
# Golden блоков «Достраиваем „Дежурного“» (ретрофит глав 1–13, 0.17.0) в слепки прежних глав не входят.
RETROFIT_GOLDEN = re.compile(r"ch(0\d|1[0-3])_dezhurny_")
CASES = "workspace/ch10/cases/"
DRAFT_DIR = WORKSPACE_ROOT / "drafts" / "ch10"
SECRET_VALUE = "FAKE-DEMO-VALUE-NOT-A-TOKEN"
# Слепок 64 эталонов глав 1–9: имя и SHA-256 каждого файла, по порядку имён.
OLD_GOLDEN_COUNT = 64
OLD_GOLDEN_DIGEST = "a2c8e2c94a868b0a48b10139ce8be6376cf6493b1b7687a56bdf8f1397ddc25f"


def run_cli(*args):
    return subprocess.run(
        [sys.executable, "state_demo.py", *args],
        cwd=PROJECT_ROOT,
        capture_output=True,
        env=dict(os.environ, PYTHONIOENCODING="utf-8"),
    )


def tasks_digest():
    digest = hashlib.sha256()
    for path in sorted((WORKSPACE_ROOT / "tasks").iterdir()):
        digest.update(path.name.encode("utf-8"))
        digest.update(path.read_bytes())
    return digest.hexdigest()


class StateDemoGoldenTests(unittest.TestCase):
    def tearDown(self):
        if DRAFT_DIR.exists():
            shutil.rmtree(DRAFT_DIR)

    def check_output(self, golden, *args):
        result = run_cli(*args)
        self.assertEqual(result.returncode, 0)
        expected = (GOLDEN / golden).read_text(encoding="utf-8")
        printed = result.stdout.decode("utf-8").replace("\r\n", "\n")
        self.assertEqual(printed, expected)
        self.assertEqual(result.stderr, b"")
        self.assertNotIn(SECRET_VALUE, printed)
        self.assertNotIn(str(PROJECT_ROOT), printed)
        return printed

    def test_classify(self):
        printed = self.check_output("ch10_classify.txt", "classify")
        self.assertIn("SKILL.md -> procedural knowledge", printed)
        self.assertIn("project_state.json -> state", printed)

    def test_resume_ready(self):
        printed = self.check_output("ch10_resume.txt", "resume", CASES + "project_state_ready.json")
        self.assertTrue(printed.endswith("result: resumable\n"))

    def test_resume_missing_next_step(self):
        printed = self.check_output("ch10_resume_missing.txt", "resume",
                                    CASES + "project_state_missing_next_step.json")
        self.assertIn("error: missing field next_step", printed)
        self.assertIn("result: not resumable", printed)

    def test_checkpoint_saves_only_into_drafts(self):
        before = tasks_digest()
        printed = self.check_output("ch10_checkpoint.txt", "checkpoint",
                                    CASES + "project_state_ready.json",
                                    "--out", "drafts/ch10/project_state.json")
        self.assertIn("project cards changed: no", printed)
        self.assertEqual(tasks_digest(), before)
        saved = load_state("drafts/ch10/project_state.json")
        self.assertEqual(saved, load_state("ch10/cases/project_state_ready.json"))

    def test_handoff_ready(self):
        printed = self.check_output("ch10_handoff.txt", "handoff", CASES + "project_state_ready.json")
        self.assertIn("full transcript included: no", printed)
        self.assertIn("secret fields included: 0", printed)

    def test_handoff_secret(self):
        printed = self.check_output("ch10_handoff_secret.txt", "handoff",
                                    CASES + "project_state_with_secret.json")
        self.assertIn("error: forbidden secret field", printed)
        self.assertIn("result: not accepted", printed)


class HandoffContractTests(unittest.TestCase):
    def ready(self):
        return load_state("ch10/cases/project_state_ready.json")

    def test_handoff_drops_transcript_and_extra_fields(self):
        state = dict(self.ready(), chat_transcript=["Привет", "Как дела?"], scratch="черновик")
        handoff = build_handoff(state)
        self.assertEqual(set(handoff) - set(HANDOFF_FIELDS), set())
        self.assertNotIn("chat_transcript", handoff)
        self.assertEqual(handoff["next_step"], state["next_step"])

    def test_secret_anywhere_blocks_handoff(self):
        for state in (dict(self.ready(), api_key="x"),
                      dict(self.ready(), meta={"access_token": "x"}),
                      dict(self.ready(), history=[{"password": "x"}])):
            with self.subTest(state=list(state)[-1]):
                self.assertEqual(validate_project_state(state), ["forbidden secret field"])
                with self.assertRaises(ValueError):
                    build_handoff(state)

    def test_missing_next_step_is_not_partially_resumable(self):
        state = self.ready()
        del state["next_step"]
        self.assertIn("missing field next_step", validate_project_state(state))
        with self.assertRaises(ValueError):
            build_handoff(state)

    def test_template_is_a_valid_resumable_state(self):
        template = load_state("ch10/templates/project_state.json")
        self.assertEqual(validate_project_state(template), [])
        self.assertEqual(template, self.ready())

    def test_secret_detection_reuses_trace_list(self):
        source = (PROJECT_ROOT / "school_agent" / "state_store.py").read_text(encoding="utf-8")
        self.assertIn("from .trace import SENSITIVE_PARTS", source)
        self.assertNotRegex(source, r"SENSITIVE_PARTS\s*=")


class BoundaryTests(unittest.TestCase):
    def tearDown(self):
        if DRAFT_DIR.exists():
            shutil.rmtree(DRAFT_DIR)

    def test_input_path_stays_inside_workspace(self):
        for raw in ("/etc/passwd", "../README.md", "workspace/../README.md", "skills/project-status/SKILL.md"):
            with self.subTest(path=raw):
                result = run_cli("resume", raw)
                self.assertEqual(result.returncode, 2)
                self.assertEqual(result.stdout, b"")
                self.assertNotIn(b"Traceback", result.stderr)

    def test_checkpoint_writes_only_into_drafts(self):
        before = tasks_digest()
        for out in ("drafts/../tasks/x.json", "tasks/x.json", "drafts", "../x.json", "/tmp/x.json"):
            with self.subTest(out=out):
                result = run_cli("checkpoint", CASES + "project_state_ready.json", "--out", out)
                self.assertEqual(result.returncode, 2)
                self.assertEqual(result.stdout, b"")
        self.assertEqual(tasks_digest(), before)
        self.assertFalse((WORKSPACE_ROOT / "tasks" / "x.json").exists())

    def test_invalid_state_is_not_saved(self):
        result = run_cli("checkpoint", CASES + "project_state_with_secret.json",
                         "--out", "drafts/ch10/project_state.json")
        self.assertIn(b"checkpoint: not saved", result.stdout)
        self.assertFalse(DRAFT_DIR.exists())


class SingleStoreTests(unittest.TestCase):
    def test_demo_uses_existing_store(self):
        self.assertIs(state_demo.load_state, state_store.load_state)
        self.assertIs(state_demo.save_state, state_store.save_state)
        source = (PROJECT_ROOT / "state_demo.py").read_text(encoding="utf-8")
        for token in ("json.dump", "open(", "write_text", "write_bytes", "tempfile", "os.replace"):
            with self.subTest(token=token):
                self.assertNotIn(token, source)

    def test_no_network_and_no_second_store_module(self):
        for token in ("socket", "urllib", "http.client", "requests", "httpx"):
            with self.subTest(token=token):
                self.assertNotIn(token, (PROJECT_ROOT / "state_demo.py").read_text(encoding="utf-8"))
        modules = {path.name for path in (PROJECT_ROOT / "school_agent").glob("*.py")}
        self.assertEqual({name for name in modules if "state" in name}, {"state_store.py"})

    def test_skill_file_holds_no_run_state(self):
        skill = (PROJECT_ROOT / "skills" / "project-status" / "SKILL.md").read_text(encoding="utf-8")
        for token in ("next_step", "pending_question", "blocked_tasks"):
            with self.subTest(token=token):
                self.assertNotIn(token, skill)


class RegressionSnapshot(unittest.TestCase):
    def test_old_golden_untouched_and_six_new(self):
        names = sorted(path.name for path in GOLDEN.iterdir() if not RETROFIT_GOLDEN.match(path.name)
                       if not re.match(r"ch1[1-9]_", path.name))
        new = [name for name in names if name.startswith("ch10_")]
        old = [name for name in names if not name.startswith("ch10_")]
        self.assertEqual(len(new), 6)
        self.assertEqual(len(old), OLD_GOLDEN_COUNT)
        digest = hashlib.sha256()
        for name in old:
            digest.update(name.encode("utf-8"))
            digest.update(hashlib.sha256((GOLDEN / name).read_bytes()).digest())
        self.assertEqual(digest.hexdigest(), OLD_GOLDEN_DIGEST)


if __name__ == "__main__":
    unittest.main()
