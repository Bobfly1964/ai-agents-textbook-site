"""Контракт главы 6: tool call, JSON Schema arguments и карточки, пять режимов CLI."""

import hashlib
import inspect
import os
import re
import shutil
import subprocess
import sys
import unittest
from contextlib import contextmanager
from unittest import mock

import tool_call_demo
from school_agent import dispatcher
from school_agent import validation
from school_agent.paths import PROJECT_ROOT
from school_agent.replay_model import ReplayModel
from school_agent.tools import Tools
from school_agent.validation import CARD_SCHEMA, TOOL_SCHEMAS


GOLDEN = PROJECT_ROOT / "tests" / "golden"
# Golden блоков «Достраиваем „Дежурного“» (ретрофит глав 1–13, 0.17.0) в слепки прежних глав не входят.
RETROFIT_GOLDEN = re.compile(r"ch(0\d|1[0-3])_dezhurny_")
FIXTURE = PROJECT_ROOT / "tests" / "fixtures" / "ch06" / "tool_call_valid.json"
DRAFT = PROJECT_ROOT / "workspace" / "drafts" / "ch06_tool_call.json"
DRAFT_ARG = "workspace/drafts/ch06_tool_call.json"

STATUSES = ["planned", "in_progress", "blocked", "done"]
# Сетевых клиентов в главе нет: демонстрация читает только локальные файлы.
NETWORK_TOKENS = (
    "socket",
    "urllib",
    "http.client",
    "requests",
    "httpx",
)
# Слепок двух golden принятых глав: папка эталонов расширяется, но не правится.
OLD_GOLDEN_SHA = {
    "chat_normal.txt": "f35e3052c83aa43ead7d4bf2b2ba6e4b7858578e2ff3c8de502b0fae706be522",
    "ch04_mcp_map.txt": "534554e387ae6bdc9f1e3aede4d071fb2f7566c59c80898aa7cdf539b0e696d0",
}


@contextmanager
def spy_on(*names):
    """Считать вызовы методов Tools, не подменяя их поведение.

    Таблица ``dispatcher.AVAILABLE_TOOLS`` держит прямые ссылки на функции,
    поэтому подменяется и она: иначе счётчик не увидел бы вызов из ``call_tool``.
    """

    calls = []
    spies = {}
    for name in names:
        original = getattr(Tools, name)

        def spy(self, *args, _name=name, _original=original, **kwargs):
            calls.append((_name, args, kwargs))
            return _original(self, *args, **kwargs)

        spies[name] = spy
    patches = [mock.patch.object(Tools, name, spies[name]) for name in names]
    patches.append(mock.patch.dict(dispatcher.AVAILABLE_TOOLS, spies))
    for patch in patches:
        patch.start()
    try:
        with mock.patch("sys.stdout"):
            yield calls
    finally:
        for patch in patches:
            patch.stop()


class ToolCallDemoGoldenTests(unittest.TestCase):
    def check_output(self, golden, *args):
        """Сверить полный stdout команды с эталоном.

        Дочернему процессу явно задаётся UTF-8: иначе на консоли cp1251
        сравнение эталона ломается по кодировке, а не по содержанию.
        """

        result = subprocess.run(
            [sys.executable, "tool_call_demo.py", *args],
            cwd=PROJECT_ROOT,
            capture_output=True,
            env=dict(os.environ, PYTHONIOENCODING="utf-8"),
            check=True,
        )
        expected = (GOLDEN / golden).read_text(encoding="utf-8")
        self.assertEqual(result.stdout.decode("utf-8").replace("\r\n", "\n"), expected)
        self.assertEqual(result.stderr, b"")
        return expected

    def test_show_matches_golden(self):
        printed = self.check_output("ch06_show.txt", "show")
        self.assertIn("origin: synthetic_script — авторский сценарий, не запись модели",
                      printed)
        self.assertIn("execution: not performed", printed)
        self.assertNotIn("tool result", printed)

    def test_execute_matches_golden(self):
        printed = self.check_output("ch06_execute.txt", "execute")
        self.assertIn("execution: performed by application", printed)
        self.assertIn('"count": 3', printed)
        self.assertNotIn("untrusted_content", printed)

    def test_call_not_created_matches_golden(self):
        """Ученический файл tool call starter не поставляет; команда это печатает."""

        self.assertFalse(DRAFT.exists())
        printed = self.check_output("ch06_call_not_created.txt", "check", DRAFT_ARG)
        self.assertIn("ошибка: файл не создан: " + DRAFT_ARG, printed)

    def test_call_valid_matches_golden(self):
        shutil.copyfile(FIXTURE, DRAFT)
        try:
            printed = self.check_output("ch06_call_valid.txt", "check", DRAFT_ARG)
        finally:
            if DRAFT.exists():
                DRAFT.unlink()
        self.assertIn("JSON Schema: valid", printed)
        self.assertIn("execution: not performed", printed)
        self.assertFalse(DRAFT.exists())

    def test_call_missing_task_id_matches_golden(self):
        printed = self.check_output(
            "ch06_call_missing_task_id.txt",
            "check",
            "workspace/ch06/cases/validate_missing_task_id.json",
        )
        self.assertIn("reason: arguments: нет обязательного поля task_id", printed)

    def test_call_path_rejected_matches_golden(self):
        printed = self.check_output(
            "ch06_call_path_rejected.txt",
            "check",
            "workspace/ch06/cases/read_with_path.json",
        )
        self.assertIn("reason: arguments: лишнее поле path", printed)

    def test_card_valid_matches_golden(self):
        printed = self.check_output(
            "ch06_card_valid.txt", "check-card", "workspace/ch06/cards/card_valid.json"
        )
        self.assertIn("JSON Schema: valid", printed)

    def test_card_missing_status_matches_golden(self):
        printed = self.check_output(
            "ch06_card_missing_status.txt",
            "check-card",
            "workspace/ch06/cards/card_missing_status.json",
        )
        self.assertIn("reason: card: нет обязательного поля status", printed)

    def test_card_bad_status_matches_golden(self):
        printed = self.check_output(
            "ch06_card_bad_status.txt",
            "check-card",
            "workspace/ch06/cards/card_bad_status.json",
        )
        self.assertIn("reason: card.status: значение не входит в enum", printed)

    def test_schema_read_task_cards_matches_golden(self):
        printed = self.check_output(
            "ch06_schema_read_task_cards.txt", "schema", "read_task_cards"
        )
        self.assertIn('"properties": {}', printed)

    def test_schema_validate_task_card_matches_golden(self):
        printed = self.check_output(
            "ch06_schema_validate_task_card.txt", "schema", "validate_task_card"
        )
        self.assertIn("task_id", printed)

    def test_schema_task_card_matches_golden(self):
        printed = self.check_output("ch06_schema_task_card.txt", "schema", "task_card")
        for status in STATUSES:
            self.assertIn(status, printed)


class ExecutionIsSeparateFromRequestTests(unittest.TestCase):
    """Показанный tool call и фактически выполненный вызов — разные события."""

    def test_show_does_not_call_the_tool(self):
        with spy_on("read_task_cards") as calls:
            tool_call_demo.main(["show"])
        self.assertEqual(calls, [])

    def test_execute_calls_the_tool_once_without_arguments(self):
        with spy_on("read_task_cards") as calls:
            tool_call_demo.main(["execute"])
        self.assertEqual(len(calls), 1)
        self.assertEqual(calls[0], ("read_task_cards", (), {}))

    def test_invalid_arguments_are_rejected_before_the_call(self):
        cases = [
            "workspace/ch06/cases/validate_missing_task_id.json",
            "workspace/ch06/cases/read_with_path.json",
        ]
        for case in cases:
            with self.subTest(case=case):
                with spy_on("read_task_cards", "validate_task_card") as calls:
                    tool_call_demo.main(["check", case])
                self.assertEqual(calls, [])


class SchemaMatchesSignatureTests(unittest.TestCase):
    """Schema arguments и сигнатура операции описывают один и тот же договор."""

    @staticmethod
    def parameters(method):
        return [name for name in inspect.signature(method).parameters if name != "self"]

    def test_validate_task_card_schema_matches_signature(self):
        schema = TOOL_SCHEMAS["validate_task_card"]
        self.assertEqual(schema["required"], ["task_id"])
        self.assertIn("task_id", schema["properties"])
        self.assertEqual(self.parameters(Tools.validate_task_card), ["task_id"])
        self.assertEqual(self.parameters(Tools.validate_task_card), schema["required"])

    def test_read_task_cards_schema_is_an_empty_object(self):
        schema = TOOL_SCHEMAS["read_task_cards"]
        self.assertEqual(schema["type"], "object")
        self.assertEqual(schema["properties"], {})
        self.assertEqual(schema["required"], [])
        self.assertIs(schema["additionalProperties"], False)
        self.assertEqual(self.parameters(Tools.read_task_cards), [])

    def test_task_card_schema_fixes_required_fields_and_statuses(self):
        self.assertEqual(CARD_SCHEMA["required"], ["id", "title", "status"])
        self.assertEqual(CARD_SCHEMA["properties"]["status"]["enum"], STATUSES)


class Chapter06StaysLocalTests(unittest.TestCase):
    def test_demo_and_validator_have_no_network_client(self):
        """Ни один режим главы 6 не обращается к сети."""

        sources = {
            "tool_call_demo.py": (PROJECT_ROOT / "tool_call_demo.py"),
            "school_agent/validation.py": (
                PROJECT_ROOT / "school_agent" / "validation.py"
            ),
        }
        for name, path in sources.items():
            source = path.read_text(encoding="utf-8")
            for token in NETWORK_TOKENS:
                with self.subTest(file=name, token=token):
                    self.assertNotIn(token, source)

    def test_golden_of_accepted_chapters_are_untouched(self):
        """Папка эталонов только пополнилась двенадцатью файлами главы 6."""

        # Эталоны следующих глав проверяет их собственный тест-слепок.
        names = sorted(path.name for path in GOLDEN.iterdir() if not RETROFIT_GOLDEN.match(path.name)
                       if not re.match(r"ch(0[7-9]|1\d)_", path.name))
        new = [name for name in names if name.startswith("ch06_")]
        old = [name for name in names if not name.startswith("ch06_")]
        self.assertEqual(len(new), 12)
        self.assertEqual(len(old), 32)
        self.assertEqual(len(names), 44)
        for name, digest in OLD_GOLDEN_SHA.items():
            with self.subTest(golden=name):
                body = (GOLDEN / name).read_bytes()
                self.assertEqual(hashlib.sha256(body).hexdigest(), digest)


class ReplayAndSchemaSourceTests(unittest.TestCase):
    def test_replay_file_follows_replay_contract(self):
        model = ReplayModel(tool_call_demo.REPLAY_PATH, "default")
        response = model.next({"state": {"phase": "start"}})
        self.assertEqual(response["type"], "tool_calls")
        self.assertEqual(len(response["tool_calls"]), 1)
        call = response["tool_calls"][0]
        self.assertEqual(call["name"], "read_task_cards")
        self.assertEqual(call["arguments"], {})
        self.assertEqual(model.provenance["kind"], "synthetic_script")
        self.assertFalse(model.provenance["verified_real_model_output"])

    def test_single_schema_source(self):
        self.assertEqual(list((PROJECT_ROOT / "workspace" / "ch06").rglob("*.schema.json")), [])
        self.assertIs(tool_call_demo.TOOL_SCHEMAS, validation.TOOL_SCHEMAS)
        self.assertIs(tool_call_demo.CARD_SCHEMA, validation.CARD_SCHEMA)


if __name__ == "__main__":
    unittest.main()
