"""Контракт главы 17: Release candidate фиксирует одну версию конфигурации; harness проверяет отпечаток."""

import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

import dezhurny
from school_agent.my_agent_config import ConfigError, read_my_agent
from school_agent.paths import PROJECT_ROOT, WORKSPACE_ROOT
from school_agent.release_candidate import (
    FILE_NAME, build_release_candidate, config_files, digest, validate_release_candidate,
)

GOLDEN = PROJECT_ROOT / "tests" / "golden"
# Golden блоков «Достраиваем „Дежурного“» (ретрофит глав 1–13, 0.17.0) в слепки прежних глав не входят.
RETROFIT_GOLDEN = re.compile(r"ch(0\d|1[0-3])_dezhurny_")
CASES = "ch17/cases/"
CANDIDATE = CASES + "release-candidate"
LINE = ("Release candidate: festival-rc1 | зафиксировано файлов: 3 | отпечаток совпадает — "
        "метка кандидата, не доказательство качества")
# Слепок 109 эталонов 0.15.0 (главы 1–16): глава 17 не меняет ни одного прежнего вывода.
OLD_GOLDEN_COUNT = 109
OLD_GOLDEN_DIGEST = "9b67726c15b456355fef5096e1ce9b7af70c20f01535edf59613a26e0019a500"
STATE_STORE_SHA256 = "60b6ad0de3d498d6320e17977a7ee7412586eacb2cd0c45d12a317a864cc0f4b"


def run_cli(*args):
    return subprocess.run([sys.executable, "dezhurny.py", *args], cwd=PROJECT_ROOT,
                          capture_output=True, env=dict(os.environ, PYTHONIOENCODING="utf-8"))


def tree(root):
    return {path.relative_to(root).as_posix(): hashlib.sha256(path.read_bytes()).hexdigest()
            for path in sorted(root.rglob("*")) if path.is_file()}


def temp_workspace(test):
    directory = tempfile.mkdtemp()
    test.addCleanup(shutil.rmtree, directory)
    workspace = Path(directory) / "workspace"
    shutil.copytree(WORKSPACE_ROOT, workspace)
    return workspace


class GoldenTests(unittest.TestCase):
    COMMANDS = (
        ("ch17_candidate.txt", ("candidate", "--label", "festival-rc1", "--dir", "workspace/" + CANDIDATE)),
        ("ch17_dezhurny_status.txt", ("status", "--chapter", "17", "--dir", "workspace/" + CANDIDATE)),
        ("ch17_dezhurny_run_candidate.txt", ("run", "--dir", "workspace/" + CANDIDATE)),
        ("ch17_dezhurny_eval_candidate.txt", ("eval", "--dir", "workspace/" + CANDIDATE)),
        ("ch17_release_stale_status.txt", ("status", "--chapter", "17", "--dir", "workspace/" + CASES + "release-stale")),
        ("ch17_release_invalid_status.txt", ("status", "--chapter", "17", "--dir", "workspace/" + CASES + "release-invalid")),
    )

    def test_six_outputs_and_cases_unchanged(self):
        before = tree(WORKSPACE_ROOT / "ch17")
        for golden, args in self.COMMANDS:
            with self.subTest(golden=golden):
                result = run_cli(*args)
                self.assertEqual(result.returncode, 0, result.stderr.decode("utf-8"))
                self.assertEqual(result.stderr, b"")
                printed = result.stdout.decode("utf-8").replace("\r\n", "\n")
                self.assertEqual(printed, (GOLDEN / golden).read_text(encoding="utf-8"))
                self.assertNotIn(str(PROJECT_ROOT), printed)
        # candidate с той же меткой без изменений файл не переписывает: поставка побайтно прежняя.
        self.assertEqual(tree(WORKSPACE_ROOT / "ch17"), before)

    def test_stale_and_invalid_stop_run_and_eval_in_cli(self):
        for case, message in (("release-stale", "недействителен — 07_tools.json изменён после фиксации"),
                              ("release-invalid", "неизвестное поле ready")):
            for command in ("run", "eval"):
                with self.subTest(case=case, command=command):
                    result = run_cli(command, "--dir", "workspace/" + CASES + case)
                    self.assertEqual(result.returncode, 2)
                    self.assertEqual(result.stdout, b"")
                    self.assertIn(message, result.stderr.decode("utf-8"))


class CandidateTests(unittest.TestCase):
    def setUp(self):
        self.workspace = temp_workspace(self)
        self.folder = self.workspace / CANDIDATE

    def status_row(self):
        return dezhurny.cmd_status(CANDIDATE, workspace_root=self.workspace, chapter=17)[2]

    def test_run_and_eval_print_the_label_and_change_nothing_else(self):
        with_label = dezhurny.cmd_run(CANDIDATE, workspace_root=self.workspace)
        evals = dezhurny.cmd_eval(CANDIDATE, workspace_root=self.workspace)
        self.assertIn(LINE, with_label)
        self.assertEqual(evals[2], LINE)
        (self.folder / FILE_NAME).unlink()
        without = dezhurny.cmd_run(CANDIDATE, workspace_root=self.workspace)
        self.assertEqual([line for line in with_label if line != LINE], without)
        self.assertEqual([line for line in evals if line != LINE],
                         dezhurny.cmd_eval(CANDIDATE, workspace_root=self.workspace))
        self.assertEqual(with_label[-1], "Качество модели не подтверждено этим техническим прогоном.")

    def test_same_terminal_and_tools_with_and_without_label(self):
        calls = []
        real = dezhurny.run_replay_scenario

        def spy(*args, **kwargs):
            result = real(*args, **kwargs)
            calls.append((result["terminal"], result["executed_tools"], kwargs.get("profile")))
            return result
        with mock.patch.object(dezhurny, "run_replay_scenario", spy):
            dezhurny.cmd_run(CANDIDATE, workspace_root=self.workspace)
            (self.folder / FILE_NAME).unlink()
            dezhurny.cmd_run(CANDIDATE, workspace_root=self.workspace)
        self.assertEqual(calls[0], calls[1])

    def test_changes_after_fixing_stop_run_and_eval_before_the_loop(self):
        changes = {
            "добавлен 07_tools.json": lambda: (self.folder / "07_tools.json").write_text(
                '{"enabled": ["read_task_cards", "propose_status_update"]}', encoding="utf-8"),
            "14_permissions.json изменён после фиксации": lambda: (self.folder / "14_permissions.json").write_text(
                '{"default": "deny", "task_cards": "read_only", "status_update": "deny"}', encoding="utf-8"),
            "удалён 11_evals.json": lambda: (self.folder / "11_evals.json").unlink(),
        }
        for message, change in changes.items():
            with self.subTest(message=message):
                shutil.rmtree(self.folder)
                shutil.copytree(WORKSPACE_ROOT / CANDIDATE, self.folder)
                change()
                self.assertIn("ошибка: 17_release_candidate.json: недействителен — " + message
                              + " | run не запускается, пока файл не исправлен", self.status_row())
                with mock.patch.object(dezhurny, "run_replay_scenario") as loop:
                    for command in (dezhurny.cmd_run, dezhurny.cmd_eval):
                        with self.assertRaises(ConfigError):
                            command(CANDIDATE, workspace_root=self.workspace)
                loop.assert_not_called()

    def test_new_fixation_repairs_the_label(self):
        (self.folder / "07_tools.json").write_text('{"enabled": ["read_task_cards"]}', encoding="utf-8")
        self.assertIn("недействителен", self.status_row())
        lines = dezhurny.cmd_candidate(CANDIDATE, label="festival-rc2", workspace_root=self.workspace)
        self.assertEqual(lines[2][:52], "Release candidate: festival-rc2 | зафиксировано файл")
        self.assertIn("настроено: festival-rc2; зафиксировано файлов: 4", self.status_row())

    def test_state_written_by_run_does_not_break_the_label(self):
        (self.folder / "10_state.json").write_text("{}", encoding="utf-8")
        for _ in range(2):
            self.assertIn(LINE, dezhurny.cmd_run(CANDIDATE, workspace_root=self.workspace))
        self.assertEqual(json.loads((self.folder / "10_state.json").read_text(encoding="utf-8"))["runs"], 2)

    def test_line_endings_do_not_change_the_digest(self):
        goal = self.folder / "01_goal.md"
        goal.write_bytes(goal.read_bytes().replace(b"\n", b"\r\n"))
        self.assertIn("настроено: festival-rc1", self.status_row())

    def test_candidate_is_idempotent(self):
        (self.folder / FILE_NAME).unlink()
        dezhurny.cmd_candidate(CANDIDATE, label="festival-rc1", workspace_root=self.workspace)
        first = (self.folder / FILE_NAME).read_bytes()
        with mock.patch.object(dezhurny, "save_state") as save:
            dezhurny.cmd_candidate(CANDIDATE, label="festival-rc1", workspace_root=self.workspace)
        save.assert_not_called()
        self.assertEqual((self.folder / FILE_NAME).read_bytes(), first)
        self.assertEqual(json.loads(first), json.loads((WORKSPACE_ROOT / CANDIDATE / FILE_NAME).read_text(encoding="utf-8")))

    def test_candidate_refuses_broken_config_and_bad_label(self):
        with self.assertRaises(ConfigError):
            dezhurny.cmd_candidate(CANDIDATE, label="festival rc1", workspace_root=self.workspace)
        (self.folder / "02_stop_policy.json").write_text("{bad", encoding="utf-8")
        with self.assertRaises(ConfigError):
            dezhurny.cmd_candidate(CANDIDATE, label="festival-rc1", workspace_root=self.workspace)

    def test_copied_template_is_not_a_candidate(self):
        shutil.copyfile(WORKSPACE_ROOT / "my_agent" / "templates" / FILE_NAME, self.folder / FILE_NAME)
        self.assertIn("ошибка: 17_release_candidate.json: не зафиксирован — выполни python dezhurny.py "
                      "candidate --label festival-rc1", self.status_row())

    def test_what_is_fixed(self):
        (self.folder / "10_state.json").write_text("{}", encoding="utf-8")
        (self.folder / "13_versions").mkdir()
        (self.folder / "13_versions" / "notes.md").write_text("x", encoding="utf-8")
        shutil.copytree(WORKSPACE_ROOT / "my_agent" / "examples" / "full" / "09_skills", self.folder / "09_skills")
        files = config_files(self.folder)
        self.assertEqual(files, ["01_goal.md", "09_skills/lesson-notes/SKILL.md",
                                 "09_skills/lesson-notes/references/format.md", "11_evals.json",
                                 "14_permissions.json"])
        rows = {row["file"]: row["state"] for row in read_my_agent(CANDIDATE, workspace_root=self.workspace)["rows"]}
        # Снимки главы 13 в отпечаток не входят; notes.md — не снимок, это ошибка строки 13 (0.17.0).
        self.assertEqual(rows["13_versions"], "error")

    def test_validation_rules(self):
        value = build_release_candidate("festival-rc1", self.folder)
        self.assertEqual(validate_release_candidate(value, self.folder), [])
        self.assertEqual(value["digest"], digest(self.folder, config_files(self.folder)))
        cases = {"ожидался JSON-объект": [],
                 "неизвестное поле ready": dict(value, ready=True),
                 "label — 1–64 символа [A-Za-z0-9._-]": dict(value, label="с пробелом"),
                 "не зафиксирован — выполни python dezhurny.py candidate --label festival-rc1": {"label": "festival-rc1"},
                 "недействителен — отпечаток не совпадает": dict(value, digest="0" * 64)}
        for message, item in cases.items():
            with self.subTest(message=message):
                self.assertEqual(validate_release_candidate(item, self.folder), [message])


class OneSourceTests(unittest.TestCase):
    def test_rules_live_in_one_module(self):
        for path in ("school_agent/my_agent_config.py", "dezhurny.py"):
            source = (PROJECT_ROOT / path).read_text(encoding="utf-8")
            with self.subTest(path=path):
                self.assertNotIn("def validate_release_candidate", source)
                self.assertNotIn("hashlib", source)
                self.assertNotIn("A-Za-z0-9._-", source)

    def test_module_prints_nothing_and_writes_nothing(self):
        source = (PROJECT_ROOT / "school_agent" / "release_candidate.py").read_text(encoding="utf-8")
        for token in ("print(", "write_text", "write_bytes", "save_state(", "open("):
            with self.subTest(token=token):
                self.assertNotIn(token, source)


class RegressionSnapshot(unittest.TestCase):
    def test_old_golden_and_state_store_untouched(self):
        names = sorted(path.name for path in GOLDEN.iterdir() if not RETROFIT_GOLDEN.match(path.name) if not path.name.startswith("ch17_"))
        self.assertEqual(len(names), OLD_GOLDEN_COUNT)
        total = hashlib.sha256()
        for name in names:
            total.update(name.encode("utf-8"))
            total.update(hashlib.sha256((GOLDEN / name).read_bytes()).digest())
        self.assertEqual(total.hexdigest(), OLD_GOLDEN_DIGEST)
        self.assertEqual(len([path for path in GOLDEN.iterdir() if path.name.startswith("ch17_")]), 6)
        self.assertEqual(hashlib.sha256((PROJECT_ROOT / "school_agent" / "state_store.py").read_bytes()).hexdigest(),
                         STATE_STORE_SHA256)


if __name__ == "__main__":
    unittest.main()
