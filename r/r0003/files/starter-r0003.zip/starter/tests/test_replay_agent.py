import unittest
from school_agent.agent import run_agent, run_replay_scenario

class SequenceAdapter:
    kind = "test"
    def __init__(self, rows):
        self.rows = iter(rows)
        self.contexts = []
    def next(self, context):
        self.contexts.append(context)
        return next(self.rows)

def tc(name, arguments=None, call_id="x"):
    return {"type": "tool_calls", "tool_calls": [{"id": call_id, "name": name, "arguments": arguments or {}}]}

class AgentTests(unittest.TestCase):
    def test_success_on_fifth_action(self):
        result = run_replay_scenario("success")
        self.assertEqual((result["terminal"], result["steps"]), ("success", 5))
        self.assertFalse(result["model_quality_verified"])
        self.assertEqual(result["evidence_kind"], "synthetic_script")
        self.assertEqual(result["state"]["context_requests"], 2)

    def test_skill_requests_precede_loading(self):
        events = run_replay_scenario("success")["trace"]
        for index, event in enumerate(events):
            self.assertIn(event["initiator"], ("model", "harness"))
            if event["type"] in ("skill_loaded", "skill_resource_loaded"):
                request = events[index - 1]
                self.assertEqual(request["type"], "model_response")
                self.assertEqual(request["initiator"], "model")
                self.assertEqual(event["initiator"], "harness")
        self.assertEqual(events[1]["payload"]["active_skills"], [])

    def test_no_automatic_skill_activation(self):
        result = run_replay_scenario("injection")
        self.assertFalse(any(e["type"] == "skill_loaded" for e in result["trace"]))
        self.assertEqual(result["terminal"], "success")  # Только контракт авторского сценария.
        self.assertFalse(result["model_quality_verified"])

    def test_error_and_limit(self):
        for scenario, terminal, steps in (("missing_file", "error", 2), ("permanent_error", "error", 2),
                                           ("limit", "limit", 5), ("needs_input", "needs_input", 1),
                                           ("unknown_tool", "error", 0)):
            with self.subTest(scenario=scenario):
                result = run_replay_scenario(scenario)
                self.assertEqual((result["terminal"], result["steps"]), (terminal, steps))

    def test_success_takes_precedence_at_limit(self):
        self.assertEqual(run_replay_scenario("injection", max_steps=3)["terminal"], "success")

    def test_text_promise_is_not_success(self):
        adapter = SequenceAdapter([{"type": "text", "text": "Всё прочитал, готово."}])
        result = run_agent(adapter)
        self.assertEqual((result["terminal"], result["steps"]), ("needs_input", 0))
        self.assertIsNone(result["report"])

    def test_invented_tool_denied_even_if_requested(self):
        result = run_agent(SequenceAdapter([tc("publish_report")]))
        self.assertEqual(result["executed_tools"], [])
        self.assertEqual(result["terminal"], "error")

    def test_resource_requires_activation(self):
        result = run_agent(SequenceAdapter([{"type": "read_skill_resource", "name": "project-status",
                                             "path": "references/report-template.md"}]))
        self.assertEqual(result["reason"], "skill_request_rejected")

    def test_context_disclosure_layers(self):
        adapter = SequenceAdapter([
            {"type": "load_skill", "name": "project-status"},
            {"type": "read_skill_resource", "name": "project-status", "path": "references/report-template.md"},
            {"type": "needs_input", "text": "Стоп"}])
        run_agent(adapter)
        self.assertEqual(adapter.contexts[0]["active_skills"], {})
        self.assertEqual(adapter.contexts[0]["skill_resources"], {})
        self.assertEqual(set(adapter.contexts[0]["skill_catalog"][0]), {"name", "description"})
        self.assertIn("instructions", adapter.contexts[1]["active_skills"]["project-status"])
        self.assertEqual(adapter.contexts[1]["skill_resources"], {})
        self.assertTrue(adapter.contexts[2]["skill_resources"])

    def test_repeated_context_requests_have_budget(self):
        adapter = SequenceAdapter([{"type": "load_skill", "name": "project-status"}] * 20)
        result = run_agent(adapter)
        self.assertEqual((result["terminal"], result["steps"]), ("limit", 0))
        self.assertEqual(result["reason"], "model_turn_limit")

    def test_duplicate_call_id_does_not_execute_twice(self):
        adapter = SequenceAdapter([tc("read_task_cards"), tc("read_task_cards")])
        result = run_agent(adapter)
        self.assertEqual(result["steps"], 1)
        self.assertEqual(result["reason"], "duplicate_call_id")

    def test_batch_stops_at_budget(self):
        adapter = SequenceAdapter([{"type":"tool_calls","tool_calls":[
            {"id":str(i),"name":"read_task_cards","arguments":{}} for i in range(4)]}])
        result = run_agent(adapter, max_steps=2)
        self.assertEqual((result["terminal"], result["steps"]), ("limit", 2))
