"""Контракт главы 13 в конструкторе: снимки конфигурации 13_versions/ неизменяемы, compare — по одному набору случаев."""

import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

import dezhurny
from school_agent import versions
from school_agent.my_agent_config import ConfigError, read_my_agent
from school_agent.paths import PROJECT_ROOT, WORKSPACE_ROOT
from school_agent.release_candidate import build_release_candidate
from school_agent.versions import VersionsError, compare_versions, list_versions, save_version

GOLDEN = PROJECT_ROOT / "tests" / "golden"
GOLDEN_DEZHURNY = PROJECT_ROOT / "tests" / "golden_dezhurny"
# Golden блоков «Достраиваем „Дежурного“» (ретрофит глав 1–13, 0.17.0) в слепки прежних глав не входят.
RETROFIT_GOLDEN = re.compile(r"ch(0\d|1[0-3])_dezhurny_")
CASES = "ch13/cases/"
VERSIONS = CASES + "versions"
OTHER = CASES + "versions-other-cases"
# Слепок 115 эталонов 0.16.0 (главы 1–17): ретрофит не меняет ни одного прежнего вывода.
OLD_GOLDEN_COUNT = 115
OLD_GOLDEN_DIGEST = "7d87148521f8914a2395c26a46387781562ad25ef76462579d8e8a1238605a9d"
STATE_STORE_SHA256 = "60b6ad0de3d498d6320e17977a7ee7412586eacb2cd0c45d12a317a864cc0f4b"
REPAIR = " — удали папку снимка или сохрани заново под новой меткой"
TEMPLATE = ": это шаблон, а не снимок — удали папку и выполни python dezhurny.py version save <метка>"


def run_cli(*args):
    return subprocess.run([sys.executable, "dezhurny.py", *args], cwd=PROJECT_ROOT,
                          capture_output=True, env=dict(os.environ, PYTHONIOENCODING="utf-8"))


def tree(root):
    return {path.relative_to(root).as_posix(): hashlib.sha256(path.read_bytes()).hexdigest()
            for path in sorted(root.rglob("*")) if path.is_file()}


def temp_workspace(test):
    directory = tempfile.mkdtemp()
    test.addCleanup(shutil.rmtree, directory)
    workspace = Path(directory) / "workspace"
    shutil.copytree(WORKSPACE_ROOT, workspace)
    return workspace


class GoldenTests(unittest.TestCase):
    COMMANDS = (
        ("ch13_dezhurny_version_save.txt", ("version", "save", "1.1.0", "--dir", "workspace/" + VERSIONS)),
        ("ch13_dezhurny_status_versions.txt", ("status", "--chapter", "13", "--dir", "workspace/" + VERSIONS)),
        ("ch13_dezhurny_version_compare.txt", ("version", "compare", "1.0.0", "1.1.0", "--dir", "workspace/" + VERSIONS)),
        ("ch13_dezhurny_version_compare_other.txt", ("version", "compare", "1.0.0", "1.1.0", "--dir", "workspace/" + OTHER)),
    )

    def test_four_outputs_and_cases_unchanged(self):
        before = tree(WORKSPACE_ROOT / "ch13")
        for golden, args in self.COMMANDS + (("", ("version", "list", "--dir", "workspace/" + VERSIONS)),):
            with self.subTest(args=args):
                result = run_cli(*args)
                self.assertEqual(result.returncode, 0, result.stderr.decode("utf-8"))
                self.assertEqual(result.stderr, b"")
                printed = result.stdout.decode("utf-8").replace("\r\n", "\n")
                if golden:
                    self.assertEqual(printed, (GOLDEN / golden).read_text(encoding="utf-8"))
                self.assertNotIn(str(PROJECT_ROOT), printed)
        # Повторный save той же метки и compare ничего не пишут: поставка главы 13 побайтно прежняя.
        self.assertEqual(tree(WORKSPACE_ROOT / "ch13"), before)

    def test_usage_errors_exit_2_without_traceback(self):
        for args in (("version", "save"), ("version", "compare", "1.0.0"), ("version", "list", "x"),
                     ("version", "compare", "1.0.0", "9.9.9", "--dir", "workspace/" + VERSIONS)):
            with self.subTest(args=args):
                result = run_cli(*args)
                self.assertEqual(result.returncode, 2)
                self.assertEqual(result.stdout, b"")
                self.assertNotIn(b"Traceback", result.stderr)


class SaveTests(unittest.TestCase):
    def setUp(self):
        self.workspace = temp_workspace(self)
        self.folder = self.workspace / "my_agent"
        for name in ("01_goal.md", "07_tools.json", "11_evals.json"):
            shutil.copyfile(self.workspace / VERSIONS / name, self.folder / name)

    def save(self, label):
        return dezhurny.cmd_version_save(workspace_root=self.workspace, label=label)

    def test_save_writes_only_inside_13_versions(self):
        before = tree(self.workspace)
        lines = self.save("1.0.0")
        self.assertEqual(lines[2][:26], "version: 1.0.0 | файлов: 3")
        added = sorted(set(tree(self.workspace)) - set(before))
        self.assertEqual(added, ["my_agent/13_versions/1.0.0/01_goal.md", "my_agent/13_versions/1.0.0/07_tools.json",
                                 "my_agent/13_versions/1.0.0/11_evals.json", "my_agent/13_versions/1.0.0/manifest.json"])
        self.assertEqual({name: sha for name, sha in tree(self.workspace).items() if name in before}, before)

    def test_manifest_has_no_time_and_matches_release_candidate_rules(self):
        manifest = save_version(self.folder, "1.0.0", workspace_root=self.workspace)
        candidate = build_release_candidate("1.0.0", self.folder)
        self.assertEqual(manifest, candidate)
        written = json.loads((self.folder / "13_versions" / "1.0.0" / "manifest.json").read_text(encoding="utf-8"))
        self.assertEqual(written, manifest)
        self.assertEqual(sorted(written), ["digest", "files", "label"])

    def test_same_label_same_files_writes_nothing(self):
        self.save("1.0.0")
        before = tree(self.folder)
        with mock.patch.object(versions, "save_state") as save:
            self.save("1.0.0")
        save.assert_not_called()
        self.assertEqual(tree(self.folder), before)

    def test_same_label_other_files_is_refused(self):
        self.save("1.0.0")
        (self.folder / "07_tools.json").write_text('{"enabled": ["read_task_cards"]}', encoding="utf-8")
        with self.assertRaises(ConfigError) as refused:
            self.save("1.0.0")
        self.assertEqual(str(refused.exception), "версия 1.0.0 уже есть и отличается — выбери новую метку")

    def test_save_refuses_broken_config_but_not_rows_13_and_17(self):
        with self.assertRaises(ConfigError):
            self.save("с пробелом")
        (self.folder / "17_release_candidate.json").write_text('{"label": "rc", "ready": true}', encoding="utf-8")
        self.save("1.0.0")
        (self.folder / "02_stop_policy.json").write_text("{bad", encoding="utf-8")
        with self.assertRaises(ConfigError) as refused:
            self.save("1.1.0")
        self.assertIn("02_stop_policy.json: не JSON", str(refused.exception))

    def test_empty_config_is_a_snapshot(self):
        # Вердикт RETRO_TECH, C1: пустая конфигурация — снимок, как у candidate главы 17.
        for name in ("01_goal.md", "07_tools.json", "11_evals.json"):
            (self.folder / name).unlink()
        lines = self.save("0.0.0")
        self.assertEqual(lines[2][:26], "version: 0.0.0 | файлов: 0")
        self.assertEqual(lines[3], "снимок конфигурации, не оценка качества")
        self.assertEqual(sorted(path.name for path in (self.folder / "13_versions" / "0.0.0").iterdir()),
                         ["manifest.json"])
        for name in ("01_goal.md", "07_tools.json", "11_evals.json"):
            shutil.copyfile(self.workspace / VERSIONS / name, self.folder / name)
        self.save("1.0.0")
        lines = dezhurny.cmd_version_compare(first="0.0.0", second="1.0.0", workspace_root=self.workspace)
        self.assertIn("добавлены: 01_goal.md, 07_tools.json, 11_evals.json", lines)
        self.assertIn("decision: не сравнивается — разные наборы случаев (правило главы 13)", lines)
        self.assertIn("настроено: версий: 2 (0.0.0, 1.0.0)",
                      dezhurny.cmd_status(workspace_root=self.workspace, chapter=13)[2])

    def test_snapshot_does_not_change_the_release_candidate_fingerprint(self):
        dezhurny.cmd_candidate(workspace_root=self.workspace, label="festival-rc1")
        before = (self.folder / "17_release_candidate.json").read_bytes()
        self.save("1.0.0")
        row = dezhurny.cmd_status(workspace_root=self.workspace, chapter=17)[2]
        self.assertIn("настроено: festival-rc1; зафиксировано файлов: 3", row)
        self.assertEqual(build_release_candidate("festival-rc1", self.folder), json.loads(before))

    def test_list_is_in_string_order(self):
        self.assertEqual(dezhurny.cmd_version_list(workspace_root=self.workspace)[2],
                         "versions: нет — выполни python dezhurny.py version save <метка>")
        for label in ("1.2.0", "1.10.0"):
            self.save(label)
        self.assertEqual([item["label"] for item in list_versions(self.folder)], ["1.10.0", "1.2.0"])


class CompareTests(unittest.TestCase):
    def setUp(self):
        self.workspace = temp_workspace(self)

    def compare(self, folder, first, second):
        return dezhurny.cmd_version_compare(folder, first=first, second=second, workspace_root=self.workspace)

    def test_regression_is_only_pass_to_fail(self):
        lines = self.compare(VERSIONS, "1.0.0", "1.1.0")
        self.assertIn("improved: 0 | regressions: 1", lines)
        self.assertIn("decision: revert", lines)

    def test_improvement_is_only_fail_to_pass(self):
        lines = self.compare(VERSIONS, "1.1.0", "1.0.0")
        self.assertIn("case report-on-clean-cards: 1.1.0 fail | 1.0.0 pass", lines)
        self.assertIn("improved: 1 | regressions: 0", lines)
        self.assertIn("decision: keep", lines)

    def test_no_improvement_asks_for_other_evidence(self):
        lines = self.compare(VERSIONS, "1.0.0", "1.0.0")
        self.assertIn("improved: 0 | regressions: 0", lines)
        self.assertIn("decision: keep — улучшение не наблюдается: покажи другое свидетельство (diff, trace)", lines)

    def test_other_cases_are_not_evaluated(self):
        with mock.patch.object(dezhurny, "_eval_cases") as evaluate, \
                mock.patch.object(dezhurny, "run_replay_scenario") as loop:
            lines = self.compare(OTHER, "1.0.0", "1.1.0")
        evaluate.assert_not_called()
        loop.assert_not_called()
        self.assertEqual(lines[-2], "decision: не сравнивается — разные наборы случаев (правило главы 13)")
        self.assertFalse(compare_versions(self.workspace / OTHER, "1.0.0", "1.1.0")["same_cases"])

    def test_compare_changes_nothing_and_decision_is_advice(self):
        before = tree(self.workspace)
        self.compare(VERSIONS, "1.0.0", "1.1.0")
        self.assertEqual(tree(self.workspace), before)

    def test_difference_by_manifest(self):
        folder = self.workspace / VERSIONS
        self.assertEqual(compare_versions(folder, "1.0.0", "1.1.0"),
                         {"changed": ["07_tools.json"], "added": [], "removed": [], "same_cases": True})


class BrokenSnapshotTests(unittest.TestCase):
    """Вердикт PLAN ретрофита, MINOR 2–3: сломанный снимок останавливает run и eval и говорит, что делать."""

    def setUp(self):
        self.workspace = temp_workspace(self)
        self.folder = self.workspace / VERSIONS
        self.snapshot = self.folder / "13_versions" / "1.1.0"

    def assert_stops(self, message):
        row = dezhurny.cmd_status(VERSIONS, workspace_root=self.workspace, chapter=13)[2]
        self.assertEqual(row, "глава 13 | 13_versions | ошибка: " + message
                         + " | run не запускается, пока файл не исправлен")
        with mock.patch.object(dezhurny, "run_replay_scenario") as loop:
            for command in (dezhurny.cmd_run, dezhurny.cmd_eval):
                with self.assertRaises(ConfigError) as stopped:
                    command(VERSIONS, workspace_root=self.workspace)
                self.assertEqual(str(stopped.exception), message)
        loop.assert_not_called()

    def test_extra_file(self):
        (self.snapshot / "notes.md").write_text("x", encoding="utf-8")
        self.assert_stops("13_versions: 1.1.0: лишний файл notes.md" + REPAIR)

    def test_changed_file(self):
        (self.snapshot / "07_tools.json").write_text('{"enabled": ["read_task_cards"]}', encoding="utf-8")
        self.assert_stops("13_versions: 1.1.0: файл 07_tools.json не совпадает с манифестом" + REPAIR)

    def test_missing_file(self):
        (self.snapshot / "01_goal.md").unlink()
        self.assert_stops("13_versions: 1.1.0: файл 01_goal.md не совпадает с манифестом" + REPAIR)

    def test_no_manifest(self):
        (self.snapshot / "manifest.json").unlink()
        self.assert_stops("13_versions: 1.1.0: нет manifest.json" + REPAIR)

    def test_corrupted_manifest(self):
        (self.snapshot / "manifest.json").write_text("{bad", encoding="utf-8")
        self.assert_stops("13_versions: 1.1.0: manifest.json повреждён" + REPAIR)

    def test_label_format(self):
        self.snapshot.rename(self.snapshot.with_name("1.1 new"))
        self.assert_stops("13_versions: 1.1 new: метка не соответствует формату" + REPAIR)

    def test_copied_template_is_not_a_snapshot(self):
        template = WORKSPACE_ROOT / "my_agent" / "templates" / "13_versions"
        shutil.rmtree(self.folder / "13_versions")
        shutil.copytree(template, self.folder / "13_versions")
        self.assert_stops("13_versions" + TEMPLATE)
        shutil.rmtree(self.folder / "13_versions")
        shutil.copytree(template, self.folder / "13_versions" / "1.0.0")
        self.assert_stops("13_versions/1.0.0" + TEMPLATE)

    def test_line_endings_do_not_break_a_snapshot(self):
        goal = self.snapshot / "01_goal.md"
        goal.write_bytes(goal.read_bytes().replace(b"\n", b"\r\n"))
        self.assertIn("настроено: версий: 2 (1.0.0, 1.1.0)",
                      dezhurny.cmd_status(VERSIONS, workspace_root=self.workspace, chapter=13)[2])


class RunUnchangedTests(unittest.TestCase):
    def test_snapshots_do_not_change_run(self):
        workspace = temp_workspace(self)
        with_versions = dezhurny.cmd_run(VERSIONS, workspace_root=workspace)
        shutil.rmtree(workspace / VERSIONS / "13_versions")
        self.assertEqual(dezhurny.cmd_run(VERSIONS, workspace_root=workspace), with_versions)

    def test_run_without_13_versions_is_byte_identical(self):
        for golden, args in (("dezhurny_run_default.txt", ("run",)),
                             ("dezhurny_run_limit2.txt", ("run", "--dir", "workspace/my_agent/examples/limit2"))):
            with self.subTest(golden=golden):
                printed = run_cli(*args).stdout.decode("utf-8").replace("\r\n", "\n")
                self.assertEqual(printed, (GOLDEN_DEZHURNY / golden).read_text(encoding="utf-8"))


class OneSourceTests(unittest.TestCase):
    def test_hash_and_label_rules_live_in_release_candidate(self):
        for path in ("school_agent/versions.py", "school_agent/my_agent_config.py", "dezhurny.py"):
            source = (PROJECT_ROOT / path).read_text(encoding="utf-8")
            with self.subTest(path=path):
                self.assertNotIn("hashlib", source)
                self.assertNotIn("A-Za-z0-9._-]{", source)

    def test_versions_module_prints_nothing_and_has_no_second_mechanism(self):
        source = (PROJECT_ROOT / "school_agent" / "versions.py").read_text(encoding="utf-8")
        # change_demo.py главы 13 назван в докстринге как граница, но не импортируется.
        for token in ("print(", "import change_demo", "versioning import", "from .versioning",
                      "run_replay_scenario", "subprocess"):
            with self.subTest(token=token):
                self.assertNotIn(token, source)

    def test_row_13_is_read_by_the_versions_module(self):
        workspace = temp_workspace(self)
        rows = {row["file"]: row for row in read_my_agent(VERSIONS, workspace_root=workspace)["rows"]}
        self.assertEqual(rows["13_versions"]["state"], "configured")
        with self.assertRaises(VersionsError):
            versions.validate_versions_dir(workspace / "my_agent")


class RegressionSnapshot(unittest.TestCase):
    def test_old_golden_and_state_store_untouched(self):
        names = sorted(path.name for path in GOLDEN.iterdir() if not RETROFIT_GOLDEN.match(path.name))
        self.assertEqual(len(names), OLD_GOLDEN_COUNT)
        total = hashlib.sha256()
        for name in names:
            total.update(name.encode("utf-8"))
            total.update(hashlib.sha256((GOLDEN / name).read_bytes()).digest())
        self.assertEqual(total.hexdigest(), OLD_GOLDEN_DIGEST)
        self.assertEqual(len([path for path in GOLDEN.iterdir() if RETROFIT_GOLDEN.match(path.name)]), 15)
        self.assertEqual(hashlib.sha256((PROJECT_ROOT / "school_agent" / "state_store.py").read_bytes()).hexdigest(),
                         STATE_STORE_SHA256)


if __name__ == "__main__":
    unittest.main()
