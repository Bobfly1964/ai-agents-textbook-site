"""Контракт главы 7: dispatcher, allowlist, tool error и журнал событий поверх существующего кода."""

import hashlib
import os
import re
import subprocess
import sys
import unittest

import dispatcher_demo
from school_agent.agent import run_agent
from school_agent.dispatcher import AVAILABLE_TOOLS
from school_agent.paths import PROJECT_ROOT
from school_agent.replay_model import ReplayModel
from tests.test_tool_call_demo import spy_on


GOLDEN = PROJECT_ROOT / "tests" / "golden"
# Golden блоков «Достраиваем „Дежурного“» (ретрофит глав 1–13, 0.17.0) в слепки прежних глав не входят.
RETROFIT_GOLDEN = re.compile(r"ch(0\d|1[0-3])_dezhurny_")
ALL_TOOLS = tuple(AVAILABLE_TOOLS)
# Путь, по которому строка от модели могла бы превратиться в код.
FORBIDDEN = ("eval(", "exec(", "getattr(", "importlib", "__import__", "subprocess")
# Слепок 44 эталонов глав 1–6: имя и SHA-256 каждого файла, по порядку имён.
OLD_GOLDEN_COUNT = 44
OLD_GOLDEN_DIGEST = "093b88b14298fe4a4f2825095294d7df7a6e6b0b081ff643e09803620c0261b9"


def run_replay(name):
    replay_scenario, tools_scenario = dispatcher_demo.RUNS[name]
    adapter = ReplayModel(dispatcher_demo.REPLAY_PATH, replay_scenario)
    return run_agent(adapter, scenario=tools_scenario)


class DispatcherDemoGoldenTests(unittest.TestCase):
    def check_output(self, golden, script, *args):
        """Полный stdout команды равен эталону, stderr пуст."""

        result = subprocess.run(
            [sys.executable, script, *args],
            cwd=PROJECT_ROOT,
            capture_output=True,
            env=dict(os.environ, PYTHONIOENCODING="utf-8"),
            check=True,
        )
        expected = (GOLDEN / golden).read_text(encoding="utf-8")
        printed = result.stdout.decode("utf-8").replace("\r\n", "\n")
        self.assertEqual(printed, expected)
        self.assertEqual(result.stderr, b"")
        self.assertNotIn("Traceback", printed)
        self.assertIsNone(re.search(r"[A-Za-z]:\\|/home/|/Users/", printed))
        self.assertNotIn(str(PROJECT_ROOT), printed)
        return printed

    def test_case_allowed(self):
        printed = self.check_output("ch07_case_allowed.txt", "dispatcher_demo.py", "case", "allowed")
        self.assertIn("allowlist: allowed", printed)
        self.assertIn("execution: performed", printed)
        self.assertIn("outcome: result", printed)

    def test_case_unknown_tool(self):
        printed = self.check_output(
            "ch07_case_unknown_tool.txt", "dispatcher_demo.py", "case", "unknown-tool")
        self.assertIn("tool: delete_everything", printed)
        self.assertIn("allowlist: denied", printed)
        self.assertIn("execution: not performed", printed)

    def test_case_invalid_arguments(self):
        printed = self.check_output(
            "ch07_case_invalid_arguments.txt", "dispatcher_demo.py", "case", "invalid-arguments")
        self.assertIn("arguments: invalid", printed)
        self.assertIn("execution: not performed", printed)
        self.assertIn("нет обязательного поля task_id", printed)

    def test_case_tool_exception(self):
        printed = self.check_output(
            "ch07_case_tool_exception.txt", "dispatcher_demo.py", "case", "tool-exception")
        first, second = printed.split("\n\n")
        self.assertIn("execution: performed", first)
        self.assertIn("outcome: tool error", first)
        self.assertIn("error: Ошибка: учебные карточки недоступны", first)
        self.assertIn("outcome: result", second)

    def test_run_two_calls(self):
        printed = self.check_output(
            "ch07_run_two_calls.txt", "dispatcher_demo.py", "run", "two-calls")
        self.assertIn("origin: synthetic_script — авторский сценарий, не запись модели", printed)
        self.assertIn("terminal: needs_input", printed)

    def test_run_stop_after_decision(self):
        printed = self.check_output(
            "ch07_run_stop_after_decision.txt", "dispatcher_demo.py", "run", "stop-after-decision")
        self.assertIn("terminal: error | steps: 0", printed)
        self.assertIn("not executed: call-2 read_task_cards", printed)

    def test_run_missing_file(self):
        printed = self.check_output(
            "ch07_run_missing_file.txt", "dispatcher_demo.py", "run", "missing-file")
        self.assertIn("error: Ошибка: учебные карточки недоступны", printed)
        self.assertIn("terminal: error | steps: 2", printed)

    def test_agent_demo_missing_file(self):
        """Поурочный план урока 14: команда главы 2 без текста ошибки в stdout."""

        printed = self.check_output(
            "ch07_agent_missing_file.txt", "agent_demo.py", "--scenario", "missing_file")
        self.assertIn("Шаг 2 | read_task_cards | error", printed)
        self.assertIn("Остановка: error", printed)
        self.assertNotIn("Ошибка: учебные карточки недоступны", printed)


class NothingRunsBeforeTheChecksTests(unittest.TestCase):
    """Отказ до выполнения доказывается отсутствием вызова, а не только строкой вывода."""

    def test_unknown_tool_calls_no_implementation(self):
        with spy_on(*ALL_TOOLS) as calls:
            dispatcher_demo.main(["case", "unknown-tool"])
        self.assertEqual(calls, [])

    def test_invalid_arguments_do_not_reach_validate_task_card(self):
        with spy_on(*ALL_TOOLS) as calls:
            dispatcher_demo.main(["case", "invalid-arguments"])
        self.assertEqual(calls, [])

    def test_allowed_call_runs_once_without_arguments(self):
        with spy_on(*ALL_TOOLS) as calls:
            dispatcher_demo.main(["case", "allowed"])
        self.assertEqual(calls, [("read_task_cards", (), {})])

    def test_stop_after_decision_leaves_the_rest_of_the_batch(self):
        with spy_on(*ALL_TOOLS) as calls:
            dispatcher_demo.main(["run", "stop-after-decision"])
        self.assertEqual(calls, [])


class EventLogTests(unittest.TestCase):
    """Журнал событий главы 7 — это события существующего run_agent."""

    @staticmethod
    def events(result, kind):
        return [event["payload"] for event in result["trace"] if event["type"] == kind]

    def test_two_calls_keep_ids_order_and_first_result(self):
        result = run_replay("two-calls")
        requested = [value["request"]["id"] for value in self.events(result, "tool_requested")]
        observed = [value["observation"] for value in self.events(result, "tool_observation")]
        self.assertEqual(requested, ["call-1", "call-2"])
        self.assertEqual(len(set(requested)), 2)
        self.assertEqual([item["call_id"] for item in observed], requested)
        self.assertTrue(observed[0]["ok"])
        self.assertEqual(observed[0]["result"]["count"], 3)
        self.assertFalse(observed[1]["ok"])
        self.assertTrue(observed[1]["executed"])
        self.assertEqual(result["terminal"], "needs_input")
        self.assertEqual(result["steps"], 2)

    def test_rejected_call_is_not_a_step(self):
        result = run_replay("stop-after-decision")
        self.assertEqual(result["steps"], 0)
        self.assertEqual(result["executed_tools"], [])
        self.assertEqual(result["terminal"], "error")
        self.assertEqual(len(self.events(result, "tool_observation")), 1)

    def test_retry_policy_is_unchanged(self):
        result = run_replay("missing-file")
        self.assertEqual(result["steps"], 2)
        self.assertEqual(result["failures"], 2)
        decisions = [value["decision"] for value in self.events(result, "tool_observation")]
        self.assertEqual(decisions, ["continue", "error"])

    def test_replay_file_follows_replay_contract(self):
        for name, (replay_scenario, _) in dispatcher_demo.RUNS.items():
            with self.subTest(run=name):
                model = ReplayModel(dispatcher_demo.REPLAY_PATH, replay_scenario)
                self.assertEqual(model.provenance["kind"], "synthetic_script")
                self.assertFalse(model.provenance["verified_real_model_output"])
                self.assertEqual(model.provenance["authored_for"], "starter 0.6.0")


class NoSecondMechanismTests(unittest.TestCase):
    def test_no_dynamic_lookup_of_names(self):
        sources = {
            "school_agent/dispatcher.py": PROJECT_ROOT / "school_agent" / "dispatcher.py",
            "dispatcher_demo.py": PROJECT_ROOT / "dispatcher_demo.py",
        }
        for name, path in sources.items():
            source = path.read_text(encoding="utf-8")
            for token in FORBIDDEN:
                with self.subTest(file=name, token=token):
                    self.assertNotIn(token, source)

    def test_demo_reuses_existing_core(self):
        self.assertEqual(dispatcher_demo.call_tool.__module__, "school_agent.dispatcher")
        self.assertEqual(dispatcher_demo.run_agent.__module__, "school_agent.agent")
        source = (PROJECT_ROOT / "dispatcher_demo.py").read_text(encoding="utf-8")
        for name in ("AVAILABLE_TOOLS", "validate_tool_arguments", "decide_after_observation",
                     "TraceRecorder"):
            with self.subTest(name=name):
                self.assertNotIn(name, source)

    def test_four_tools_in_the_allowlist(self):
        self.assertEqual(sorted(AVAILABLE_TOOLS), [
            "build_status_report", "propose_status_update",
            "read_task_cards", "validate_task_card",
        ])


class GoldenSnapshotTests(unittest.TestCase):
    def test_old_golden_untouched_and_eight_new(self):
        # Эталоны следующих глав проверяет их собственный тест-слепок.
        names = sorted(path.name for path in GOLDEN.iterdir() if not RETROFIT_GOLDEN.match(path.name)
                       if not re.match(r"ch(0[89]|1\d)_", path.name))
        new = [name for name in names if name.startswith("ch07_")]
        old = [name for name in names if not name.startswith("ch07_")]
        self.assertEqual(len(new), 8)
        self.assertEqual(len(old), OLD_GOLDEN_COUNT)
        digest = hashlib.sha256()
        for name in old:
            digest.update(name.encode("utf-8"))
            digest.update(hashlib.sha256((GOLDEN / name).read_bytes()).digest())
        self.assertEqual(digest.hexdigest(), OLD_GOLDEN_DIGEST)


if __name__ == "__main__":
    unittest.main()
