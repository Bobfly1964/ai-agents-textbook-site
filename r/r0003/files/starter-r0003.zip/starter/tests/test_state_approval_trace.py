import copy
import json
import shutil
import tempfile
import unittest
from pathlib import Path
from school_agent.approval import ApprovalError, apply_status_update
from school_agent.tools import Tools, proposal_id
from school_agent.paths import WORKSPACE_ROOT, WorkspaceBoundaryError
from school_agent.state_store import load_state, save_state
from school_agent.trace import TraceRecorder, redact
from school_agent.agent import run_replay_scenario

class StateApprovalTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name) / "workspace"
        shutil.copytree(WORKSPACE_ROOT, self.root)
        self.proposal = Tools(self.root).propose_status_update("task-003", "in_progress", "Блокер устранён")

    def test_propose_and_decline_do_not_write(self):
        original = (self.root / "tasks/task-003.json").read_bytes()
        for approved in (False, None, 1, "yes", {"approved": True}):
            self.assertFalse(apply_status_update(self.proposal, approved=approved, workspace_root=self.root)["applied"])
        self.assertEqual((self.root / "tasks/task-003.json").read_bytes(), original)

    def test_approval_changes_only_status_and_is_idempotent(self):
        result = apply_status_update(self.proposal, approved=True, workspace_root=self.root)
        self.assertTrue(result["applied"])
        self.assertEqual(load_state("tasks/task-003.json", workspace_root=self.root), self.proposal["after"])
        again = apply_status_update(self.proposal, approved=True, workspace_root=self.root)
        self.assertTrue(again["already_applied"])
        self.assertFalse(again["applied"])

    def test_tampered_proposal_denied(self):
        for key, value in (("target", "../outside.json"), ("reason", "Подмена")):
            proposal = dict(self.proposal, **{key:value})
            with self.assertRaises(ApprovalError):
                apply_status_update(proposal, approved=True, workspace_root=self.root)
        proposal = copy.deepcopy(self.proposal)
        proposal["after"]["title"] = "Подмена заголовка"
        proposal["operation_id"] = proposal_id(proposal)
        with self.assertRaises(ApprovalError):
            apply_status_update(proposal, approved=True, workspace_root=self.root)

    def test_stale_proposal_denied(self):
        card = load_state("tasks/task-003.json", workspace_root=self.root)
        card["title"] = "Новая редакция"
        save_state(card, "tasks/task-003.json", workspace_root=self.root)
        with self.assertRaises(ApprovalError):
            apply_status_update(self.proposal, approved=True, workspace_root=self.root)

    def test_state_round_trip_and_boundary(self):
        data = {"phase":"ready","nested":{"x":1}}
        save_state(data, "state/test.json", workspace_root=self.root)
        self.assertEqual(load_state("state/test.json", workspace_root=self.root), data)
        with self.assertRaises(WorkspaceBoundaryError):
            save_state(data, "../outside.json", workspace_root=self.root)

    def test_trace_filters_keys_not_arbitrary_strings(self):
        value = redact({"api_key":"secret-value","notes":"secret-value"})
        self.assertEqual(value["api_key"], "[REDACTED]")
        self.assertEqual(value["notes"], "secret-value")
        event = TraceRecorder().record("tool_requested", initiator="model", request={"token":"x"})
        self.assertEqual(event["initiator"], "model")
        self.assertEqual(event["payload"]["request"]["token"], "[REDACTED]")

    def test_trace_confined_and_not_overwritten(self):
        run_replay_scenario("success", workspace_root=self.root, trace_relative_path="traces/test.jsonl")
        events = [json.loads(line) for line in (self.root / "traces/test.jsonl").read_text(encoding="utf-8").splitlines()]
        self.assertEqual(events[-1]["type"], "run_finished")
        with self.assertRaises(ValueError):
            run_replay_scenario("success", workspace_root=self.root, trace_relative_path="traces/test.jsonl")
        with self.assertRaises(ValueError):
            run_replay_scenario("success", workspace_root=self.root, trace_relative_path="tasks/new.json")
