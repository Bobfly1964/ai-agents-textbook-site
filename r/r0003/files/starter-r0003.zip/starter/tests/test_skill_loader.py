from __future__ import annotations

import unittest

from school_agent.paths import PROJECT_ROOT
from school_agent.skill_loader import (
    SkillFormatError,
    discover_skills,
    load_skill,
    read_skill_resource,
)


SKILLS_ROOT = PROJECT_ROOT / "skills"


class SkillLoaderTests(unittest.TestCase):
    def test_catalog_exposes_only_short_metadata(self) -> None:
        catalog = discover_skills(SKILLS_ROOT)
        self.assertEqual(catalog[0]["name"], "project-status")
        self.assertEqual(set(catalog[0]), {"name", "description"})

    def test_activation_loads_instructions_and_lists_files(self) -> None:
        skill = load_skill(SKILLS_ROOT, "project-status")
        self.assertIn("Процедура", skill["instructions"])
        paths = {item["path"] for item in skill["available_files"]}
        self.assertIn("references/report-template.md", paths)
        self.assertIn("scripts/validate_cards.py", paths)

    def test_resource_is_loaded_on_demand(self) -> None:
        result = read_skill_resource(
            SKILLS_ROOT, "project-status", "references/report-template.md"
        )
        self.assertIn("Шаблон", result["content"])

    def test_scripts_cannot_be_read_as_resources(self) -> None:
        with self.assertRaises(SkillFormatError):
            read_skill_resource(
                SKILLS_ROOT, "project-status", "scripts/validate_cards.py"
            )

    def test_path_traversal_is_rejected(self) -> None:
        with self.assertRaises(SkillFormatError):
            read_skill_resource(SKILLS_ROOT, "project-status", "references/../../README.md")


if __name__ == "__main__":
    unittest.main()


class SkillBoundaryTests(unittest.TestCase):
    def test_skill_file_symlink_is_rejected(self):
        import tempfile
        from pathlib import Path
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory) / "skills"
            (root / "example").mkdir(parents=True)
            outside = Path(directory) / "outside.md"
            outside.write_text("---\nname: example\ndescription: Demo\n---\nText", encoding="utf-8")
            try:
                (root / "example/SKILL.md").symlink_to(outside)
            except (OSError, NotImplementedError):
                self.skipTest("symlinks unavailable")
            with self.assertRaises(SkillFormatError):
                load_skill(root, "example")

    def test_duplicate_metadata_rejected(self):
        import tempfile
        from pathlib import Path
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root / "example").mkdir()
            (root / "example/SKILL.md").write_text(
                "---\nname: example\nname: other\ndescription: Demo\n---\nText", encoding="utf-8")
            with self.assertRaises(SkillFormatError):
                load_skill(root, "example")
