import json
import unittest
from school_agent.bridge import ManualBridge
from school_agent.agent import run_agent
from school_agent.response import parse_response, ResponseError

class BridgeTests(unittest.TestCase):
    def test_manual_round_trip_fixture_is_not_real_model(self):
        lines = iter([
            '{"type":"tool_calls","tool_calls":[{"id":"b1","name":"read_task_cards","arguments":{}}]}',
            ".", '{"type":"needs_input","text":"Фикстура: остановить демонстрацию"}', "."])
        output = []
        result = run_agent(ManualBridge(lambda: next(lines), output.append))
        self.assertEqual((result["terminal"], result["steps"]), ("needs_input", 1))
        self.assertEqual(result["adapter"], "bridge")
        self.assertFalse(result["model_quality_verified"])
        contexts = [json.loads(item) for item in output if item.startswith("{")]
        self.assertEqual(contexts[0]["active_skills"], {})
        self.assertEqual(contexts[1]["observations"][0]["result"]["provenance"]["trust"], "untrusted")
        self.assertIn("response_schema", contexts[0])
        self.assertIn("input_schema", contexts[0]["tool_catalog"][0])

    def test_no_model_approval_or_path(self):
        raw = '{"type":"tool_calls","tool_calls":[{"id":"b","name":"read_task_cards","arguments":{"path":"../"}}]}'
        lines = iter([raw, "."])
        result = run_agent(ManualBridge(lambda: next(lines), lambda value: None))
        self.assertEqual((result["terminal"], result["steps"]), ("error", 0))

    def test_reject_malformed_json_and_schema(self):
        invalid = [
            '{"type":"text","type":"error","text":"x"}',
            '{"type":"text","text":NaN}', '[]', '{"type":"text","text":""}',
            '{"type":"text","text":"x","approved":true}',
            '```json\n{"type":"text","text":"x"}\n```',
            '{"type":"tool_calls","tool_calls":[]}',
            '{"type":"tool_calls","tool_calls":[{"id":"a","name":"x","arguments":{}},{"id":"a","name":"x","arguments":{}}]}',
            '{"type":"tool_calls","tool_calls":[{"id":"a","name":"x","arguments":{"approved":true,"approved":false}}]}',
            'x' * 256001,
        ]
        for raw in invalid:
            with self.subTest(raw=raw[:100]):
                with self.assertRaises(ResponseError):
                    parse_response(raw)

    def test_eof_does_not_claim_live_run(self):
        lines = iter([])
        result = run_agent(ManualBridge(lambda: next(lines), lambda value: None))
        self.assertEqual(result["terminal"], "needs_input")
        self.assertEqual(result["steps"], 0)
        self.assertIn("bridge_input_needed", result["reason"])

    def test_cancel(self):
        self.assertEqual(ManualBridge(lambda: "/cancel", lambda value: None).next({})["type"], "needs_input")
