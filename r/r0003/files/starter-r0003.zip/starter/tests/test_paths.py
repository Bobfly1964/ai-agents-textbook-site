from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from school_agent.paths import WorkspaceBoundaryError, resolve_workspace_path


class WorkspacePathTests(unittest.TestCase):
    def test_accepts_relative_path_inside_workspace(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            target = root / "tasks" / "card.json"
            target.parent.mkdir()
            target.write_text("{}", encoding="utf-8")
            self.assertEqual(
                resolve_workspace_path("tasks/card.json", workspace_root=root),
                target.resolve(),
            )

    def test_rejects_parent_traversal(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            with self.assertRaises(WorkspaceBoundaryError):
                resolve_workspace_path("../outside.json", workspace_root=directory)

    def test_rejects_absolute_path(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            with self.assertRaises(WorkspaceBoundaryError):
                resolve_workspace_path(Path(directory) / "file.json", workspace_root=directory)


if __name__ == "__main__":
    unittest.main()

