"""Сохранённые golden-контракты глав 1–2 в starter 0.3.1."""
import os
import subprocess
import sys
import unittest
from pathlib import Path
from school_agent.paths import PROJECT_ROOT
from chat_stub import model_stub

GOLDEN = PROJECT_ROOT / "tests/golden"

class GoldenTests(unittest.TestCase):
    def check_output(self, golden, *args):
        result = subprocess.run([sys.executable, *args], cwd=PROJECT_ROOT,
                                capture_output=True, text=True, encoding="utf-8",
                                env=dict(os.environ, PYTHONIOENCODING="utf-8"), check=True)
        expected = (GOLDEN / golden).read_text(encoding="utf-8")
        self.assertEqual(result.stdout.replace("\r\n", "\n"), expected)
        self.assertEqual(result.stderr, "")

    def test_stub_phrase_and_string_signature(self):
        self.assertEqual(model_stub("Проверь карточки проекта"),
                         "Карточки проекта прочитаны. Задача task-003 заблокирована.")

    def test_ch01_normal(self):
        self.check_output("chat_normal.txt", "chat_stub.py")

    def test_ch01_error_keeps_identical_promise(self):
        self.check_output("chat_missing.txt", "chat_stub.py", "--scenario", "missing_file")

    def test_ch02_permanent_error(self):
        self.check_output("loop_permanent_error.txt", "loop_demo.py", "--scenario", "permanent_error")

    def test_ch02_success(self):
        self.check_output("loop_one_match.txt", "loop_demo.py", "--scenario", "one_match")

    def test_ch02_ambiguity(self):
        self.check_output("loop_two_matches.txt", "loop_demo.py", "--scenario", "two_matches")

    def test_ch02_temporary_error(self):
        self.check_output("loop_temporary_error.txt", "loop_demo.py", "--scenario", "temporary_error")

    def test_ch02_limit(self):
        self.check_output("loop_limit.txt", "loop_demo.py", "--scenario", "limit")

    def test_ch02_no_matches(self):
        self.check_output("loop_no_matches.txt", "loop_demo.py", "--scenario", "no_matches")

    def test_ch02_missing_file(self):
        self.check_output("loop_missing_file.txt", "loop_demo.py", "--scenario", "missing_file")

    def test_teacher_demo(self):
        self.check_output("agent_success.txt", "agent_demo.py", "--scenario", "success")

    def test_json_is_opt_in(self):
        import json
        result = subprocess.run([sys.executable, "chat_stub.py", "--json"], cwd=PROJECT_ROOT,
                                capture_output=True, text=True, encoding="utf-8",
                                env=dict(os.environ, PYTHONIOENCODING="utf-8"), check=True)
        self.assertEqual(json.loads(result.stdout)["message"], model_stub("x"))

    def test_stub_does_not_read_files(self):
        from unittest.mock import patch
        with patch("chat_stub.read_task_cards") as reader:
            model_stub("Прочитай файл")
            reader.assert_not_called()

    def test_real_read_failure_is_also_readable(self):
        from unittest.mock import patch
        from chat_stub import run_demo
        from school_agent.tools import ToolDataError
        with patch("chat_stub.read_task_cards", side_effect=ToolDataError(
                "cards_unavailable", "Ошибка: учебные карточки недоступны")):
            result = run_demo("Прочитай файл")
        self.assertEqual(result["message"], model_stub("x"))
        self.assertEqual(result["observation"]["error"], "Ошибка: учебные карточки недоступны")
