import inspect
import json
import tempfile
import unittest
from pathlib import Path
from school_agent.dispatcher import AVAILABLE_TOOLS, call_tool
from school_agent.tools import Tools, read_task_cards, validate_card_data, ToolDataError
from school_agent.validation import TOOL_SCHEMAS, validate_tool_arguments

class ToolTests(unittest.TestCase):
    def test_four_tools_only(self):
        self.assertEqual(set(AVAILABLE_TOOLS), set(TOOL_SCHEMAS))
        self.assertEqual(len(AVAILABLE_TOOLS), 4)
        self.assertNotIn("apply_status_update", AVAILABLE_TOOLS)

    def test_pathless_signature_and_schema(self):
        self.assertEqual(list(inspect.signature(read_task_cards).parameters), [])
        self.assertEqual(list(inspect.signature(Tools.read_task_cards).parameters), ["self"])
        self.assertEqual(TOOL_SCHEMAS["read_task_cards"]["properties"], {})
        for args in ({"relative_dir": "tasks"}, {"path": "tasks"}, {"approved": True}):
            result = call_tool({"id": "x", "name": "read_task_cards", "arguments": args}, Tools())
            self.assertFalse(result["executed"])
            self.assertEqual(result["error"]["code"], "invalid_arguments")

    def test_reference_contract(self):
        tools = Tools()
        data = tools.read_task_cards()
        self.assertEqual(data["provenance"]["assigned_by"], "harness")
        self.assertEqual(data["provenance"]["trust"], "untrusted")
        self.assertEqual(data["count"], 3)
        self.assertTrue(validate_tool_arguments("validate_task_card", {"card": data["untrusted_content"][0]}))
        data["untrusted_content"][0]["title"] = "Подмена копии"
        for card in tools.cards:
            self.assertTrue(tools.validate_task_card(card["id"])["valid"])
        self.assertNotEqual(tools.cards[0]["title"], "Подмена копии")
        self.assertTrue(tools.build_status_report()["draft"])

    def test_cannot_build_before_validation(self):
        tools = Tools()
        with self.assertRaises(ToolDataError):
            tools.build_status_report()
        tools.read_task_cards()
        with self.assertRaises(ToolDataError):
            tools.build_status_report()
        with self.assertRaises(ToolDataError):
            tools.validate_task_card("task-absent")

    def test_unknown_tool_or_malformed_name(self):
        for name in ("__import__", "publish_report", ["read_task_cards"], None):
            result = call_tool({"name": name, "arguments": {}}, Tools())
            self.assertFalse(result["executed"])
            self.assertEqual(result["error"]["code"], "unknown_tool")

    def test_card_validation_four_statuses_no_self_trust(self):
        for status in ("planned", "in_progress", "blocked", "done"):
            card = {"id": "task-1", "title": "Учебная задача", "status": status}
            self.assertTrue(validate_card_data(card)["valid"])
            self.assertFalse(validate_card_data(dict(card, source_trust="trusted"))["valid"])
        self.assertFalse(validate_card_data({"id": "task-1", "title": "X", "status": []})["valid"])

    def test_same_read_error(self):
        result = call_tool({"id": "x", "name": "read_task_cards", "arguments": {}}, Tools(scenario="missing_file"))
        self.assertTrue(result["executed"])
        self.assertEqual(result["error"]["message"], "Ошибка: учебные карточки недоступны")

    def test_empty_cards_are_not_io_failure(self):
        with tempfile.TemporaryDirectory() as directory:
            (Path(directory) / "tasks").mkdir()
            self.assertEqual(Tools(directory).read_task_cards()["count"], 0)

    def test_card_symlink_cannot_escape(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory) / "workspace"
            (root / "tasks").mkdir(parents=True)
            outside = Path(directory) / "private.json"
            outside.write_text('{"id":"outside"}', encoding="utf-8")
            try:
                (root / "tasks/secret.json").symlink_to(outside)
            except (OSError, NotImplementedError):
                self.skipTest("symlinks unavailable")
            result = call_tool({"id": "x", "name": "read_task_cards", "arguments": {}}, Tools(root))
            self.assertEqual(result["error"]["code"], "outside_workspace")

    def test_repeated_read_clears_validation(self):
        tools = Tools()
        tools.read_task_cards()
        tools.validate_task_card("task-001")
        tools.read_task_cards()
        self.assertEqual(tools.validated, set())
