"""Ретрофит глав 1–13 (0.17.0): команды блоков «Достраиваем „Дежурного“» печатают свои golden.

Каждая группа запускается так, как её запускает ``tools/verify_chapter.py``:
команды подряд в поставке starter, фикстура кладётся перед командой и
удаляется после неё; после группы ``workspace/my_agent/`` восстанавливается
побайтно, новые файлы ``drafts/`` и ``traces/`` удаляются.
"""

import os
import subprocess
import sys
import unittest

from school_agent.paths import PROJECT_ROOT, WORKSPACE_ROOT

GOLDEN = PROJECT_ROOT / "tests" / "golden"
GOLDEN_DEZHURNY = PROJECT_ROOT / "tests" / "golden_dezhurny"
MY_AGENT = WORKSPACE_ROOT / "my_agent"
STUDENT_DIRS = (WORKSPACE_ROOT / "drafts", WORKSPACE_ROOT / "traces")
EXAMPLES = "workspace/my_agent/examples/"
VERSIONS = "workspace/ch13/cases/versions"
ENV = dict(os.environ, PYTHONUTF8="1", PYTHONIOENCODING="utf-8")


def fixture(chapter, name):
    return ("tests/fixtures/ch%02d/%s" % (chapter, name), "workspace/my_agent/" + name)


# Глава → команды блока по порядку: (golden, аргументы dezhurny.py, фикстура или None).
BLOCKS = {
    1: [("ch01_dezhurny_status_goal.txt", ("status", "--chapter", "1"), fixture(1, "01_goal.md")),
        ("ch01_dezhurny_run_goal.txt", ("run",), fixture(1, "01_goal.md"))],
    2: [("dezhurny_run_limit2.txt", ("run", "--dir", EXAMPLES + "limit2"), None)],
    3: [("dezhurny_run_denied.txt", ("run", "--dir", EXAMPLES + "denied"), None)],
    5: [("ch05_dezhurny_run_contract.txt", ("run",), fixture(5, "05_task_contract.md"))],
    7: [("ch07_dezhurny_run_tools.txt", ("run", "--dir", EXAMPLES + "tools"), None)],
    8: [("ch08_dezhurny_status_my_tool.txt", ("status", "--chapter", "8", "--dir", EXAMPLES + "ch08"), None),
        ("ch08_dezhurny_run_my_tool.txt", ("run", "--dir", EXAMPLES + "ch08"), None)],
    9: [("ch09_dezhurny_run_skill.txt", ("run", "--dir", EXAMPLES + "ch09"), None)],
    10: [("ch10_dezhurny_run_state_1.txt", ("run", "--dir", EXAMPLES + "ch10"), None),
         ("ch10_dezhurny_run_state_2.txt", ("run", "--dir", EXAMPLES + "ch10"), None)],
    11: [("dezhurny_eval_example.txt", ("eval", "--dir", EXAMPLES + "full"), None)],
    12: [("ch12_dezhurny_run_trace.txt", ("run",), fixture(12, "12_trace.json")),
         ("ch12_dezhurny_trace_last.txt", ("trace", "--last"), None)],
    13: [("ch13_dezhurny_version_save.txt", ("version", "save", "1.1.0", "--dir", VERSIONS), None),
         ("ch13_dezhurny_status_versions.txt", ("status", "--chapter", "13", "--dir", VERSIONS), None),
         ("ch13_dezhurny_version_compare.txt", ("version", "compare", "1.0.0", "1.1.0", "--dir", VERSIONS), None)],
}


def golden_path(name):
    return (GOLDEN_DEZHURNY if name.startswith("dezhurny_") else GOLDEN) / name


def _my_agent_snapshot():
    return {path.relative_to(MY_AGENT): path.read_bytes() for path in MY_AGENT.rglob("*") if path.is_file()}


def _student_snapshot():
    return {path for folder in STUDENT_DIRS if folder.is_dir() for path in folder.rglob("*")}


def _restore(my_agent_before, student_before):
    """Та же уборка, что у verify_chapter.py после главы."""

    for path in sorted(_student_snapshot() - student_before, key=lambda item: len(item.parts), reverse=True):
        if path.is_file():
            path.unlink()
        elif path.is_dir() and not any(path.iterdir()):
            path.rmdir()
    for path in sorted(MY_AGENT.rglob("*"), key=lambda item: len(item.parts), reverse=True):
        relative = path.relative_to(MY_AGENT)
        if path.is_file() and relative not in my_agent_before:
            path.unlink()
        elif path.is_dir() and not any(path.iterdir()) and not any(
                key.parts[:len(relative.parts)] == relative.parts for key in my_agent_before):
            path.rmdir()
    for relative, data in my_agent_before.items():
        target = MY_AGENT / relative
        if not target.is_file() or target.read_bytes() != data:
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(data)


def run_group(commands):
    """Команды блока подряд, как verify_chapter; [(код выхода, stdout, stderr)]."""

    my_agent_before, student_before = _my_agent_snapshot(), _student_snapshot()
    outputs = []
    try:
        for _, args, placed in commands:
            target = None
            if placed:
                source, target = PROJECT_ROOT / placed[0], PROJECT_ROOT / placed[1]
                if target.exists():
                    raise AssertionError("фикстура: целевой файл уже существует в поставке: " + placed[1])
                target.write_bytes(source.read_bytes())
            try:
                result = subprocess.run([sys.executable, "dezhurny.py", *args], cwd=PROJECT_ROOT,
                                        capture_output=True, env=ENV)
            finally:
                if target is not None:
                    target.unlink()
            outputs.append((result.returncode, result.stdout.decode("utf-8").replace("\r\n", "\n"),
                            result.stderr.decode("utf-8")))
    finally:
        _restore(my_agent_before, student_before)
    return outputs


class BlockOutputTests(unittest.TestCase):
    def test_every_block_prints_its_golden_and_leaves_the_delivery_clean(self):
        for chapter, commands in BLOCKS.items():
            with self.subTest(chapter=chapter):
                my_agent_before, student_before = _my_agent_snapshot(), _student_snapshot()
                outputs = run_group(commands)
                for (golden, args, _), (code, printed, errors) in zip(commands, outputs):
                    self.assertEqual((code, errors), (0, ""), args)
                    self.assertEqual(printed, golden_path(golden).read_text(encoding="utf-8"), golden)
                    self.assertNotIn(str(PROJECT_ROOT), printed)
                self.assertEqual(_my_agent_snapshot(), my_agent_before)
                self.assertEqual(_student_snapshot(), student_before)

    def test_chapters_4_and_6_have_no_commands(self):
        self.assertEqual(sorted(set(range(1, 14)) - set(BLOCKS)), [4, 6])

    def test_fixtures_are_student_files_missing_from_the_delivery(self):
        for commands in BLOCKS.values():
            for _, _, placed in commands:
                if placed:
                    with self.subTest(fixture=placed[0]):
                        self.assertTrue((PROJECT_ROOT / placed[0]).is_file())
                        self.assertFalse((PROJECT_ROOT / placed[1]).exists())


class OrderTests(unittest.TestCase):
    """Вердикт PLAN ретрофита, MINOR 5: порядок команд глав 10 и 12 обязателен."""

    def test_second_run_of_chapter_10_reads_the_first(self):
        first, second = run_group(BLOCKS[10])
        self.assertIn("state: первый запуск (запусков теперь: 1)", first[1])
        self.assertIn("state: предыдущий запуск — success, шагов 5 (запусков теперь: 2)", second[1])
        # По одному — каждый run видит только поставку: второй без первого снова «первый».
        alone = run_group(BLOCKS[10][1:])[0]
        self.assertIn("state: первый запуск (запусков теперь: 1)", alone[1])

    def test_trace_last_reads_the_trace_of_the_same_run(self):
        run, last = run_group(BLOCKS[12])
        written = [line for line in run[1].splitlines() if line.startswith("trace: ")]
        self.assertEqual(written, ["trace: workspace/traces/dezhurny/run-001.jsonl"])
        self.assertEqual(last[1].splitlines()[0], written[0])
        # Без run той же группы trace --last записанного запуска не находит.
        self.assertIn("нет записанных запусков", run_group(BLOCKS[12][1:])[0][1])


if __name__ == "__main__":
    unittest.main()
