"""Контракт главы 11: Eval считается по слоям, scripted не входит в оценку модели."""

import contextlib
import hashlib
import io
import json
import os
import re
import subprocess
import sys
import unittest
from unittest.mock import patch

from school_agent.evals import check_harness, run_eval_cases
from school_agent.paths import PROJECT_ROOT, WORKSPACE_ROOT
from school_agent.presentation import eval_main

GOLDEN = PROJECT_ROOT / "tests" / "golden"
# Golden блоков «Достраиваем „Дежурного“» (ретрофит глав 1–13, 0.17.0) в слепки прежних глав не входят.
RETROFIT_GOLDEN = re.compile(r"ch(0\d|1[0-3])_dezhurny_")
EVALS = PROJECT_ROOT / "workspace" / "evals"
# Слепок 70 эталонов глав 1–10: имя и SHA-256 каждого файла, по порядку имён.
OLD_GOLDEN_COUNT = 70
OLD_GOLDEN_DIGEST = "fe8cd6ff7be26c675d839b792c449cfaefab81657f3f4d2a95a4fbac41053c7d"


def load(name):
    return json.loads((EVALS / name).read_text(encoding="utf-8"))


def summary_of(result):
    """Три строки `--summary` по подставленному результату: текст и код выхода."""
    printed, code = io.StringIO(), None
    with patch("school_agent.evals.run_eval_cases", return_value=result):
        with contextlib.redirect_stdout(printed):
            try:
                eval_main(["--summary"])
            except SystemExit as stop:
                code = stop.code
    return printed.getvalue().splitlines(), code


class EvalRunnerGoldenTests(unittest.TestCase):
    def run_cli(self, *args):
        return subprocess.run([sys.executable, "eval_runner.py", *args], cwd=PROJECT_ROOT,
                              capture_output=True, env=dict(os.environ, PYTHONIOENCODING="utf-8"))

    def check_golden(self, golden, *args):
        result = self.run_cli(*args)
        self.assertEqual(result.returncode, 0)
        printed = result.stdout.decode("utf-8").replace("\r\n", "\n")
        self.assertEqual(printed, (GOLDEN / golden).read_text(encoding="utf-8"))
        self.assertEqual(result.stderr, b"")
        self.assertNotIn(str(PROJECT_ROOT), printed)
        return printed

    def test_stdout_matches_golden(self):
        self.check_golden("ch11_eval_runner.txt")

    def test_summary_matches_golden(self):
        printed = self.check_golden("ch11_eval_summary.txt", "--summary")
        self.assertEqual(len(printed.splitlines()), 3)

    def test_flag_changes_only_the_shape_of_the_same_result(self):
        full = json.loads(self.run_cli().stdout.decode("utf-8"))
        summary = self.run_cli("--summary").stdout.decode("utf-8").replace("\r\n", "\n")
        harness = full["harness"]
        self.assertIn(str(harness["passed"]) + "/" + str(harness["total"]) + " passed", summary)
        self.assertIn(full["model_behavior"]["status"], summary)
        self.assertIn(json.dumps(full["publication_ready"]), summary)
        for blocker in full["publication_blockers"]:
            with self.subTest(blocker=blocker):
                self.assertIn(blocker, summary)

    def test_golden_is_the_whole_answer_of_the_runner(self):
        golden = json.loads((GOLDEN / "ch11_eval_runner.txt").read_text(encoding="utf-8"))
        self.assertEqual(golden, run_eval_cases())


class ScoringLayersTests(unittest.TestCase):
    def setUp(self):
        self.result = run_eval_cases()

    def test_harness_is_counted_on_its_own_cases(self):
        harness = self.result["harness"]
        self.assertEqual(harness["total"], len(load("harness_cases.json")["cases"]))
        self.assertEqual(harness["passed"], harness["total"])
        self.assertEqual([row["id"] for row in harness["cases"]],
                         [case["id"] for case in load("harness_cases.json")["cases"]])

    def test_no_common_score_over_two_layers(self):
        for key in ("pass_rate", "passed", "total", "score", "percent"):
            with self.subTest(key=key):
                self.assertNotIn(key, self.result)
                self.assertNotIn(key, self.result["model_behavior"])

    def test_scripted_behavior_is_excluded_from_model_scoring(self):
        cases = self.result["model_behavior"]["cases"]
        self.assertEqual(len(cases), len(load("model_behavior_cases.json")["cases"]))
        for case in cases:
            with self.subTest(case=case["id"]):
                self.assertEqual(case["status"], "scripted")
                self.assertEqual(case["scoring"], "excluded")
                self.assertFalse(case["model_quality_verified"])

    def test_missing_live_evidence_is_neither_zero_nor_success(self):
        behavior = self.result["model_behavior"]
        self.assertEqual(behavior["status"], "not_evaluated")
        self.assertEqual(behavior["verified_sessions"], 0)
        self.assertEqual(self.result["model_quality_gate"],
                         "pending_verified_live_evidence_and_review")
        # Три сценария не попадают ни в числитель, ни в знаменатель harness.
        self.assertEqual(self.result["harness"]["total"],
                         len(load("harness_cases.json")["cases"]))

    def test_publication_ready_stays_false_while_external_blockers_are_open(self):
        self.assertFalse(self.result["publication_ready"])
        self.assertEqual(self.result["publication_blockers"],
                         ["classroom_pilot_pending", "live_model_evidence_pending"])


class SummaryIsComputedTests(unittest.TestCase):
    """Три строки считаются из результата, а не напечатаны константой."""

    def test_failed_harness_case_changes_the_count(self):
        result = run_eval_cases()
        result["harness"] = dict(result["harness"], passed=5)
        lines, code = summary_of(result)
        self.assertEqual(lines[0], "harness: 5/6 passed")
        self.assertEqual(code, 1)

    def test_scripted_count_follows_the_cases(self):
        result = run_eval_cases()
        cases = [dict(result["model_behavior"]["cases"][0], status="verified")]
        cases += result["model_behavior"]["cases"][1:]
        result["model_behavior"] = dict(result["model_behavior"], cases=cases)
        lines, _ = summary_of(result)
        self.assertEqual(lines[1], "model_behavior: not_evaluated"
                                   " (verified_sessions: 0; scripted: 2, excluded from scoring)")

    def test_publication_line_drops_brackets_without_blockers(self):
        result = dict(run_eval_cases(), publication_ready=True, publication_blockers=[])
        lines, code = summary_of(result)
        self.assertEqual(lines[2], "publication_ready: true")
        self.assertEqual(code, 0)


class CaseDataTests(unittest.TestCase):
    def test_index_points_at_the_files_the_runner_reads(self):
        index = load("test_cases.json")
        self.assertEqual(index["harness"], "harness_cases.json")
        self.assertEqual(index["model_behavior"], "model_behavior_cases.json")
        source = (PROJECT_ROOT / "school_agent" / "evals.py").read_text(encoding="utf-8")
        for name in (index["harness"], index["model_behavior"]):
            with self.subTest(name=name):
                self.assertTrue((EVALS / name).is_file())
                self.assertIn(name, source)

    def test_index_holds_no_cases_of_its_own(self):
        index = load("test_cases.json")
        self.assertNotIn("cases", index)
        self.assertEqual({path.name for path in EVALS.iterdir()},
                         {"test_cases.json", "harness_cases.json", "model_behavior_cases.json"})

    def test_every_case_carries_an_observable_expectation(self):
        for case in load("harness_cases.json")["cases"]:
            with self.subTest(case=case["id"]):
                self.assertTrue(case["invariant"].strip())
        for case in load("model_behavior_cases.json")["cases"]:
            with self.subTest(case=case["id"]):
                self.assertTrue(case["expected_terminal"].strip())
                self.assertTrue(case["real_run_acceptance"].strip())

    def test_case_without_expected_behavior_is_not_reported_as_passed(self):
        with self.assertRaises(ValueError):
            check_harness("no_expected_behavior", WORKSPACE_ROOT)


class RegressionSnapshot(unittest.TestCase):
    def test_old_golden_untouched_and_two_new(self):
        # Эталоны следующих глав в слепок главы 11 не входят (как в тесте главы 10).
        names = sorted(path.name for path in GOLDEN.iterdir() if not RETROFIT_GOLDEN.match(path.name)
                       if not re.match(r"ch1[2-9]_", path.name))
        new = [name for name in names if name.startswith("ch11_")]
        old = [name for name in names if not name.startswith("ch11_")]
        self.assertEqual(new, ["ch11_eval_runner.txt", "ch11_eval_summary.txt"])
        self.assertEqual(len(old), OLD_GOLDEN_COUNT)
        digest = hashlib.sha256()
        for name in old:
            digest.update(name.encode("utf-8"))
            digest.update(hashlib.sha256((GOLDEN / name).read_bytes()).digest())
        self.assertEqual(digest.hexdigest(), OLD_GOLDEN_DIGEST)


if __name__ == "__main__":
    unittest.main()
