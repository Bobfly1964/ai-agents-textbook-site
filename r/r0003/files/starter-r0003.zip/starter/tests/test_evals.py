import unittest
from school_agent.evals import run_eval_cases

class EvalTests(unittest.TestCase):
    def test_harness_is_separate_from_behavior(self):
        result = run_eval_cases()
        self.assertEqual(result["harness"]["passed"], result["harness"]["total"])
        self.assertGreater(result["harness"]["total"], 0)
        self.assertEqual(result["model_behavior"]["status"], "not_evaluated")
        self.assertEqual(result["model_behavior"]["verified_sessions"], 0)
        self.assertFalse(result["publication_ready"])
        self.assertNotIn("canonical_chapters_01_02_not_supplied", result["publication_blockers"])
        self.assertNotIn("regulation_05_not_supplied", result["publication_blockers"])
        self.assertNotIn("chapters_01_02_candidate_editorial_acceptance_pending", result["publication_blockers"])
        self.assertNotIn("regulation_05_amendment_owner_acceptance_pending", result["publication_blockers"])
        self.assertEqual(result["publication_blockers"],
                         ["classroom_pilot_pending", "live_model_evidence_pending"])
        self.assertNotIn("pass_rate", result)
        self.assertNotIn("behavior_gate_passed", result)
        for case in result["model_behavior"]["cases"]:
            self.assertEqual(case["status"], "scripted")
            self.assertEqual(case["scoring"], "excluded")
            self.assertTrue(case["script_contract_matches"])
