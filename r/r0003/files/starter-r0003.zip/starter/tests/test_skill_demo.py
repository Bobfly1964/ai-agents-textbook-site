"""Контракт главы 9: слои Agent Skill через единственный загрузчик, scripts не запускаются."""

import hashlib
import os
import re
import subprocess
import sys
import unittest
from contextlib import redirect_stdout
from io import StringIO
from unittest import mock

import skill_demo
from school_agent import skill_loader
from school_agent.agent import run_replay_scenario
from school_agent.paths import PROJECT_ROOT

GOLDEN = PROJECT_ROOT / "tests" / "golden"
# Golden блоков «Достраиваем „Дежурного“» (ретрофит глав 1–13, 0.17.0) в слепки прежних глав не входят.
RETROFIT_GOLDEN = re.compile(r"ch(0\d|1[0-3])_dezhurny_")
CASES = "workspace/ch09/cases/"
MARKER = PROJECT_ROOT / "workspace" / "ch09" / "cases" / "script-present" / "scripts" / "EXECUTED.marker"
# Слепок 56 эталонов глав 1–8: имя и SHA-256 каждого файла, по порядку имён.
OLD_GOLDEN_COUNT = 56
OLD_GOLDEN_DIGEST = "5cecd58f7413985c3148af0cff98fb8facea7a7efeaf3fed21195e067db4bc4c"


def run_cli(*args):
    return subprocess.run(
        [sys.executable, "skill_demo.py", *args],
        cwd=PROJECT_ROOT,
        capture_output=True,
        env=dict(os.environ, PYTHONIOENCODING="utf-8"),
    )


def spied(*names):
    """Считать вызовы функций загрузчика, не меняя их поведения."""

    return [mock.patch.object(skill_demo, name, wraps=getattr(skill_loader, name))
            for name in names]


class GoldenTests(unittest.TestCase):
    def check_output(self, golden, *args):
        result = run_cli(*args)
        self.assertEqual(result.returncode, 0)
        expected = (GOLDEN / golden).read_text(encoding="utf-8")
        printed = result.stdout.decode("utf-8").replace("\r\n", "\n")
        self.assertEqual(printed, expected)
        self.assertEqual(result.stderr, b"")
        self.assertNotIn("Traceback", printed)
        self.assertNotIn(str(PROJECT_ROOT), printed)
        return printed

    def test_catalog_matches_golden(self):
        printed = self.check_output("ch09_skill_catalog.txt", "catalog")
        self.assertIn("skill: project-status", printed)
        self.assertNotIn("## Процедура", printed)
        self.assertNotIn("Шаблон статус-отчёта", printed)

    def test_load_matches_golden(self):
        printed = self.check_output("ch09_skill_load.txt", "load", "project-status")
        self.assertIn("scripts/validate_cards.py (scripts)", printed)
        self.assertIn("scripts executed: no", printed)

    def test_resource_matches_golden(self):
        printed = self.check_output("ch09_skill_resource.txt", "resource", "project-status",
                                    "references/report-template.md")
        self.assertIn("resource: references/report-template.md", printed)

    def test_check_valid_matches_golden(self):
        printed = self.check_output("ch09_skill_check_valid.txt", "check",
                                    CASES + "project-status-valid")
        self.assertTrue(printed.endswith("result: accepted\n"))

    def test_function_only_is_not_skill(self):
        printed = self.check_output("ch09_skill_check_function_only.txt", "check",
                                    CASES + "function-only")
        self.assertIn("SKILL.md: missing", printed)
        self.assertIn("result: not accepted", printed)

    def test_bad_frontmatter_matches_golden(self):
        printed = self.check_output("ch09_skill_check_bad_frontmatter.txt", "check",
                                    CASES + "bad-frontmatter")
        self.assertIn("reason: SKILL.md должен начинаться с YAML frontmatter", printed)

    def test_script_present_matches_golden(self):
        printed = self.check_output("ch09_skill_check_script_present.txt", "check",
                                    CASES + "script-present")
        self.assertIn("scripts/check.py (scripts)", printed)
        self.assertIn("scripts executed: no", printed)

    def test_replay_skill_requests_match_golden(self):
        printed = self.check_output("ch09_skill_replay.txt", "replay")
        self.assertIn("origin: synthetic_script — авторский сценарий, не запись модели", printed)
        self.assertIn("model quality verified: no", printed)


class ProgressiveDisclosureTests(unittest.TestCase):
    def run_main(self, *argv):
        patches = spied("discover_skills", "load_skill", "read_skill_resource")
        mocks = [patch.start() for patch in patches]
        try:
            with redirect_stdout(StringIO()):
                skill_demo.main(list(argv))
        finally:
            for patch in patches:
                patch.stop()
        return dict(zip(("discover", "load", "resource"), mocks))

    def test_catalog_reads_no_instructions(self):
        calls = self.run_main("catalog")
        self.assertEqual(calls["discover"].call_count, 1)
        calls["load"].assert_not_called()
        calls["resource"].assert_not_called()

    def test_load_reads_no_resource(self):
        calls = self.run_main("load", "project-status")
        self.assertEqual(calls["load"].call_count, 1)
        calls["resource"].assert_not_called()

    def test_resource_reads_only_requested_path(self):
        calls = self.run_main("resource", "project-status", "references/report-template.md")
        calls["resource"].assert_called_once_with(
            skill_demo.SKILLS_ROOT, "project-status", "references/report-template.md")
        calls["load"].assert_not_called()


class SkillStructureTests(unittest.TestCase):
    def test_optional_folders_are_not_required(self):
        folders = {path.name for path in (PROJECT_ROOT / "workspace" / "ch09" / "cases"
                                          / "project-status-valid").iterdir() if path.is_dir()}
        self.assertEqual(folders, {"references"})
        self.assertEqual(run_cli("check", CASES + "project-status-valid").returncode, 0)

    def test_missing_draft_is_not_accepted_with_hint(self):
        printed = run_cli("check", "workspace/drafts/ch09/project-status").stdout.decode("utf-8")
        self.assertIn("result: not accepted", printed)
        self.assertIn("workspace/ch09/templates/project-status/", printed)
        self.assertFalse((PROJECT_ROOT / "workspace" / "drafts" / "ch09").exists())

    def test_templates_are_not_skills_yet(self):
        templates = PROJECT_ROOT / "workspace" / "ch09" / "templates"
        self.assertEqual(list(templates.rglob("SKILL.md")), [])
        personal = (templates / "personal-study-skill" / "SKILL.template.md").read_text(encoding="utf-8")
        for line in ("- должен:", "- не должен:", "- ошибка:"):
            self.assertIn(line, personal)

    def test_single_loader(self):
        source = (PROJECT_ROOT / "skill_demo.py").read_text(encoding="utf-8")
        for token in ("yaml", "_split_skill_file", "split(\"---\")", "frontmatter ="):
            with self.subTest(token=token):
                self.assertNotIn(token, source)


class ScriptBoundaryTests(unittest.TestCase):
    def test_script_is_listed_but_not_executed(self):
        if MARKER.exists():
            MARKER.unlink()
        for argv in (["check", CASES + "script-present"], ["load", "project-status"]):
            with self.subTest(argv=argv):
                with mock.patch("subprocess.run") as run, mock.patch("subprocess.Popen") as popen:
                    with redirect_stdout(StringIO()):
                        skill_demo.main(argv)
                run.assert_not_called()
                popen.assert_not_called()
        self.assertFalse(MARKER.exists())

    def test_marker_works_when_really_run(self):
        """Контроль: маркер действительно появляется при запуске, значит его отсутствие что-то доказывает."""

        try:
            subprocess.run([sys.executable, str(MARKER.parent / "check.py")], check=True)
            self.assertTrue(MARKER.exists())
        finally:
            if MARKER.exists():
                MARKER.unlink()

    def test_demo_has_no_execution_path(self):
        source = (PROJECT_ROOT / "skill_demo.py").read_text(encoding="utf-8")
        for token in ("subprocess", "exec(", "eval(", "importlib", "runpy", "__import__"):
            with self.subTest(token=token):
                self.assertNotIn(token, source)

    def test_scripts_cannot_be_read_as_resource(self):
        result = run_cli("resource", "project-status", "scripts/validate_cards.py")
        self.assertEqual(result.returncode, 2)
        self.assertEqual(result.stdout, b"")


class WorkspaceBoundaryTests(unittest.TestCase):
    def test_check_rejects_paths_outside_workspace(self):
        for raw in ("/etc", "../outside", "workspace/../README.md", "workspace/ch09/../../skills",
                    "skills/project-status"):
            with self.subTest(path=raw):
                result = run_cli("check", raw)
                self.assertEqual(result.returncode, 2)
                self.assertEqual(result.stdout, b"")
                self.assertNotIn(b"Traceback", result.stderr)


class ReplaySkillTests(unittest.TestCase):
    def test_requests_precede_loading(self):
        result = run_replay_scenario("success")
        kinds = []
        for event in result["trace"]:
            if event["type"] == "model_response":
                kind = event["payload"]["response"]["type"]
                if kind in ("load_skill", "read_skill_resource"):
                    kinds.append(kind)
            elif event["type"] in ("skill_loaded", "skill_resource_loaded"):
                kinds.append(event["type"])
        self.assertEqual(kinds, ["load_skill", "skill_loaded",
                                 "read_skill_resource", "skill_resource_loaded"])
        self.assertEqual(result["state"]["context_requests"], 2)
        self.assertEqual(result["evidence_kind"], "synthetic_script")
        self.assertFalse(result["model_quality_verified"])


class RegressionSnapshot(unittest.TestCase):
    def test_old_golden_untouched_and_eight_new(self):
        names = sorted(path.name for path in GOLDEN.iterdir() if not RETROFIT_GOLDEN.match(path.name)
                       if not re.match(r"ch1\d_", path.name))
        new = [name for name in names if name.startswith("ch09_")]
        old = [name for name in names if not name.startswith("ch09_")]
        self.assertEqual(len(new), 8)
        self.assertEqual(len(old), OLD_GOLDEN_COUNT)
        digest = hashlib.sha256()
        for name in old:
            digest.update(name.encode("utf-8"))
            digest.update(hashlib.sha256((GOLDEN / name).read_bytes()).digest())
        self.assertEqual(digest.hexdigest(), OLD_GOLDEN_DIGEST)


if __name__ == "__main__":
    unittest.main()
