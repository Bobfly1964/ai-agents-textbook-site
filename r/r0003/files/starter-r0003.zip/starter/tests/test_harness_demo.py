"""Контракт выделенного harness главы 3."""

import os
import subprocess
import sys
import unittest
from pathlib import Path

from harness_demo import run_harness
from loop_demo import run_loop
from school_agent.paths import PROJECT_ROOT


GOLDEN = PROJECT_ROOT / "tests" / "golden"
SCENARIOS = (
    "one_match",
    "two_matches",
    "temporary_error",
    "permanent_error",
    "limit",
    "missing_file",
    "no_matches",
)


class HarnessDemoTests(unittest.TestCase):
    def check_output(self, golden, *args):
        result = subprocess.run(
            [sys.executable, *args],
            cwd=PROJECT_ROOT,
            capture_output=True,
            text=True,
            encoding="utf-8",
            env=dict(os.environ, PYTHONIOENCODING="utf-8"),
            check=True,
        )
        expected = (GOLDEN / golden).read_text(encoding="utf-8")
        self.assertEqual(result.stdout.replace("\r\n", "\n"), expected)
        self.assertEqual(result.stderr, "")

    def test_parts_match_golden(self):
        self.check_output("harness_parts.txt", "harness_demo.py", "--show-parts")

    def test_one_match_matches_golden(self):
        self.check_output(
            "harness_one_match.txt",
            "harness_demo.py",
            "--scenario",
            "one_match",
        )

    def test_harness_matches_loop_for_every_existing_scenario(self):
        for scenario in SCENARIOS:
            with self.subTest(scenario=scenario):
                self.assertEqual(run_harness(scenario), run_loop(scenario))


if __name__ == "__main__":
    unittest.main()
