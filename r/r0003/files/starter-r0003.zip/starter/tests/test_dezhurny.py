"""Контракт конструктора «Дежурного» (EC-24): my_agent/ наблюдаемо меняет поведение существующего harness."""

import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

import dezhurny
from school_agent.agent import _skill_root_for, run_agent, run_replay_scenario
from school_agent.my_agent_config import (
    FILES, RESERVED, HarnessProfile, build_profile, read_my_agent,
)
from school_agent.paths import PROJECT_ROOT, WORKSPACE_ROOT
from school_agent.skill_loader import SkillFormatError, load_skill
from school_agent.trace_analysis import build_incident_report

GOLDEN = PROJECT_ROOT / "tests" / "golden_dezhurny"
# Golden блоков «Достраиваем „Дежурного“» (ретрофит глав 1–13, 0.17.0) в слепки прежних глав не входят.
RETROFIT_GOLDEN = re.compile(r"ch(0\d|1[0-3])_dezhurny_")
OLD_GOLDEN = PROJECT_ROOT / "tests" / "golden"
EXAMPLES = "my_agent/examples/"
FULL = WORKSPACE_ROOT / "my_agent" / "examples" / "full"
# Слепок 84 эталонов глав 1–13: конструктор не меняет ни одного прежнего вывода.
OLD_GOLDEN_COUNT = 84
OLD_GOLDEN_DIGEST = "8b9f03584a1e6057c76123a861ad5e380cb608e88e6433bb1c16b2b7d21601b5"


def run_cli(*args):
    return subprocess.run([sys.executable, "dezhurny.py", *args], cwd=PROJECT_ROOT,
                          capture_output=True, env=dict(os.environ, PYTHONIOENCODING="utf-8"))


def temp_workspace(test):
    directory = tempfile.mkdtemp()
    test.addCleanup(shutil.rmtree, directory)
    workspace = Path(directory) / "workspace"
    shutil.copytree(WORKSPACE_ROOT, workspace)
    return workspace


def configure(workspace, *names):
    """Скопировать файлы полного примера в рабочую папку my_agent/ временного workspace."""

    for name in names:
        source = FULL / name
        target = workspace / "my_agent" / name
        if source.is_dir():
            shutil.copytree(source, target)
        else:
            shutil.copyfile(source, target)


class RecordingAdapter:
    """Модель-заглушка: запоминает контекст и отвечает по заранее заданному списку."""

    kind = "replay"

    def __init__(self, responses):
        self.responses = list(responses)
        self.contexts = []

    def next(self, context):
        self.contexts.append(context)
        return self.responses.pop(0)


class GoldenTests(unittest.TestCase):
    def check_output(self, golden, *args):
        result = run_cli(*args)
        self.assertEqual(result.returncode, 0, result.stderr.decode("utf-8"))
        printed = result.stdout.decode("utf-8").replace("\r\n", "\n")
        self.assertEqual(printed, (GOLDEN / golden).read_text(encoding="utf-8"))
        self.assertEqual(result.stderr, b"")
        self.assertNotIn(str(PROJECT_ROOT), printed)
        return printed

    def test_six_outputs(self):
        runs = {
            "dezhurny_status_empty.txt": ("status",),
            "dezhurny_status_example.txt": ("status", "--dir", "workspace/" + EXAMPLES + "full"),
            "dezhurny_run_default.txt": ("run",),
            "dezhurny_run_limit2.txt": ("run", "--dir", "workspace/" + EXAMPLES + "limit2"),
            "dezhurny_run_denied.txt": ("run", "--dir", "workspace/" + EXAMPLES + "denied"),
            "dezhurny_eval_example.txt": ("eval", "--dir", "workspace/" + EXAMPLES + "full"),
        }
        for golden, args in runs.items():
            with self.subTest(golden=golden):
                self.check_output(golden, *args)

    def test_empty_status_names_every_chapter(self):
        printed = (GOLDEN / "dezhurny_status_empty.txt").read_text(encoding="utf-8")
        for name, chapter, _ in FILES:
            with self.subTest(file=name):
                self.assertIn("глава %d | %s | не настроено" % (chapter, name), printed)
        self.assertIn("configured: 0/15", printed)

    def test_status_json_is_opt_in(self):
        result = run_cli("status", "--json")
        document = json.loads(result.stdout.decode("utf-8"))
        self.assertEqual((document["configured"], document["total"]), (0, 15))
        self.assertEqual(len(document["rows"]), len(FILES))


class DefaultEquivalenceTests(unittest.TestCase):
    def test_empty_config_runs_like_agent_demo_success(self):
        workspace = temp_workspace(self)
        lines = dezhurny.cmd_run(workspace_root=workspace)
        demo = subprocess.run([sys.executable, "agent_demo.py", "--scenario", "success"], cwd=PROJECT_ROOT,
                              capture_output=True, env=dict(os.environ, PYTHONIOENCODING="utf-8"))
        expected = demo.stdout.decode("utf-8").replace("\r\n", "\n").split("\n")[1:-2]
        start = lines.index("Шаг 1 | read_task_cards | continue")
        self.assertEqual(lines[start:start + len(expected)], expected)
        self.assertIsNone(build_profile(read_my_agent(workspace_root=workspace)))

    def test_profile_none_keeps_the_trace_payloads(self):
        plain = run_replay_scenario("success")
        with_none = run_replay_scenario("success", profile=None)
        self.assertEqual([event["payload"] for event in plain["trace"]],
                         [event["payload"] for event in with_none["trace"]])


class EachFileChangesBehaviourTests(unittest.TestCase):
    def default_run(self, workspace):
        return dezhurny.cmd_run(workspace_root=workspace)

    def test_goal_is_quoted(self):
        workspace = temp_workspace(self)
        configure(workspace, "01_goal.md")
        self.assertIn("goal: Готовить черновик статуса проекта бюро по проверенным карточкам",
                      self.default_run(workspace))

    def test_stop_policy_limits_steps(self):
        workspace = temp_workspace(self)
        (workspace / "my_agent" / "02_stop_policy.json").write_text('{"max_steps": 3}', encoding="utf-8")
        lines = self.default_run(workspace)
        self.assertIn("Остановка: limit", lines)
        self.assertIn("Шаг 3 | validate_task_card | limit", lines)

    def test_workspace_policy_saves_only_inside_its_area(self):
        workspace = temp_workspace(self)
        configure(workspace, "03_workspace_policy.json")
        self.assertIn("save: allowed | inside_writable_prefix | drafts/dezhurny_report.md",
                      self.default_run(workspace))
        self.assertTrue((workspace / "drafts" / "dezhurny_report.md").is_file())
        (workspace / "my_agent" / "03_workspace_policy.json").write_text(
            '{"allowed_operations": ["read"], "writable_prefix": "drafts/"}', encoding="utf-8")
        self.assertIn("save: denied | operation_not_allowed | drafts/dezhurny_report.md",
                      self.default_run(workspace))

    def test_denied_save_writes_nothing(self):
        workspace = temp_workspace(self)
        shutil.copyfile(WORKSPACE_ROOT / EXAMPLES / "denied" / "03_workspace_policy.json",
                        workspace / "my_agent" / "03_workspace_policy.json")
        before = sorted(path.name for path in (workspace / "tasks").iterdir())
        self.default_run(workspace)
        self.assertEqual(sorted(path.name for path in (workspace / "tasks").iterdir()), before)

    def test_policy_cannot_widen_the_chapter_3_area(self):
        workspace = temp_workspace(self)
        (workspace / "my_agent" / "03_workspace_policy.json").write_text(
            '{"allowed_operations": ["read", "write"], "writable_prefix": "tasks/"}', encoding="utf-8")
        status = "\n".join(dezhurny.cmd_status(workspace_root=workspace))
        self.assertIn("ошибка: 03_workspace_policy.json: writable_prefix должен лежать внутри drafts/", status)
        with self.assertRaises(ValueError):
            self.default_run(workspace)

    def test_contract_ok_and_violated(self):
        workspace = temp_workspace(self)
        configure(workspace, "05_task_contract.md")
        self.assertIn("contract: ok", self.default_run(workspace))
        path = workspace / "my_agent" / "05_task_contract.md"
        path.write_text(path.read_text(encoding="utf-8").replace("- Всего задач:", "- Отчёт отправлен"),
                        encoding="utf-8")
        self.assertIn("contract: violated — нет: Отчёт отправлен", self.default_run(workspace))

    def test_tools_allowlist_rejects_before_dispatcher(self):
        workspace = temp_workspace(self)
        shutil.copyfile(WORKSPACE_ROOT / EXAMPLES / "tools" / "07_tools.json",
                        workspace / "my_agent" / "07_tools.json")
        lines = self.default_run(workspace)
        self.assertIn("Отклонено: validate_task_card | нет в 07_tools.json", lines)
        self.assertIn("Остановка: error", lines)
        profile = build_profile(read_my_agent(workspace_root=workspace))
        result = run_replay_scenario("success", workspace_root=workspace, profile=profile)
        self.assertEqual(result["executed_tools"], ["read_task_cards"])
        report = build_incident_report(result["trace"])
        self.assertEqual(report["root_cause"], "not_in_profile_allowlist")

    def test_unknown_tool_in_allowlist_is_a_config_error(self):
        workspace = temp_workspace(self)
        (workspace / "my_agent" / "07_tools.json").write_text('{"enabled": ["publish_report"]}', encoding="utf-8")
        self.assertIn("ошибка: 07_tools.json: неизвестный tool publish_report",
                      "\n".join(dezhurny.cmd_status(workspace_root=workspace)))

    def test_state_second_run_sees_the_first(self):
        workspace = temp_workspace(self)
        (workspace / "my_agent" / "10_state.json").write_text("{}", encoding="utf-8")
        self.assertIn("state: первый запуск (запусков теперь: 1)", self.default_run(workspace))
        self.assertIn("state: предыдущий запуск — success, шагов 5 (запусков теперь: 2)",
                      self.default_run(workspace))

    def test_evals_run_the_students_cases(self):
        workspace = temp_workspace(self)
        configure(workspace, "11_evals.json", "02_stop_policy.json")
        (workspace / "my_agent" / "02_stop_policy.json").write_text('{"max_steps": 2}', encoding="utf-8")
        lines = dezhurny.cmd_eval(workspace_root=workspace)
        # Тот же случай с пределом двух шагов падает: eval проверяет настройки, а не модель.
        self.assertIn("case report-on-clean-cards: scenario success | expected success | actual limit | fail",
                      lines)

    def test_trace_is_recorded_and_read_back(self):
        workspace = temp_workspace(self)
        configure(workspace, "12_trace.json")
        self.assertEqual(dezhurny.cmd_trace_last(workspace_root=workspace)[0],
                         "trace: нет записанных запусков — включи 12_trace.json (глава 12)")
        self.assertIn("trace: workspace/traces/dezhurny/run-001.jsonl", self.default_run(workspace))
        self.assertIn("trace: workspace/traces/dezhurny/run-002.jsonl", self.default_run(workspace))
        self.assertEqual(dezhurny.cmd_trace_last(workspace_root=workspace)[:2],
                         ["trace: workspace/traces/dezhurny/run-002.jsonl", "terminal: success"])

    def test_versions_row_is_read_since_0_17_0(self):
        # Строка 13 больше не зарезервирована (ретрофит главы 13): лишний файл — ошибка и стоп run.
        workspace = temp_workspace(self)
        self.assertIn("глава 13 | 13_versions | не настроено | version save сохраняет снимок конфигурации",
                      dezhurny.cmd_status(workspace_root=workspace))
        self.assertEqual(RESERVED, set())
        (workspace / "my_agent" / "13_versions").mkdir()
        (workspace / "my_agent" / "13_versions" / "notes.json").write_text("не JSON", encoding="utf-8")
        status = "\n".join(dezhurny.cmd_status(workspace_root=workspace))
        self.assertIn("глава 13 | 13_versions | ошибка: 13_versions: лишний файл notes.json", status)
        with self.assertRaises(ValueError):
            self.default_run(workspace)


class MyToolTests(unittest.TestCase):
    def profile(self, workspace):
        return build_profile(read_my_agent(workspace_root=workspace))

    def test_tool_without_allowlist_is_not_registered(self):
        workspace = temp_workspace(self)
        configure(workspace, "08_my_tool.py")
        # Без 07_tools.json tool ученика ни на что не влияет: профиля нет, цикл прежний.
        self.assertIsNone(self.profile(workspace))
        (workspace / "my_agent" / "07_tools.json").write_text('{"enabled": ["read_task_cards"]}', encoding="utf-8")
        self.assertEqual(self.profile(workspace).extra_tools, ())
        self.assertIn("в каталоге: нет, имени нет в 07_tools.json",
                      "\n".join(dezhurny.cmd_status(workspace_root=workspace)))

    def test_allowlisted_tool_appears_in_the_model_catalog(self):
        workspace = temp_workspace(self)
        configure(workspace, "08_my_tool.py", "07_tools.json")
        adapter = RecordingAdapter([{"type": "text", "text": "Стоп."}])
        run_agent(adapter, workspace_root=workspace, profile=self.profile(workspace))
        catalog = {tool["name"]: tool for tool in adapter.contexts[0]["tool_catalog"]}
        self.assertIn("count_open_tasks", catalog)
        self.assertEqual(catalog["count_open_tasks"]["access"], "not-executable")
        self.assertNotIn("propose_status_update", catalog)

    def test_student_code_is_never_executed(self):
        workspace = temp_workspace(self)
        marker = workspace / "drafts" / "executed.txt"
        (workspace / "my_agent" / "08_my_tool.py").write_text(
            "open(" + repr(str(marker)) + ", 'w').write('x')\n\n"
            "def count_open_tasks(cards):\n    \"\"\"Описание.\"\"\"\n    return 0\n", encoding="utf-8")
        (workspace / "my_agent" / "07_tools.json").write_text('{"enabled": ["count_open_tasks"]}', encoding="utf-8")
        dezhurny.cmd_status(workspace_root=workspace)
        self.assertIn("Отклонено: read_task_cards | нет в 07_tools.json", dezhurny.cmd_run(workspace_root=workspace))
        self.assertFalse(marker.exists())


class SkillTests(unittest.TestCase):
    def test_student_skill_three_layers(self):
        workspace = temp_workspace(self)
        configure(workspace, "09_skills")
        layers = dezhurny.skill_layers(workspace_root=workspace)
        self.assertEqual([layer["catalog"]["name"] for layer in layers], ["lesson-notes"])
        self.assertIn("Выдели три главные мысли.", layers[0]["instructions"])
        self.assertEqual(layers[0]["files"], [{"path": "references/format.md", "kind": "references"}])

    def test_model_sees_and_loads_the_student_skill_through_run_agent(self):
        workspace = temp_workspace(self)
        configure(workspace, "09_skills")
        profile = build_profile(read_my_agent(workspace_root=workspace))
        adapter = RecordingAdapter([
            {"type": "load_skill", "name": "lesson-notes"},
            {"type": "read_skill_resource", "name": "lesson-notes", "path": "references/format.md"},
            {"type": "text", "text": "Конспект готов к проверке."},
        ])
        result = run_agent(adapter, workspace_root=workspace, profile=profile)
        names = [skill["name"] for skill in adapter.contexts[0]["skill_catalog"]]
        self.assertEqual(names, ["project-status", "lesson-notes"])
        self.assertIn("lesson-notes", adapter.contexts[1]["active_skills"])
        self.assertIn("lesson-notes/references/format.md", adapter.contexts[2]["skill_resources"])
        self.assertEqual([event["type"] for event in result["trace"] if "skill" in event["type"]],
                         ["skill_loaded", "skill_resource_loaded"])

    def test_student_skill_cannot_shadow_the_project_skill(self):
        workspace = temp_workspace(self)
        skill = workspace / "my_agent" / "09_skills" / "project-status"
        shutil.copytree(PROJECT_ROOT / "skills" / "project-status", skill)
        self.assertIn("ошибка: 09_skills: имя project-status уже есть у skill проекта",
                      "\n".join(dezhurny.cmd_status(workspace_root=workspace)))


class BoundaryAndErrorTests(unittest.TestCase):
    def test_bad_json_is_a_readable_error_without_traceback(self):
        workspace = temp_workspace(self)
        (workspace / "my_agent" / "02_stop_policy.json").write_text("{max_steps: 2}", encoding="utf-8")
        self.assertIn("глава 2 | 02_stop_policy.json | ошибка: 02_stop_policy.json: не JSON",
                      "\n".join(dezhurny.cmd_status(workspace_root=workspace)))
        with self.assertRaises(ValueError):
            dezhurny.cmd_run(workspace_root=workspace)

    def test_cli_rejects_config_outside_workspace(self):
        for raw in ("my_agent", "workspace/../skills", "../workspace/my_agent"):
            with self.subTest(path=raw):
                result = run_cli("status", "--dir", raw)
                self.assertEqual(result.returncode, 2)
                self.assertEqual(result.stdout, b"")
                self.assertNotIn(b"Traceback", result.stderr)

    def test_bridge_only_with_success(self):
        with self.assertRaises(ValueError):
            dezhurny.cmd_run(scenario="needs_input", model="bridge")

    def test_unknown_files_are_reported(self):
        workspace = temp_workspace(self)
        (workspace / "my_agent" / "02_stop_policy.txt").write_text("5", encoding="utf-8")
        self.assertIn("не распознано: 02_stop_policy.txt",
                      dezhurny.cmd_status(workspace_root=workspace))

    def test_shipped_my_agent_holds_no_active_file(self):
        names = {entry.name for entry in (WORKSPACE_ROOT / "my_agent").iterdir()}
        self.assertEqual(names, {"README.md", "templates", "examples"})

    def test_templates_cover_every_non_reserved_file(self):
        templates = {entry.name for entry in (WORKSPACE_ROOT / "my_agent" / "templates").iterdir()}
        self.assertEqual(templates, {name for name, _, _ in FILES if name not in RESERVED})


class AcceptanceFixesTests(unittest.TestCase):
    """Правки приёмки EC-24 (вердикт C3, C4)."""

    def test_plural_forms(self):
        expected = {1: "пункт", 2: "пункта", 5: "пунктов", 11: "пунктов", 12: "пунктов",
                    21: "пункт", 22: "пункта", 25: "пунктов"}
        for number, word in expected.items():
            with self.subTest(number=number):
                self.assertEqual(dezhurny._plural(number, "пункт", "пункта", "пунктов"), word)

    def test_invalid_skill_name_never_touches_the_disk(self):
        project = PROJECT_ROOT / "skills"
        roots = [project, FULL / "09_skills"]
        for name in ("..", "../skills/project-status", "a/b", None):
            with self.subTest(name=name):
                self.assertEqual(_skill_root_for(roots, name), project)
                with self.assertRaises(SkillFormatError) as refused:
                    load_skill(_skill_root_for(roots, name), name)
                self.assertEqual(str(refused.exception), "недопустимое имя skill")
        self.assertEqual(_skill_root_for(roots, "lesson-notes"), FULL / "09_skills")


class NoSecondMechanismTests(unittest.TestCase):
    def test_constructor_composes_existing_modules(self):
        for path in ("dezhurny.py", "school_agent/my_agent_config.py"):
            source = (PROJECT_ROOT / path).read_text(encoding="utf-8")
            for token in ("while ", "call_tool", "TraceRecorder(", "decide", "_split_skill_file",
                          "importlib", "exec(", "__import__", "subprocess", "socket", "urllib"):
                with self.subTest(path=path, token=token):
                    self.assertNotIn(token, source)
            self.assertIsNone(re.search(r"eval\(", source))

    def test_dispatcher_is_untouched(self):
        # dispatcher.py глава 7 печатает целиком; allowlist ученика проверяет run_agent до него.
        source = (PROJECT_ROOT / "school_agent" / "dispatcher.py").read_text(encoding="utf-8")
        self.assertNotIn("profile", source)

    def test_profile_is_plain_data(self):
        profile = HarnessProfile(allowed_tools=["read_task_cards"])
        self.assertTrue(profile.allows("read_task_cards"))
        self.assertFalse(profile.allows("validate_task_card"))
        self.assertTrue(HarnessProfile().allows("anything"))


class RegressionSnapshot(unittest.TestCase):
    def test_old_golden_untouched(self):
        # Эталоны глав 14+ в слепок конструктора не входят (как в тестах глав 11–13).
        names = sorted(path.name for path in OLD_GOLDEN.iterdir() if not RETROFIT_GOLDEN.match(path.name) if not re.match(r"ch1[4-9]_", path.name))
        self.assertEqual(len(names), OLD_GOLDEN_COUNT)
        digest = hashlib.sha256()
        for name in names:
            digest.update(name.encode("utf-8"))
            digest.update(hashlib.sha256((OLD_GOLDEN / name).read_bytes()).digest())
        self.assertEqual(digest.hexdigest(), OLD_GOLDEN_DIGEST)

    def test_six_constructor_golden(self):
        self.assertEqual(len(list(GOLDEN.iterdir())), 6)


if __name__ == "__main__":
    unittest.main()
