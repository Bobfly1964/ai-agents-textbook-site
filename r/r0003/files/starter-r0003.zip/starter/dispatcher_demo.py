"""Глава 7. Диспетчер и ошибки: две линзы на уже существующий механизм.

``case`` — один tool call проходит через существующий ``call_tool``: allowlist,
проверка arguments, выполнение и перехват ошибки выполняет он, а не эта
демонстрация. ``run`` — пакет tool calls из авторского сценария (replay)
проходит через существующий ``run_agent``; печатаются события его журнала.

Сеть не используется, карточки проекта не изменяются. Своей таблицы имён,
своей проверки arguments, своей политики решения и своего журнала здесь нет.
"""

import argparse

from school_agent.agent import run_agent
from school_agent.dispatcher import call_tool
from school_agent.paths import PROJECT_ROOT
from school_agent.replay_model import ReplayModel
from school_agent.tools import Tools


REPLAY_PATH = PROJECT_ROOT / "workspace" / "ch07" / "replay" / "dispatcher_cases.json"
ORIGIN_NOTE = "авторский сценарий, не запись модели"

# Учебные tool calls для линзы case: сценарий Tools и попытки по порядку.
CASES = {
    "allowed": ("success", [
        {"id": "call-1", "name": "read_task_cards", "arguments": {}},
    ]),
    "unknown-tool": ("success", [
        {"id": "call-X", "name": "delete_everything", "arguments": {}},
    ]),
    "invalid-arguments": ("success", [
        {"id": "call-2", "name": "validate_task_card", "arguments": {}},
    ]),
    "tool-exception": ("temporary_error", [
        {"id": "call-3", "name": "read_task_cards", "arguments": {}},
        {"id": "call-4", "name": "read_task_cards", "arguments": {}},
    ]),
}

# Сценарий replay-файла и сценарий учебных данных для линзы run.
RUNS = {
    "two-calls": ("two_calls", "success"),
    "stop-after-decision": ("stop_after_decision", "success"),
    "missing-file": ("missing_file", "missing_file"),
}


def _checks(observation):
    """Что успел проверить call_tool: читается из его ответа, не вычисляется заново."""

    code = observation.get("error", {}).get("code")
    if code == "unknown_tool":
        return "denied", "not checked"
    if code == "invalid_arguments":
        return "allowed", "invalid"
    return "allowed", "valid"


def _execution(observation):
    return "performed" if observation["executed"] else "not performed"


def _outcome(observation):
    return "result" if observation["ok"] else "tool error"


def _print_case_block(observation):
    allowlist, arguments = _checks(observation)
    print("call_id: " + observation["call_id"])
    print("tool: " + observation["name"])
    print("allowlist: " + allowlist)
    print("arguments: " + arguments)
    print("execution: " + _execution(observation))
    print("outcome: " + _outcome(observation))
    if not observation["ok"]:
        print("error: " + observation["error"]["message"])


def _case(name):
    scenario, calls = CASES[name]
    tools = Tools(scenario=scenario)
    for index, tool_call in enumerate(calls):
        if index:
            print()
        _print_case_block(call_tool(tool_call, tools))


def _event_line(event):
    value = event["payload"]
    if event["type"] == "tool_requested":
        request = value["request"]
        return " | ".join([
            "event: tool_requested",
            "call_id: " + request["id"],
            "tool: " + request["name"],
        ])
    if event["type"] == "tool_observation":
        observation = value["observation"]
        parts = [
            "event: tool_observation",
            "call_id: " + observation["call_id"],
            "tool: " + observation["name"],
            "execution: " + _execution(observation),
            "outcome: " + _outcome(observation),
            "decision: " + value["decision"],
        ]
        if not observation["ok"]:
            parts.append("error: " + observation["error"]["message"])
        return " | ".join(parts)
    if event["type"] == "run_finished":
        return " | ".join([
            "event: run_finished",
            "terminal: " + value["terminal"],
            "steps: " + str(value["steps"]),
        ])
    return None


def _not_executed(trace):
    """Вызовы из ответов модели, для которых в журнале нет observation."""

    observed = {
        event["payload"]["observation"]["call_id"]
        for event in trace
        if event["type"] == "tool_observation"
    }
    missing = []
    for event in trace:
        response = event["payload"].get("response") if event["type"] == "model_response" else None
        if response and response["type"] == "tool_calls":
            missing += [call for call in response["tool_calls"] if call["id"] not in observed]
    return missing


def _run(name):
    replay_scenario, tools_scenario = RUNS[name]
    adapter = ReplayModel(REPLAY_PATH, replay_scenario)
    print("mode: replay")
    print("origin: " + adapter.provenance["kind"] + " — " + ORIGIN_NOTE)
    result = run_agent(adapter, scenario=tools_scenario)
    for event in result["trace"]:
        line = _event_line(event)
        if line is not None:
            print(line)
    for call in _not_executed(result["trace"]):
        print("not executed: " + call["id"] + " " + call["name"])


def main(argv=None):
    parser = argparse.ArgumentParser(
        description="Диспетчер и ошибки главы 7 на локальных учебных данных.",
    )
    commands = parser.add_subparsers(dest="command", required=True)
    case = commands.add_parser("case", help="один tool call через call_tool")
    case.add_argument("name", choices=list(CASES))
    run = commands.add_parser("run", help="пакет tool calls из replay через run_agent")
    run.add_argument("name", choices=list(RUNS))
    args = parser.parse_args(argv)

    if args.command == "case":
        _case(args.name)
    else:
        _run(args.name)
    return 0


if __name__ == "__main__":
    main()
