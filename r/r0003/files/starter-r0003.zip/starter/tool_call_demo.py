"""Глава 6. Первый tool: показать запрос, проверить arguments, выполнить вызов.

Локальная учебная демонстрация: сеть не используется, карточки проекта не
изменяются. Ответ модели берётся из файла ``workspace/ch06/replay/`` — это
ответ модели по авторскому сценарию (replay), а не поведение живой модели;
происхождение печатает сама программа строкой ``origin``.

Схемы читает существующий ``school_agent.validation`` из
``data/tool_schemas.json``; второго источника схем в starter нет. Фактический
вызов функции выполняет существующий обработчик приложения
``school_agent.dispatcher.call_tool``.
"""

import argparse
import json
from pathlib import Path

from school_agent.dispatcher import call_tool
from school_agent.paths import (
    PROJECT_ROOT,
    WorkspaceBoundaryError,
    resolve_workspace_path,
)
from school_agent.tools import Tools
from school_agent.validation import (
    CARD_SCHEMA,
    TOOL_SCHEMAS,
    validate_task_card_schema,
    validate_tool_arguments,
)


CH06_ROOT = (PROJECT_ROOT / "workspace" / "ch06").resolve()
FIXTURES_ROOT = (PROJECT_ROOT / "tests" / "fixtures").resolve()
REPLAY_PATH = CH06_ROOT / "replay" / "read_task_cards.json"

# Путь, который создаёт сам ученик, и шаблон, с которого он начинает.
DRAFT_PATH = "workspace/drafts/ch06_tool_call.json"
TEMPLATE_PATH = "workspace/ch06/templates/tool_call.json"

# Честная подпись происхождения replay по Канону: значение слева от тире
# берётся из самого файла, объяснение справа печатает демонстрация.
ORIGIN_NOTE = "авторский сценарий, не запись модели"

SCHEMA_NAMES = ["read_task_cards", "validate_task_card", "task_card"]


def _resolve_ch06_path(raw):
    """Файл читается только из ``workspace/`` ученика или из фикстур курса.

    Границу в обоих случаях проверяет существующий ``resolve_workspace_path``:
    абсолютный путь и выход вверх по дереву отклоняются.
    """

    path = Path(raw)
    if path.is_absolute():
        raise WorkspaceBoundaryError("ожидался относительный путь внутри starter")
    parts = path.as_posix().split("/")
    if parts[0] == "workspace" and len(parts) > 1:
        return resolve_workspace_path(Path(*parts[1:]))
    if parts[:2] == ["tests", "fixtures"] and len(parts) > 2:
        return resolve_workspace_path(Path(*parts[2:]), workspace_root=FIXTURES_ROOT)
    raise WorkspaceBoundaryError(
        "файл читается только из workspace/ или tests/fixtures/"
    )


def _read_json(path):
    with Path(path).open(encoding="utf-8") as source:
        return json.load(source)


def _read_replay():
    """Происхождение и единственный заранее подготовленный tool call."""

    document = _read_json(REPLAY_PATH)
    response = document["scenarios"]["default"][0]["response"]
    return document["provenance"], response["tool_calls"][0]


def _as_json(value):
    return json.dumps(value, ensure_ascii=False)


def _format_call(tool_call):
    return _as_json({
        "id": tool_call["id"],
        "name": tool_call["name"],
        "arguments": tool_call["arguments"],
    })


def _print_origin(provenance):
    print("mode: replay")
    print("origin: " + provenance["kind"] + " — " + ORIGIN_NOTE)


def _show():
    """Запрос показан, но функция не вызывалась."""

    provenance, tool_call = _read_replay()
    _print_origin(provenance)
    print("tool call: " + _format_call(tool_call))
    print("execution: not performed")


def _execute():
    """Тот же запрос, но приложение действительно вызывает функцию."""

    provenance, tool_call = _read_replay()
    _print_origin(provenance)
    print("tool call: " + _format_call(tool_call))
    errors = validate_tool_arguments(tool_call["name"], tool_call["arguments"])
    print("JSON Schema: " + ("invalid" if errors else "valid"))
    outcome = call_tool(tool_call, Tools())
    if not outcome["ok"]:
        print("execution: error")
        print(outcome["error"]["message"])
        return
    value = outcome["result"]
    print("execution: performed by application")
    print("tool result: " + _as_json({
        "ok": outcome["ok"],
        "count": value["count"],
        "trust": value["provenance"]["trust"],
        "assigned_by": value["provenance"]["assigned_by"],
    }))


def _check(raw_path, path):
    """Проверка arguments одного tool call до выполнения."""

    if not path.is_file() and Path(raw_path).as_posix() == DRAFT_PATH:
        print("ошибка: файл не создан: " + DRAFT_PATH)
        print("подсказка: скопируй " + TEMPLATE_PATH + " и впиши свой task_id")
        return
    tool_call = _read_json(path)
    errors = validate_tool_arguments(tool_call["name"], tool_call["arguments"])
    print("tool: " + tool_call["name"])
    print("arguments: " + _as_json(tool_call["arguments"]))
    if errors:
        print("JSON Schema: invalid")
        print("reason: " + errors[0])
    else:
        print("JSON Schema: valid")
    print("execution: not performed")


def _check_card(path):
    """Проверка карточки задачи по schema из data/tool_schemas.json."""

    card = _read_json(path)
    errors = validate_task_card_schema(card)
    print("card: " + card["id"])
    if errors:
        print("JSON Schema: invalid")
        print("reason: " + errors[0])
    else:
        print("JSON Schema: valid")


def _print_schema(name):
    schema = CARD_SCHEMA if name == "task_card" else TOOL_SCHEMAS[name]
    print("schema: " + name)
    print(json.dumps(schema, ensure_ascii=False, indent=2))


def main(argv=None):
    parser = argparse.ArgumentParser(
        description="Первый tool главы 6 на локальных учебных данных.",
    )
    commands = parser.add_subparsers(dest="command", required=True)
    commands.add_parser("show", help="показать replay tool call без выполнения")
    commands.add_parser("execute", help="выполнить тот же tool call через приложение")
    check = commands.add_parser("check", help="проверить arguments файла tool call")
    check.add_argument("path", help="путь к файлу внутри workspace/ или tests/fixtures/")
    card = commands.add_parser("check-card", help="проверить карточку задачи по schema")
    card.add_argument("path", help="путь к файлу внутри workspace/ или tests/fixtures/")
    schema = commands.add_parser("schema", help="напечатать учебную schema")
    schema.add_argument("name", choices=SCHEMA_NAMES)
    args = parser.parse_args(argv)

    if args.command == "show":
        _show()
    elif args.command == "execute":
        _execute()
    elif args.command == "schema":
        _print_schema(args.name)
    else:
        try:
            path = _resolve_ch06_path(args.path)
            if args.command == "check":
                _check(args.path, path)
            else:
                _check_card(path)
        except (WorkspaceBoundaryError, OSError, ValueError) as exc:
            parser.error(str(exc))
    return 0


if __name__ == "__main__":
    main()
