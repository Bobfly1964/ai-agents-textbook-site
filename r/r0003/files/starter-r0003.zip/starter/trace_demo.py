"""Глава 12. Traces: записать запуск, посмотреть карту событий, разобрать сбой.

``record`` запускает знакомый replay-маршрут через существующий ``run_agent``:
журнал пишет его ``TraceRecorder``, второго цикла и второй записи здесь нет.
``show`` и ``analyze`` только читают JSONL внутри ``workspace`` и ничего не
изменяют. Скрытые рассуждения модели не печатаются: их в Trace нет. Сеть не
используется, карточки проекта не изменяются.
"""

import argparse
import json
from pathlib import Path

from school_agent.agent import DEFAULT_REPLAY_PATH, run_replay_scenario
from school_agent.paths import WorkspaceBoundaryError
from school_agent.trace_analysis import TraceFormatError, build_incident_report, load_trace

ORIGIN_NOTE = "авторский сценарий, не запись модели"
SCENARIOS = sorted(json.loads(DEFAULT_REPLAY_PATH.read_text(encoding="utf-8"))["scenarios"])


def _workspace_relative(raw):
    """``workspace/…`` → путь относительно workspace; границу проверит resolve_workspace_path."""

    path = Path(raw)
    parts = path.as_posix().split("/")
    if path.is_absolute() or parts[0] != "workspace" or len(parts) < 2:
        raise WorkspaceBoundaryError("ожидался относительный путь внутри workspace/")
    return "/".join(parts[1:])


def _record(scenario, out):
    try:
        result = run_replay_scenario(scenario, trace_relative_path=out)
    except ValueError as exc:
        if "trace уже существует" not in str(exc):
            raise
        print("record: not saved")
        print("trace: " + out)
        print("error: " + str(exc))
        print("result: existing trace kept")
        return
    print("mode: " + result["adapter"])
    print("trace: " + out)
    print("terminal: " + result["terminal"])
    print("origin: " + result["evidence_kind"] + " — " + ORIGIN_NOTE)


def _show_line(event):
    kind, payload = event["type"], event["payload"]
    head = kind + " | initiator: " + event["initiator"]
    if kind == "tool_requested":
        return " " + head + " | call_id: " + payload["request"]["id"] + \
               " | tool: " + payload["request"]["name"]
    if kind == "tool_observation":
        observation = payload["observation"]
        return " " + head + " | call_id: " + observation["call_id"] + \
               " | outcome: " + ("result" if observation["ok"] else "tool error") + \
               " | decision: " + payload["decision"]
    if kind == "run_finished":
        return head + " | terminal: " + payload["terminal"] + " | steps: " + str(payload["steps"])
    return head


def _show(raw):
    relative = _workspace_relative(raw) if raw.startswith("workspace/") else raw
    events = load_trace(relative)
    print("trace: " + relative)
    for event in events:
        print(_show_line(event))


def _analyze(raw):
    relative = _workspace_relative(raw) if raw.startswith("workspace/") else raw
    try:
        events = load_trace(relative)
    except TraceFormatError as exc:
        print("trace: " + relative)
        print("result: not analyzable")
        print("error: " + str(exc))
        return
    print("trace: " + relative)
    report = build_incident_report(events)
    print("terminal: " + report["terminal"])
    print("tool_calls: " + str(report["tool_calls"]))
    print("errors: " + str(report["errors"]))
    print("approval_events: " + str(report["approval_events"]))
    point = report["failure_point"]
    if point is None:
        print("failure_point: нет наблюдаемого отклонения")
        print("root_cause: не установлена")
        return
    place = [point["type"]]
    if point["call_id"]:
        place += [point["call_id"], point["tool"]]
    print("failure_point: " + " ".join(place))
    print("root_cause: " + report["root_cause"])


def main(argv=None):
    parser = argparse.ArgumentParser(
        description="Trace главы 12 на локальных учебных данных.",
    )
    commands = parser.add_subparsers(dest="command", required=True)
    record = commands.add_parser("record", help="записать новый Trace знакомого replay-запуска")
    record.add_argument("--scenario", required=True, choices=SCENARIOS)
    record.add_argument("--out", required=True, help="путь внутри workspace/traces/")
    show = commands.add_parser("show", help="компактная карта событий Trace")
    show.add_argument("path")
    analyze = commands.add_parser("analyze", help="симптом, failure point и root cause")
    analyze.add_argument("path")
    args = parser.parse_args(argv)

    try:
        if args.command == "record":
            _record(args.scenario, args.out)
        elif args.command == "show":
            _show(args.path)
        else:
            _analyze(args.path)
    except (ValueError, FileNotFoundError, OSError) as exc:
        parser.error(str(exc))
    return 0


if __name__ == "__main__":
    main()
