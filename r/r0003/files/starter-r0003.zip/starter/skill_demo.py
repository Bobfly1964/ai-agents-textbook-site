"""Глава 9. Agent Skill по слоям: каталог, инструкции, ресурс, проверка каталога, replay.

Все подкоманды используют единственный загрузчик ``school_agent.skill_loader``;
второго разбора ``SKILL.md`` здесь нет. Файлы из ``scripts/`` только
перечисляются и никогда не запускаются. Сеть не используется.
"""

import argparse
from pathlib import Path

from school_agent.agent import run_replay_scenario
from school_agent.paths import (
    PROJECT_ROOT,
    WorkspaceBoundaryError,
    resolve_workspace_path,
)
from school_agent.skill_loader import (
    SkillFormatError,
    discover_skills,
    list_skill_files,
    load_skill,
    read_skill_resource,
)

SKILLS_ROOT = PROJECT_ROOT / "skills"
TEMPLATE_DIR = "workspace/ch09/templates/project-status/"
ORIGIN_NOTE = "авторский сценарий, не запись модели"


def _print_files(files):
    print("supporting files:" + ("" if files else " нет"))
    for item in files:
        print("  " + item["path"] + " (" + item["kind"] + ")")


def _catalog():
    skills = discover_skills(SKILLS_ROOT)
    print("layer: catalog")
    for skill in skills:
        print("skill: " + skill["name"])
        print("description: " + skill["description"])
    print("instructions loaded: no")
    print("resources read: no")


def _load(name):
    skill = load_skill(SKILLS_ROOT, name)
    print("layer: instructions")
    print("skill: " + skill["metadata"]["name"])
    print("SKILL.md: loaded")
    print("frontmatter fields: " + ", ".join(skill["metadata"]))
    print("instructions lines: " + str(len(skill["instructions"].splitlines())))
    _print_files(skill["available_files"])
    print("resources read: no")
    print("scripts executed: no")


def _resource(name, relative_path):
    resource = read_skill_resource(SKILLS_ROOT, name, relative_path)
    lines = resource["content"].splitlines()
    print("layer: resource")
    print("skill: " + name)
    print("resource: " + resource["path"])
    print("content lines: " + str(len(lines)))
    print("first line: " + (lines[0] if lines else ""))
    print("other resources read: no")
    print("scripts executed: no")


def _resolve_check_path(raw):
    """Только каталог внутри workspace/; границу проверяет resolve_workspace_path."""

    path = Path(raw)
    parts = path.as_posix().split("/")
    if path.is_absolute() or parts[0] != "workspace" or len(parts) < 2:
        raise WorkspaceBoundaryError("ожидался относительный путь внутри workspace/")
    return resolve_workspace_path(Path(*parts[1:]))


def _check(raw):
    directory = _resolve_check_path(raw)
    print("check: " + Path(raw).as_posix())
    if not directory.is_dir():
        print("result: not accepted")
        print("reason: каталог не найден")
        print("подсказка: скопируй " + TEMPLATE_DIR + " в " + Path(raw).as_posix()
              + "/ и переименуй SKILL.template.md в SKILL.md")
        return
    has_skill_file = (directory / "SKILL.md").is_file()
    print("SKILL.md: " + ("found" if has_skill_file else "missing"))
    if not has_skill_file:
        others = sorted(item.name for item in directory.iterdir() if item.is_file())
        print("other files: " + (", ".join(others) if others else "нет"))
    try:
        skill = load_skill(directory.parent, directory.name)
    except SkillFormatError as exc:
        print("scripts executed: no")
        print("result: not accepted")
        print("reason: " + str(exc))
        return
    print("frontmatter: valid")
    print("name matches directory: yes")
    print("description: present")
    print("instructions: " + ("present" if skill["instructions"].strip() else "empty"))
    _print_files(list_skill_files(directory))
    print("scripts executed: no")
    print("result: " + ("accepted" if skill["instructions"].strip() else "not accepted"))


def _replay():
    result = run_replay_scenario("success")
    print("mode: replay")
    print("origin: " + result["evidence_kind"] + " — " + ORIGIN_NOTE)
    for event in result["trace"]:
        value = event["payload"]
        if event["type"] == "model_response":
            response = value["response"]
            if response["type"] == "load_skill":
                print("model request: load_skill " + response["name"])
            elif response["type"] == "read_skill_resource":
                print("model request: read_skill_resource " + response["name"] + " " + response["path"])
        elif event["type"] == "skill_loaded":
            print("harness: skill_loaded " + value["name"])
        elif event["type"] == "skill_resource_loaded":
            print("harness: skill_resource_loaded " + value["name"] + " " + value["path"])
    print("context_requests: " + str(result["state"]["context_requests"]))
    print("model quality verified: " + ("yes" if result["model_quality_verified"] else "no"))


def main(argv=None):
    parser = argparse.ArgumentParser(
        description="Agent Skill главы 9: слои загрузки, проверка каталога и replay.",
    )
    commands = parser.add_subparsers(dest="command", required=True)
    commands.add_parser("catalog", help="слой 1: только name и description")
    load = commands.add_parser("load", help="слой 2: SKILL.md без чтения ресурсов")
    load.add_argument("name")
    resource = commands.add_parser("resource", help="слой 3: один reference или asset")
    resource.add_argument("name")
    resource.add_argument("relative_path")
    check = commands.add_parser("check", help="проверить каталог skill внутри workspace/")
    check.add_argument("path")
    commands.add_parser("replay", help="запросы skill в авторском сценарии success")
    args = parser.parse_args(argv)

    try:
        if args.command == "catalog":
            _catalog()
        elif args.command == "load":
            _load(args.name)
        elif args.command == "resource":
            _resource(args.name, args.relative_path)
        elif args.command == "check":
            _check(args.path)
        else:
            _replay()
    except (SkillFormatError, WorkspaceBoundaryError) as exc:
        parser.error(str(exc))
    return 0


if __name__ == "__main__":
    main()
